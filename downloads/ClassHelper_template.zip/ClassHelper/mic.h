// =====================================================================
//  mic.h  —  보드 마이크(ES8311 코덱) 소리 크기 읽기
//
//  앱에서 쓰는 법 (이 4가지만 알면 됩니다)
//    Mic::start();          // 앱에 들어올 때 마이크 켜기
//    Mic::stop();           // 앱에서 나갈 때 마이크 끄기  ← 꼭!
//    Mic::hasNew()          // 새 측정값이 나왔으면 true (1초에 약 20번)
//    Mic::db()              // 지금 소리 크기 (dBFS: 조용하면 -70, 시끄러우면 -20 쯤)
//
//  ⚠️ 이 값은 소음계의 '데시벨(dB)'이 아니라 마이크 안에서 잰 '상대적인 크기'입니다.
//     그래서 교실마다 "조용할 때 값"을 기준으로 저장해 두고, 그보다 얼마나 큰지로 판단하세요.
//  ⚠️ 스피커에서 소리가 나는 동안(+0.25초)은 측정을 멈춥니다.
//     자기 경고음을 듣고 또 울리는 일을 막기 위해서예요.
// =====================================================================
#pragma once
#include <math.h>
#include "sfx.h"

namespace Mic {
  static volatile bool     on      = false;
  static volatile float    lastDb  = -90.0f;
  static volatile uint32_t seq     = 0;     // 측정할 때마다 1씩 늘어남
  static uint32_t          seenSeq = 0;
  static bool              taskUp  = false;

  static void task(void*) {
    const int FRAMES = 1024;                 // 22050Hz 에서 약 46ms
    static int16_t buf[FRAMES * 2];          // 스테레오(L,R) 16bit
    for (;;) {
      if (!on || !Sfx::ready) { vTaskDelay(pdMS_TO_TICKS(30)); continue; }
      size_t n = Sfx::i2s.readBytes((char*)buf, sizeof(buf));
      int frames = n / 4;
      if (frames < 64) { vTaskDelay(pdMS_TO_TICKS(10)); continue; }
      if (Sfx::recentlyPlayed(250)) continue;          // 스피커 소리는 버림

      // 왼쪽/오른쪽 중 소리가 들어오는 쪽을 사용 (DC 성분 제거 후 RMS)
      double sumL = 0, sumR = 0;
      for (int i = 0; i < frames; i++) { sumL += buf[2 * i]; sumR += buf[2 * i + 1]; }
      double mL = sumL / frames, mR = sumR / frames, eL = 0, eR = 0;
      for (int i = 0; i < frames; i++) {
        double a = buf[2 * i] - mL, b = buf[2 * i + 1] - mR;
        eL += a * a; eR += b * b;
      }
      double rms = sqrt((eL > eR ? eL : eR) / frames);
      float d = (rms < 1.0) ? -90.0f : 20.0f * log10f((float)(rms / 32768.0));
      lastDb = d;
      seq = seq + 1;
    }
  }

  static void start() {
    if (!taskUp) {
      xTaskCreatePinnedToCore(task, "mic", 4096, nullptr, 2, nullptr, 0);
      taskUp = true;
    }
    seenSeq = seq;
    on = true;
  }
  static void stop() { on = false; }

  static bool  hasNew() { if (seq != seenSeq) { seenSeq = seq; return true; } return false; }
  static float db()     { return lastDb; }
}
