// =====================================================================
//  app_noise.h  —  🚦 교실 소음 신호등  (2차시에 만들어요)
//
//  🙋 지금은 빈 자리입니다. 첫 화면에 회색 "다음 시간에" 칸으로 보여요.
//
//  ── 바이브코딩 하는 법 ──
//   1) 이 파일 전체와 helper.h 를 복사해서 AI(제미나이)에게 붙여 넣고
//   2) 연수 워크벤치의 프롬프트를 함께 보내면
//   3) AI가 이 파일 하나를 통째로 새로 써 줍니다 → 이 탭에 덮어쓰기 → 업로드
//
//  ── AI에게 꼭 지켜 달라고 할 약속 (helper.h 맨 위에 자세히) ──
//   - namespace AppNoise { ... } 안에 start / update / touch / stop 4개 함수
//   - 맨 끝 const App app = { ... } 의 마지막 값을 true 로 (완성 표시)
//   - 화면 240x320, 왼쪽 위 (0,0)~(43,29) 는 🏠 자리 → start() 에서 drawHomeButton()
//   - 다른 파일(ClassHelper.ino, helper.h 등)은 고치지 않기
//   - 마이크: Mic::start() 는 start() 에서, Mic::stop() 은 stop() 에서 (꼭!)
//   - 경고음: Sfx::play(SFX_ALERT)
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"
#include "mic.h"
#include "ble_hid.h"

namespace AppNoise {

// 첫 화면 단추 아이콘 (가운데 좌표 cx, cy / 지름 약 40px 안에 그리기)
static void icon(int cx, int cy) {
  lcd.drawCircle(cx, cy, 14, C_DARK);
}

// ① 앱에 들어올 때: 화면 전체를 그린다
static void start() {
  lcd.fillScreen(C_BG);
  drawTitleBar("소음 신호등");
  text("여기에 만들 거예요", 120, 160, &fonts::efontKR_16, C_WHITE);
}

// ② 계속 반복 (1초에 약 100번)
static void update() {
}

// ③ 터치: ev 는 TOUCH_DOWN / TOUCH_MOVE / TOUCH_UP, (x, y) 는 손가락 위치
static void touch(uint8_t ev, int x, int y) {
}

// ④ 나갈 때: 정리
static void stop() {
}

const App app = {
  "소음 신호등", "교실 소리를 색으로 보여요", C_NOISE, icon,
  start, update, touch, stop,
  nullptr,   // BOOT 버튼 (안 쓰면 nullptr)
  false,     // true = 이 앱에서는 자동 절전 안 함
  false      // ← 완성되면 true 로!
};

}  // namespace AppNoise
