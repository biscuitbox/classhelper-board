// =====================================================================
//  config.h  —  보드 핀 & 기기 설정
//  보드: LCDwiki ES3C28P (ESP32-S3 N16R8, 2.8" IPS 240x320,
//        ILI9341V + FT6336G 정전식 터치 + ES8311 코덱 + FM8002E 앰프)
//
//  ✏️ 선생님이 바꿔도 되는 곳은 맨 위 "기기 이름" 세 줄과 시계 와이파이 세 줄뿐입니다.
//     나머지는 보드 배선이라 건드리지 마세요.
// =====================================================================
#pragma once

// ---------- ✏️ 기기 이름 (첫 화면에 보여요) ----------
#define DEVICE_TITLE   "교탁 도우미"
#define DEVICE_OWNER   "2학년 3반"          // 반 이름, 선생님 이름 등
#define BT_NAME        "ClassHelper-01"     // 블루투스 이름 — 영어·숫자만, 보드마다 번호를 다르게!

// ---------- ✏️ 탁상시계: 인터넷으로 시간 맞추기 (안 써도 됨) ----------
// 와이파이가 있으면 1 로 바꾸고 이름·비밀번호를 적으세요. 0 이면 시계 화면에서 손으로 맞춥니다.
// (학교 와이파이처럼 로그인 화면이 뜨는 곳은 안 됩니다. 휴대폰 핫스팟은 됩니다.)
#define CLOCK_WIFI     0
#define WIFI_SSID      ""
#define WIFI_PASS      ""

// ---------- LCD (SPI, ILI9341V) ----------
#define PIN_LCD_SCK    12
#define PIN_LCD_MOSI   11
#define PIN_LCD_MISO   13
#define PIN_LCD_CS     10
#define PIN_LCD_DC     46
#define PIN_LCD_BL     45     // HIGH = 백라이트 켜짐
// LCD 리셋은 ESP32 EN(리셋)과 공용이라 따로 핀이 없음

// 화면이 좌우로 뒤집혀(거울처럼) 보이면 0 -> 6 으로 바꾸세요.
#define LCD_OFFSET_ROTATION  0

// ---------- 터치 (I2C, FT6336G) ----------
#define PIN_I2C_SDA    16     // 터치·코덱·확장 I2C 공용 버스
#define PIN_I2C_SCL    15
#define PIN_TP_INT     17
#define PIN_TP_RST     18

// 터치 위치가 화면과 어긋날 때만 바꾸세요 (설정 → 점검 화면에서 확인)
#define TOUCH_SWAP_XY   0
#define TOUCH_MIRROR_X  1
#define TOUCH_MIRROR_Y  1
#define TOUCH_Y_OFFSET  0     // 손가락이 살짝 아래를 누른다면 -3 ~ -5

// ---------- 오디오 (I2S, ES8311 + FM8002E) ----------
#define PIN_I2S_MCLK    4
#define PIN_I2S_BCLK    5
#define PIN_I2S_LRCK    7
#define PIN_I2S_DOUT    8     // ESP32 -> 코덱 (스피커)
#define PIN_I2S_DIN     6     // 코덱 -> ESP32 (마이크)
#define PIN_AMP_EN      1
#define AMP_ON_LEVEL    LOW   // 제조사 문서: Low = 앰프 켜짐. 소리가 안 나면 HIGH 로 바꿔 보세요.
#define AUDIO_SAMPLE_RATE 22050

// ---------- 기타 ----------
#define PIN_WS2812     42     // 보드 뒷면 RGB LED (1개 내장)
#define PIN_BAT_ADC     9     // 배터리 전압 (1/2 분압) — 뒷면 1.25mm 2핀에 3.7V 리튬 배터리
#define BAT_DIVIDER   2.0f
#define PIN_BOOT_BTN    0     // 뒷면 BOOT 버튼 (앱마다 쓰임이 다름)

// ---------- 공통 조작 ----------
#define LONG_PRESS_MS  380    // 길게 누르기 판정 시간 (지뢰찾기 깃발)
#define HOME_HOLD_MS   700    // 왼쪽 위 🏠 를 이만큼 누르고 있으면 첫 화면으로
