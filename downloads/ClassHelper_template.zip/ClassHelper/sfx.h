// =====================================================================
//  sfx.h  —  8비트풍 효과음 신시사이저 (I2S 출력, 별도 코어에서 동작)
//  효과음은 음표 배열로 정의 → 실시간 합성. 파일/SD카드 필요 없음.
//  사용법: Sfx::play(SFX_TAP);   ← 앱 어디서든 이 한 줄로 소리를 냅니다.
//  새 소리가 필요하면 아래 S_xxx 배열을 하나 만들고 표 3곳에 이름을 더하세요.
// =====================================================================
#pragma once
#include <ESP_I2S.h>
#include "config.h"
#include "es8311.h"

enum SfxId : uint8_t {
  SFX_NONE = 0, SFX_TAP, SFX_OPEN, SFX_FLOOD, SFX_FLAG, SFX_UNFLAG, SFX_CHORD,
  SFX_BOOM, SFX_WIN, SFX_RECORD, SFX_START, SFX_ERROR, SFX_SLEEP, SFX_WAKE,
  SFX_KEY,      // 프레젠터 버튼 (아주 짧은 딸깍)
  SFX_HOME,     // 첫 화면으로
  SFX_ALERT,    // 소음 경고 (삐-뽀-삐-뽀)
  SFX_ALARM,    // 타이머 끝 (띠리리 ×3)
  SFX_COUNT
};

enum : uint8_t { W_SQ50, W_SQ25, W_TRI, W_NOISE, W_REST };
enum : uint8_t { ENV_FLAT, ENV_DECAY, ENV_FAST };

struct SfxNote {
  uint16_t f0, f1;     // 시작/끝 주파수(Hz) — 다르면 미끄러지듯 변함
  uint16_t ms;         // 길이
  uint8_t  wave;       // 파형
  uint8_t  vol;        // 0~100
  uint8_t  env;        // 음량 변화
};
#define SFX_END {0, 0, 0, W_REST, 0, ENV_FLAT}

static const SfxNote S_TAP[]    = {{1800,1800, 14, W_SQ25, 35, ENV_FAST}, SFX_END};
static const SfxNote S_OPEN[]   = {{ 900,1500, 28, W_SQ25, 45, ENV_DECAY}, SFX_END};
static const SfxNote S_FLOOD[]  = {{ 784, 784, 32, W_SQ25, 45, ENV_DECAY},
                                   { 988, 988, 32, W_SQ25, 45, ENV_DECAY},
                                   {1175,1175, 32, W_SQ25, 45, ENV_DECAY},
                                   {1568,1568, 70, W_SQ25, 45, ENV_DECAY}, SFX_END};
static const SfxNote S_FLAG[]   = {{ 880, 880, 35, W_SQ50, 40, ENV_FLAT},
                                   {1319,1319, 70, W_SQ50, 40, ENV_DECAY}, SFX_END};
static const SfxNote S_UNFLAG[] = {{1319,1319, 35, W_SQ50, 35, ENV_FLAT},
                                   { 880, 880, 60, W_SQ50, 35, ENV_DECAY}, SFX_END};
static const SfxNote S_CHORD[]  = {{ 988, 988, 25, W_SQ25, 45, ENV_FLAT},
                                   {1319,1760, 60, W_SQ25, 45, ENV_DECAY}, SFX_END};
static const SfxNote S_BOOM[]   = {{6000,6000, 90, W_NOISE,100, ENV_FLAT},
                                   {2500, 600,650, W_NOISE, 95, ENV_DECAY},
                                   { 120,  45,350, W_TRI,   80, ENV_DECAY}, SFX_END};
static const SfxNote S_WIN[]    = {{ 523, 523, 90, W_SQ50, 40, ENV_DECAY},
                                   { 659, 659, 90, W_SQ50, 40, ENV_DECAY},
                                   { 784, 784, 90, W_SQ50, 40, ENV_DECAY},
                                   {1047,1047,180, W_SQ50, 40, ENV_DECAY},
                                   {   0,   0, 60, W_REST,   0, ENV_FLAT},
                                   { 784, 784, 90, W_SQ50, 40, ENV_DECAY},
                                   {1047,1047,360, W_SQ50, 45, ENV_DECAY}, SFX_END};
static const SfxNote S_RECORD[] = {{1047,1047, 80, W_SQ25, 40, ENV_DECAY},
                                   {1319,1319, 80, W_SQ25, 40, ENV_DECAY},
                                   {1568,1568, 80, W_SQ25, 40, ENV_DECAY},
                                   {2093,2093, 80, W_SQ25, 40, ENV_DECAY},
                                   {1568,1568, 80, W_SQ25, 40, ENV_DECAY},
                                   {2093,2093,300, W_SQ25, 45, ENV_DECAY}, SFX_END};
static const SfxNote S_START[]  = {{ 659, 659, 60, W_SQ25, 40, ENV_DECAY},
                                   { 784, 784, 60, W_SQ25, 40, ENV_DECAY},
                                   { 988, 988,110, W_SQ25, 40, ENV_DECAY}, SFX_END};
static const SfxNote S_ERROR[]  = {{ 220, 180, 90, W_SQ50, 35, ENV_DECAY}, SFX_END};
static const SfxNote S_SLEEP[]  = {{ 784, 784, 70, W_TRI,  60, ENV_DECAY},
                                   { 523, 523, 70, W_TRI,  60, ENV_DECAY},
                                   { 392, 392,160, W_TRI,  60, ENV_DECAY}, SFX_END};
static const SfxNote S_WAKE[]   = {{ 392, 392, 60, W_TRI,  60, ENV_DECAY},
                                   { 523, 523, 60, W_TRI,  60, ENV_DECAY},
                                   { 784, 784,120, W_TRI,  60, ENV_DECAY}, SFX_END};

static const SfxNote S_KEY[]    = {{2400,2400,  8, W_SQ25, 30, ENV_FAST}, SFX_END};
static const SfxNote S_HOME[]   = {{ 988, 988, 50, W_TRI,  60, ENV_DECAY},
                                   { 659, 659, 90, W_TRI,  60, ENV_DECAY}, SFX_END};
static const SfxNote S_ALERT[]  = {{1319,1319,220, W_SQ50, 70, ENV_FLAT},
                                   { 988, 988,220, W_SQ50, 70, ENV_FLAT},
                                   {1319,1319,220, W_SQ50, 70, ENV_FLAT},
                                   { 988, 988,260, W_SQ50, 70, ENV_DECAY}, SFX_END};
static const SfxNote S_ALARM[]  = {{1568,1568, 90, W_SQ50, 70, ENV_FLAT}, {0,0, 40, W_REST,0,ENV_FLAT},
                                   {1568,1568, 90, W_SQ50, 70, ENV_FLAT}, {0,0, 40, W_REST,0,ENV_FLAT},
                                   {2093,2093,260, W_SQ50, 70, ENV_DECAY},{0,0,300, W_REST,0,ENV_FLAT},
                                   {1568,1568, 90, W_SQ50, 70, ENV_FLAT}, {0,0, 40, W_REST,0,ENV_FLAT},
                                   {1568,1568, 90, W_SQ50, 70, ENV_FLAT}, {0,0, 40, W_REST,0,ENV_FLAT},
                                   {2093,2093,260, W_SQ50, 70, ENV_DECAY},{0,0,300, W_REST,0,ENV_FLAT},
                                   {1568,1568, 90, W_SQ50, 70, ENV_FLAT}, {0,0, 40, W_REST,0,ENV_FLAT},
                                   {1568,1568, 90, W_SQ50, 70, ENV_FLAT}, {0,0, 40, W_REST,0,ENV_FLAT},
                                   {2093,2093,500, W_SQ50, 70, ENV_DECAY}, SFX_END};

static const SfxNote* const SFX_TABLE[SFX_COUNT] = {
  nullptr, S_TAP, S_OPEN, S_FLOOD, S_FLAG, S_UNFLAG, S_CHORD,
  S_BOOM, S_WIN, S_RECORD, S_START, S_ERROR, S_SLEEP, S_WAKE,
  S_KEY, S_HOME, S_ALERT, S_ALARM
};
// 우선순위: 재생 중인 소리보다 같거나 높을 때만 끊고 새로 재생
static const uint8_t SFX_PRIO[SFX_COUNT] = {
  0, 1, 1, 2, 2, 2, 2,
  9, 8, 9, 5, 2, 9, 5,
  1, 6, 9, 9
};

namespace Sfx {
  static I2SClass      i2s;
  static QueueHandle_t queue   = nullptr;
  static volatile uint8_t gain = 160;     // 0~255 (설정의 볼륨)
  static bool          ready   = false;
  static volatile bool     playing = false;   // 소리가 나는 중인지 (마이크가 자기 소리를 듣지 않게)
  static volatile uint32_t quietSince = 0;    // 마지막 소리가 끝난 시각(ms)

  static void ampOn(bool on) {
    digitalWrite(PIN_AMP_EN, on ? AMP_ON_LEVEL : !AMP_ON_LEVEL);
  }

  static void task(void*) {
    const int N = 128;
    static int16_t buf[N * 2];
    const float SR = (float)AUDIO_SAMPLE_RATE;
    const SfxNote* cur = nullptr;
    uint8_t  curId = 0;
    int      idx = 0;
    uint32_t pos = 0, len = 0;
    uint32_t phase = 0, lfsr = 0xACE1u;
    float    noise = 1.0f;

    for (;;) {
      uint8_t req;
      while (xQueueReceive(queue, &req, 0) == pdTRUE) {
        if (req && req < SFX_COUNT && (!cur || SFX_PRIO[req] >= SFX_PRIO[curId])) {
          cur = SFX_TABLE[req]; curId = req; idx = 0; pos = 0;
          len = (uint32_t)(cur[0].ms * SR / 1000.0f);
        }
      }
      for (int i = 0; i < N; i++) {
        float s = 0.0f;
        if (cur) {
          if (pos >= len) {             // 다음 음표
            idx++; pos = 0;
            if (cur[idx].ms == 0) { cur = nullptr; curId = 0; }
            else len = (uint32_t)(cur[idx].ms * SR / 1000.0f);
          }
        }
        if (cur) {
          const SfxNote& n = cur[idx];
          float t = (float)pos / (float)len;
          if (n.wave != W_REST) {
            float f = n.f0 + (n.f1 - (float)n.f0) * t;
            uint32_t prev = phase;
            phase += (uint32_t)(f * (4294967296.0f / SR));
            float w;
            switch (n.wave) {
              case W_SQ50: w = (phase < 0x80000000u) ? 1.0f : -1.0f; break;
              case W_SQ25: w = (phase < 0x40000000u) ? 1.0f : -1.0f; break;
              case W_TRI: {
                float p = phase / 4294967296.0f;
                w = (p < 0.5f) ? (4.0f * p - 1.0f) : (3.0f - 4.0f * p);
              } break;
              default:                   // NOISE
                if (phase < prev) {
                  lfsr ^= lfsr << 13; lfsr ^= lfsr >> 17; lfsr ^= lfsr << 5;
                  noise = (lfsr & 1) ? 1.0f : -1.0f;
                }
                w = noise;
            }
            float e;
            if (n.env == ENV_FLAT)       e = 1.0f;
            else if (n.env == ENV_DECAY) e = 1.0f - t;
            else { float k = 1.0f - t;   e = k * k * k; }
            if (pos < 40) e *= pos / 40.0f;               // 시작 '딱' 소리 방지
            if (len - pos < 40) e *= (len - pos) / 40.0f; // 끝 '딱' 소리 방지
            s = w * e * (n.vol / 100.0f);
          }
          pos++;
        }
        int32_t v = (int32_t)(s * 11000.0f * (gain / 255.0f));
        buf[2 * i] = buf[2 * i + 1] = (int16_t)v;
      }
      bool now = (cur != nullptr);
      if (playing && !now) quietSince = millis();
      playing = now;
      i2s.write((uint8_t*)buf, sizeof(buf));   // DMA 가 비면 대기 (블로킹)
    }
  }

  static bool begin() {
    pinMode(PIN_AMP_EN, OUTPUT);
    ampOn(false);
    // 스피커(DOUT)와 마이크(DIN)를 같은 I2S 로 함께 씁니다 (마이크는 mic.h 에서 읽음)
    i2s.setPins(PIN_I2S_BCLK, PIN_I2S_LRCK, PIN_I2S_DOUT, PIN_I2S_DIN, PIN_I2S_MCLK);
    if (!i2s.begin(I2S_MODE_STD, AUDIO_SAMPLE_RATE, I2S_DATA_BIT_WIDTH_16BIT,
                   I2S_SLOT_MODE_STEREO)) {
      Serial.println("[SFX] I2S 시작 실패");
      return false;
    }
    delay(5);
    if (!ES8311::begin()) {
      Serial.println("[SFX] ES8311 코덱 응답 없음");
    }
    queue = xQueueCreate(8, sizeof(uint8_t));
    xTaskCreatePinnedToCore(task, "sfx", 4096, nullptr, 3, nullptr, 0);
    ampOn(true);
    ready = true;
    return true;
  }

  static void play(uint8_t id) {
    if (!ready || gain == 0) return;
    xQueueSend(queue, &id, 0);
  }

  static void setGain(uint8_t g) { gain = g; }

  // 지금 소리가 나는 중이거나, 끝난 지 ms 밀리초가 안 됐으면 true
  static bool recentlyPlayed(uint32_t ms = 250) {
    return playing || (millis() - quietSince < ms);
  }
}
