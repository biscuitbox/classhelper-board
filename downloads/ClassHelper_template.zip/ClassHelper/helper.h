// =====================================================================
//  helper.h  —  모든 앱이 함께 쓰는 것: 화면(lcd), 색, 단추 그리기, '앱 약속'
//
//  ┌───────────────────────── 앱 약속 ─────────────────────────┐
//  │ 앱 하나 = 파일 하나 (app_mine.h / app_noise.h / app_presenter.h) │
//  │ 파일 안은 namespace 하나로 감싸고, 아래 4개 함수를 만듭니다.      │
//  │                                                                │
//  │   void start()   ① 앱에 들어올 때 — 화면 전체를 처음부터 그린다   │
//  │   void update()  ② 계속 반복(1초에 약 100번) — 시계·센서·애니메이션 │
//  │   void touch(uint8_t ev, int x, int y)                         │
//  │                  ③ 터치 — ev 는 TOUCH_DOWN / TOUCH_MOVE / TOUCH_UP │
//  │   void stop()    ④ 나갈 때 — 마이크 끄기, 키 떼기 같은 정리       │
//  │                                                                │
//  │ 파일 맨 끝에 앱 정보(App)를 하나 적습니다. 예)                   │
//  │   const App app = { "지뢰찾기", "심심할 때 한 판", C_MINE, icon,  │
//  │                     start, update, touch, stop,                │
//  │                     nullptr,   // BOOT 버튼 (안 쓰면 nullptr)   │
//  │                     false,     // true = 이 앱에서는 절전 안 함   │
//  │                     true };    // true = 완성 (false = 회색 칸)   │
//  │                                                                │
//  │ 화면 규칙                                                       │
//  │  - 화면은 세로 240 x 320. 왼쪽 위 (0,0)~(43,29) 는 🏠 자리.      │
//  │    start() 에서 drawHomeButton() 을 꼭 불러 주세요.             │
//  │    이 자리의 터치는 앱으로 오지 않습니다 (길게 누르면 첫 화면).   │
//  │  - 글자: 한글은 fonts::efontKR_12 / 16 / 24 (굵게는 _b)          │
//  │  - 이모지는 화면에 안 나옵니다. 아이콘은 도형으로 그리세요.       │
//  │  - delay() 를 길게 쓰지 마세요 (터치가 멈춤). millis() 로 시간 재기. │
//  │                                                                │
//  │ 함께 쓸 수 있는 도구                                             │
//  │  - 소리 : Sfx::play(SFX_TAP)   (sfx.h 에 소리 목록)              │
//  │  - 마이크 : Mic::start() / Mic::hasNew() / Mic::db() / Mic::stop() │
//  │  - 블루투스 키보드·마우스 : Hid::key(...) 등 (ble_hid.h 참고)    │
//  │  - 저장 : Preferences (앱마다 다른 이름표로 prefs.begin("이름"))   │
//  └────────────────────────────────────────────────────────────────┘
// =====================================================================
#pragma once
#include <Arduino.h>
#include <Preferences.h>
#include "config.h"
#include "lgfx_es3c28p.h"

static LGFX lcd;                 // 화면. 모든 앱이 이 이름으로 그립니다.

// ------------------------------ 터치 신호 ------------------------------
enum : uint8_t { TOUCH_DOWN = 1, TOUCH_MOVE = 2, TOUCH_UP = 3 };

// ------------------------------ 앱 정보 ------------------------------
struct App {
  const char* name;                          // 첫 화면 단추 이름
  const char* desc;                          // 단추 아래 한 줄 설명
  uint16_t    color;                         // 단추 색
  void (*icon)(int cx, int cy);              // 아이콘 (가운데 좌표, 약 36px 안에)
  void (*start)();
  void (*update)();
  void (*touch)(uint8_t ev, int x, int y);
  void (*stop)();
  void (*button)();                          // 뒷면 BOOT 버튼 짧게 (없으면 nullptr)
  bool keepAwake;                            // true = 이 앱에서는 자동 절전 안 함
  bool ready;                                // false = 첫 화면에 회색 "다음 시간에"
};

// ------------------------------ 색 (RGB565) ------------------------------
#define C_BLACK   0x0000
#define C_WHITE   0xFFFF
#define C_GRAY    0xC618
#define C_DARK    0x7BEF
#define C_LIGHT   0xE71C
#define C_RED     0xF800
#define C_YELLOW  0xFFE0
#define C_BG      0x18E3     // 첫 화면 바탕 (짙은 남회색)
#define C_BAR     0x10A6     // 위쪽 제목줄 남색
#define C_ACCENT  0x2A9F     // 선택된 단추 파랑
#define C_MINE    0x5AEB     // 지뢰찾기 단추
#define C_NOISE   0x2589     // 소음 신호등 단추 (초록)
#define C_PRES    0xE3E5     // 프레젠터 단추 (주황)
#define C_GO      0x05E0     // 신호등 초록
#define C_WAIT    0xFE00     // 신호등 노랑
#define C_STOP    0xE8E4     // 신호등 빨강

static inline uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) { return lcd.color565(r, g, b); }

// ------------------------------ 시스템 설정 ------------------------------
//  (설정 화면에서 바꾸는 값. 앱에서도 읽을 수 있어요: Sys::cfg.vol 등)
namespace Sys {
  struct Settings {
    uint8_t vol = 2, bright = 1, sleepIdx = 1, flip = 0, startApp = 0;
  } cfg;
  static const uint8_t  VOL_GAIN[4]   = {0, 70, 150, 255};
  static const uint8_t  BRIGHT_VAL[3] = {45, 130, 255};
  static const uint32_t SLEEP_MS[4]   = {180000, 600000, 1800000, 0}; // 자동 절전 3·10·30분, 0 = 안 함
  static volatile bool  touching = false;   // 지금 손가락이 화면에 닿아 있는지
  static int            battery  = -1;      // 배터리 남은 양 % (-1 = 아직 모름)
}

// =====================================================================
//                         그리기 도구 (UI)
// =====================================================================
// 한글 글자 쓰기: datum 은 textdatum_t::middle_center 처럼
static void text(const char* s, int x, int y, const lgfx::IFont* font, uint16_t color,
                 textdatum_t datum = textdatum_t::middle_center) {
  lcd.setFont(font);
  lcd.setTextSize(1);
  lcd.setTextDatum(datum);
  lcd.setTextColor(color);
  lcd.drawString(s, x, y);
}

// 둥근 단추 (선택되면 파랑 바탕)
static void button(int x, int y, int w, int h, const char* label, bool selected = false,
                   const lgfx::IFont* font = &fonts::efontKR_16, uint16_t face = C_WHITE,
                   uint16_t ink = C_BLACK) {
  uint16_t bg = selected ? C_ACCENT : face;
  lcd.fillRoundRect(x, y, w, h, 6, bg);
  lcd.drawRoundRect(x, y, w, h, 6, selected ? C_ACCENT : C_DARK);
  text(label, x + w / 2, y + h / 2 + 1, font, selected ? C_WHITE : ink);
}

// 누르고 있는 동안 단추가 살짝 눌린 느낌 (테두리만 두껍게)
static void buttonPressed(int x, int y, int w, int h) {
  lcd.drawRoundRect(x, y, w, h, 6, C_ACCENT);
  lcd.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 5, C_ACCENT);
}

// 점(x,y)가 사각형 안에 있나?
static inline bool inside(int x, int y, int rx, int ry, int rw, int rh) {
  return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
}

// 위쪽 제목줄 (왼쪽 🏠 자리 포함)
static void drawHomeButton(uint16_t bg = C_BAR, uint16_t ink = C_WHITE);
static void drawTitleBar(const char* title, uint16_t bg = C_BAR) {
  lcd.fillRect(0, 0, 240, 30, bg);
  text(title, 50, 15, &fonts::efontKR_16_b, C_WHITE, textdatum_t::middle_left);
  drawHomeButton(bg);
}

// 🏠 모양 (집)
static void drawHouse(int cx, int cy, int s, uint16_t c) {
  lcd.fillTriangle(cx - s, cy, cx + s, cy, cx, cy - s, c);
  lcd.fillRect(cx - s * 2 / 3, cy, s * 4 / 3 + 1, s * 3 / 4, c);
}
static void drawHomeButton(uint16_t bg, uint16_t ink) {
  lcd.fillRect(0, 0, 44, 30, bg);
  lcd.drawRoundRect(3, 3, 38, 24, 5, ink);
  drawHouse(22, 15, 7, ink);
}
// 길게 누르는 동안 채워지는 막대 (0.0 ~ 1.0)
static void drawHomeProgress(float p) {
  int w = (int)(34 * p);
  lcd.fillRect(5, 23, w, 3, C_YELLOW);
}

// 배터리 모양 (x,y 는 왼쪽 위, 크기 약 46x12)
static void drawBattery(int x, int y, uint16_t bg, uint16_t ink = C_WHITE) {
  lcd.fillRect(x, y, 48, 14, bg);
  int p = Sys::battery;
  if (p < 0) return;
  lcd.drawRect(x, y + 1, 20, 11, ink);
  lcd.fillRect(x + 20, y + 4, 2, 5, ink);
  uint16_t c = p > 50 ? C_GO : (p > 20 ? C_WAIT : C_STOP);
  lcd.fillRect(x + 2, y + 3, 16 * p / 100, 7, c);
  char b[6];
  snprintf(b, sizeof(b), "%d%%", p);
  text(b, x + 25, y + 7, &fonts::Font0, ink, textdatum_t::middle_left);
}

// 화면 아래 잠깐 뜨는 안내
static void toast(const char* msg, uint16_t bg = C_BAR) {
  int w = 228, h = 34, x = 6, y = 240;
  lcd.fillRoundRect(x, y, w, h, 6, bg);
  text(msg, 120, y + h / 2, &fonts::efontKR_16, C_WHITE);
}
