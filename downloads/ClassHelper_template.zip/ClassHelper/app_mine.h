// =====================================================================
//  app_mine.h  —  💣 지뢰찾기  (1차시)
//
//  조작
//   - 칸을 누르고 있으면 눌린 칸이 표시됨 → 손가락을 밀어 위치를 고친 뒤 떼면 실행
//   - 짧게 탭  : 현재 모드 동작 (열기 모드 = 열기 / 깃발 모드 = 깃발)
//   - 길게 누름: 반대 동작 (열기 모드에서 길게 = 깃발)
//   - 숫자 칸 탭: 주변 깃발 수가 맞으면 나머지 칸을 한 번에 열기
//   - 위쪽 얼굴: 새 게임  /  아래 왼쪽: 모드 전환  /  아래 오른쪽: 메뉴
//   - 왼쪽 위 🏠 길게: 첫 화면 (하던 판은 그대로 남아 있어요)
//
//  ✏️ 바이브코딩으로 바꿔 보기 좋은 곳
//   - LEVELS  : 난이도별 칸 수·지뢰 수
//   - 색 (MC_xxx), 숫자 색 NUM_COLOR
//   - 효과음 : Sfx::play(SFX_xxx) 부분
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"

namespace AppMine {

static Preferences prefs;

// ------------------------------ 색상 ------------------------------
#define MC_SEG_ON  0xF800
#define MC_SEG_OFF 0x3000
#define MC_FLAGBG  0xFE4F     // 깃발 모드 버튼 주황

static const uint16_t NUM_COLOR[9] = {
  0, 0x001F, 0x0400, 0xF800, 0x0010, 0x8000, 0x0410, 0x0000, 0x7BEF
};

// ------------------------------ 화면 배치 ------------------------------
#define TOP_H    30
#define BOARD_Y  30
#define BOARD_H  260
#define BOT_Y    290

// ------------------------------ 난이도 ------------------------------
struct Level { uint8_t cols, rows, mines, cell; const char* name; };
static const Level LEVELS[3] = {
  { 8,  8,  9, 30, "쉬움"},
  { 9, 10, 14, 26, "보통"},
  {12, 13, 30, 20, "어려움"},
};
#define MAX_CELLS (12 * 13)

enum : uint8_t { HIDDEN = 0, OPEN = 1, FLAG = 2 };
enum : uint8_t { G_READY, G_PLAY, G_WON, G_LOST };
enum : uint8_t { SCR_GAME, SCR_MENU };
enum : uint8_t { FACE_SMILE, FACE_OH, FACE_COOL, FACE_DEAD };
enum : uint8_t { T_NONE, T_BOARD, T_FACE, T_MODE, T_MENU };

struct Game {
  uint8_t  level, cols, rows, mines, cell;
  int16_t  bx, by;
  uint8_t  mine[MAX_CELLS], adj[MAX_CELLS], st[MAX_CELLS];
  uint8_t  status;
  uint16_t opened;
  int16_t  flags;
  uint32_t startMs, endMs;
  uint16_t elapsedBase;
  int16_t  boomCell;
} g;

static bool     started    = false;   // 한 번이라도 판을 만들었는지
static bool     paused     = true;    // 다른 화면에 가 있는 동안 시계 멈춤
static bool     flagMode   = false;
static uint8_t  screen     = SCR_GAME;
static uint16_t shownTime  = 0xFFFF;
static uint8_t  level      = 0;
static uint16_t best[3]    = {0xFFFF, 0xFFFF, 0xFFFF};   // 0xFFFF = 기록 없음

static void loadPrefs() {
  prefs.begin("mswp", true);
  level = prefs.getUChar("lv", 0);
  if (prefs.getBytesLength("best") == sizeof(best)) prefs.getBytes("best", best, sizeof(best));
  prefs.end();
  if (level > 2) level = 0;
}
static void savePrefs() {
  prefs.begin("mswp", false);
  prefs.putUChar("lv", level);
  prefs.putBytes("best", best, sizeof(best));
  prefs.end();
}

// ------------------------------ RGB LED (보드 뒷면) ------------------------------
enum : uint8_t { LED_OFF, LED_FLASH, LED_BOOM, LED_WIN };
static struct { uint8_t fx = LED_OFF; uint32_t t0 = 0, dur = 0; uint8_t r = 0, g = 0, b = 0; uint32_t last = 0; } led;

static void ledStart(uint8_t fx, uint32_t dur, uint8_t r = 0, uint8_t gg = 0, uint8_t b = 0) {
  led.fx = fx; led.t0 = millis(); led.dur = dur; led.r = r; led.g = gg; led.b = b;
}
static void ledUpdate() {
  if (led.fx == LED_OFF) return;
  uint32_t now = millis();
  if (now - led.last < 20) return;
  led.last = now;
  uint32_t t = now - led.t0;
  if (t >= led.dur) { rgbLedWrite(PIN_WS2812, 0, 0, 0); led.fx = LED_OFF; return; }
  float k = 1.0f - (float)t / led.dur;
  if (led.fx == LED_FLASH) {
    rgbLedWrite(PIN_WS2812, led.r * k, led.g * k, led.b * k);
  } else if (led.fx == LED_BOOM) {
    float p = 0.5f + 0.5f * cosf(t / 55.0f);
    rgbLedWrite(PIN_WS2812, 90 * k * p + 10 * k, 12 * k * p, 0);
  } else {                                   // WIN: 무지개
    float h = fmodf(t / 300.0f, 1.0f) * 6.0f;
    int   i = (int)h; float f = h - i;
    float r = 0, gg = 0, b = 0;
    switch (i) {
      case 0: r = 1; gg = f; break;      case 1: r = 1 - f; gg = 1; break;
      case 2: gg = 1; b = f; break;      case 3: gg = 1 - f; b = 1; break;
      case 4: r = f; b = 1; break;       default: r = 1; b = 1 - f;
    }
    rgbLedWrite(PIN_WS2812, r * 60 * k, gg * 60 * k, b * 60 * k);
  }
}

// =====================================================================
//                              그리기
// =====================================================================
static void bevel(int x, int y, int w, int h, int b, bool raised, uint16_t face) {
  lcd.fillRect(x, y, w, h, face);
  uint16_t tl = raised ? C_WHITE : C_DARK;
  uint16_t br = raised ? C_DARK : C_WHITE;
  for (int i = 0; i < b; i++) {
    lcd.drawFastHLine(x, y + i, w - i, tl);
    lcd.drawFastVLine(x + i, y, h - i, tl);
    lcd.drawFastHLine(x + i + 1, y + h - 1 - i, w - i - 1, br);
    lcd.drawFastVLine(x + w - 1 - i, y + i + 1, h - i - 1, br);
  }
}

static void drawFlagIcon(int x, int y, int s) {
  int px = x + s * 56 / 100;
  int top = y + s * 18 / 100, mid = y + s * 50 / 100, bot = y + s * 74 / 100;
  lcd.fillTriangle(px, top, px, mid, x + s * 20 / 100, (top + mid) / 2, C_RED);
  lcd.drawFastVLine(px, top, bot - top, C_BLACK);
  lcd.drawFastVLine(px + 1, top, bot - top, C_BLACK);
  lcd.fillRect(x + s * 30 / 100, bot, s * 48 / 100, max(2, s / 10), C_BLACK);
}

static void drawMineIcon(int x, int y, int s) {
  int cx = x + s / 2, cy = y + s / 2;
  int r  = s * 26 / 100;
  int l  = r + r / 2, d = r + r / 6;
  lcd.fillRect(cx - l, cy - 1, 2 * l + 1, 2, C_BLACK);
  lcd.fillRect(cx - 1, cy - l, 2, 2 * l + 1, C_BLACK);
  lcd.drawLine(cx - d, cy - d, cx + d, cy + d, C_BLACK);
  lcd.drawLine(cx - d, cy + d, cx + d, cy - d, C_BLACK);
  lcd.fillCircle(cx, cy, r, C_BLACK);
  int gl = max(2, r / 3);
  lcd.fillRect(cx - r / 2, cy - r / 2, gl, gl, C_WHITE);
}

// 첫 화면 단추 아이콘 (가운데 좌표)
static void icon(int cx, int cy) { drawMineIcon(cx - 20, cy - 20, 40); }

static void drawCell(int i, bool pressed) {
  int c = i % g.cols, r = i / g.cols, s = g.cell;
  int x = g.bx + c * s, y = g.by + r * s;
  uint8_t st = g.st[i];
  bool lost      = (g.status == G_LOST);
  bool showMine  = lost && g.mine[i] && st != FLAG;
  bool wrongFlag = lost && st == FLAG && !g.mine[i];
  int  bv = (s >= 24) ? 3 : 2;

  if ((st == HIDDEN && !pressed && !showMine) || (st == FLAG && !wrongFlag)) {
    bevel(x, y, s, s, bv, true, C_GRAY);
    if (st == FLAG) drawFlagIcon(x, y, s);
    return;
  }
  uint16_t bg = (showMine && i == g.boomCell) ? C_RED : C_GRAY;
  lcd.fillRect(x, y, s, s, bg);
  lcd.drawFastHLine(x, y, s, C_DARK);
  lcd.drawFastVLine(x, y, s, C_DARK);
  if (showMine || wrongFlag) {
    drawMineIcon(x, y, s);
    if (wrongFlag) {
      lcd.drawLine(x + 3, y + 3, x + s - 3, y + s - 3, C_RED);
      lcd.drawLine(x + 4, y + 3, x + s - 2, y + s - 3, C_RED);
      lcd.drawLine(x + s - 3, y + 3, x + 3, y + s - 3, C_RED);
      lcd.drawLine(x + s - 2, y + 3, x + 4, y + s - 3, C_RED);
    }
  } else if (st == OPEN && g.adj[i]) {
    lcd.setFont(s >= 24 ? &fonts::FreeSansBold12pt7b : &fonts::FreeSansBold9pt7b);
    lcd.setTextDatum(textdatum_t::middle_center);
    lcd.setTextColor(NUM_COLOR[g.adj[i]]);
    lcd.drawNumber(g.adj[i], x + s / 2 + 1, y + s / 2 + 1);
  }
}

// 7세그먼트 숫자 (11x20)
static const uint8_t SEG7[10] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
static void draw7seg(int x, int y, int d) {
  const int W = 11, H = 20, T = 2;
  uint8_t m = (d >= 0 && d <= 9) ? SEG7[d] : (d == 10 ? 0x40 : 0);
  auto seg = [&](int bit, int sx, int sy, int sw, int sh) {
    lcd.fillRect(sx, sy, sw, sh, ((m >> bit) & 1) ? MC_SEG_ON : MC_SEG_OFF);
  };
  seg(0, x + T, y, W - 2 * T, T);
  seg(1, x + W - T, y + T, T, H / 2 - T - 1);
  seg(2, x + W - T, y + H / 2 + 1, T, H / 2 - T - 1);
  seg(3, x + T, y + H - T, W - 2 * T, T);
  seg(4, x, y + H / 2 + 1, T, H / 2 - T - 1);
  seg(5, x, y + T, T, H / 2 - T - 1);
  seg(6, x + T, y + H / 2 - 1, W - 2 * T, T);
}
static void drawCounter(int x, int val) {
  lcd.fillRect(x, 3, 41, 24, C_BLACK);
  bool neg = val < 0;
  int v = neg ? -val : val;
  if (v > 999) v = 999;
  if (neg && v > 99) v = 99;
  draw7seg(x + 3,  5, neg ? 10 : (v / 100) % 10);
  draw7seg(x + 16, 5, (v / 10) % 10);
  draw7seg(x + 29, 5, v % 10);
}

static uint16_t elapsedSec() {
  uint32_t e = g.elapsedBase;
  if (g.status == G_PLAY && screen == SCR_GAME && !paused) e += (millis() - g.startMs) / 1000;
  return e > 999 ? 999 : e;
}
static void drawMineCounter() { drawCounter(50, g.mines - g.flags); }   // 왼쪽 0~43 은 🏠 자리
static void drawTimer()       { drawCounter(240 - 4 - 41, elapsedSec()); }

static uint8_t curFace() {
  return g.status == G_WON ? FACE_COOL : (g.status == G_LOST ? FACE_DEAD : FACE_SMILE);
}
static void drawFace(uint8_t f, bool pressed = false) {
  int x = 107, y = 2;
  bevel(x, y, 26, 26, 2, !pressed, C_GRAY);
  int cx = x + 13 + (pressed ? 1 : 0), cy = y + 13 + (pressed ? 1 : 0);
  lcd.fillCircle(cx, cy, 10, C_YELLOW);
  lcd.drawCircle(cx, cy, 10, C_BLACK);
  switch (f) {
    case FACE_SMILE:
      lcd.fillRect(cx - 5, cy - 4, 2, 3, C_BLACK);
      lcd.fillRect(cx + 3, cy - 4, 2, 3, C_BLACK);
      lcd.fillArc(cx, cy, 6, 5, 25, 155, C_BLACK);
      break;
    case FACE_OH:
      lcd.fillRect(cx - 5, cy - 5, 2, 3, C_BLACK);
      lcd.fillRect(cx + 3, cy - 5, 2, 3, C_BLACK);
      lcd.drawCircle(cx, cy + 4, 2, C_BLACK);
      break;
    case FACE_COOL:
      lcd.fillRect(cx - 8, cy - 5, 7, 4, C_BLACK);
      lcd.fillRect(cx + 1, cy - 5, 7, 4, C_BLACK);
      lcd.drawFastHLine(cx - 10, cy - 4, 21, C_BLACK);
      lcd.fillArc(cx, cy, 6, 5, 25, 155, C_BLACK);
      break;
    default:   // DEAD
      lcd.drawLine(cx - 6, cy - 6, cx - 2, cy - 2, C_BLACK);
      lcd.drawLine(cx - 2, cy - 6, cx - 6, cy - 2, C_BLACK);
      lcd.drawLine(cx + 2, cy - 6, cx + 6, cy - 2, C_BLACK);
      lcd.drawLine(cx + 6, cy - 6, cx + 2, cy - 2, C_BLACK);
      lcd.fillArc(cx, cy + 9, 6, 5, 215, 325, C_BLACK);
  }
}

static void drawModeButton(bool pressed) {
  int x = 4, y = BOT_Y + 3, w = 104, h = 25;
  bevel(x, y, w, h, 2, !pressed, flagMode ? MC_FLAGBG : C_GRAY);
  int o = pressed ? 1 : 0;
  if (flagMode) {
    drawFlagIcon(x + 3 + o, y + 1 + o, 22);
  } else {                                     // 열린 칸 모양 아이콘
    lcd.fillRect(x + 7 + o, y + 4 + o, 17, 17, C_GRAY);
    lcd.drawRect(x + 7 + o, y + 4 + o, 17, 17, C_DARK);
    lcd.setFont(&fonts::FreeSansBold9pt7b);
    lcd.setTextDatum(textdatum_t::middle_center);
    lcd.setTextColor(NUM_COLOR[1]);
    lcd.drawString("1", x + 16 + o, y + 13 + o);
  }
  text(flagMode ? "깃발 모드" : "열기 모드", x + 28 + o, y + 13 + o, &fonts::efontKR_16,
       flagMode ? 0x8000 : C_BLACK, textdatum_t::middle_left);
}

static void drawMenuButton(bool pressed) {
  int x = 180, y = BOT_Y + 3, w = 56, h = 25;
  bevel(x, y, w, h, 2, !pressed, C_GRAY);
  int o = pressed ? 1 : 0;
  text("메뉴", x + w / 2 + o, y + 13 + o, &fonts::efontKR_16, C_BLACK);
}

static void drawLevelName() {
  lcd.fillRect(110, BOT_Y + 2, 68, 27, C_GRAY);
  text(LEVELS[g.level].name, 144, BOT_Y + 16, &fonts::efontKR_14, C_BAR);
}

static void drawBanner(const char* l1, const char* l2) {
  int w = 190, h = 62, x = (240 - w) / 2, y = BOARD_Y + (BOARD_H - h) / 2;
  lcd.fillRoundRect(x + 3, y + 3, w, h, 8, C_DARK);
  lcd.fillRoundRect(x, y, w, h, 8, C_WHITE);
  lcd.drawRoundRect(x, y, w, h, 8, C_BLACK);
  text(l1, 120, y + 20, &fonts::efontKR_16_b, C_ACCENT);
  text(l2, 120, y + 43, &fonts::efontKR_16, C_BLACK);
}

static void drawGameScreen() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  lcd.drawFastHLine(0, TOP_H - 1, 240, C_DARK);
  drawHomeButton(C_GRAY, C_BAR);
  drawMineCounter();
  shownTime = elapsedSec();
  drawTimer();
  drawFace(curFace());
  for (int i = 0; i < g.cols * g.rows; i++) drawCell(i, false);
  drawModeButton(false);
  drawLevelName();
  drawMenuButton(false);
  lcd.endWrite();
}

// =====================================================================
//                              게임 로직
// =====================================================================
static void setupLevel(uint8_t lv) {
  const Level& L = LEVELS[lv];
  g.level = lv; g.cols = L.cols; g.rows = L.rows; g.mines = L.mines; g.cell = L.cell;
  g.bx = (240 - g.cols * g.cell) / 2;
  g.by = BOARD_Y + (BOARD_H - g.rows * g.cell) / 2;
}

static void computeAdj() {
  for (int r = 0; r < g.rows; r++)
    for (int c = 0; c < g.cols; c++) {
      int n = 0;
      for (int dr = -1; dr <= 1; dr++)
        for (int dc = -1; dc <= 1; dc++) {
          int rr = r + dr, cc = c + dc;
          if ((dr || dc) && rr >= 0 && rr < g.rows && cc >= 0 && cc < g.cols) n += g.mine[rr * g.cols + cc];
        }
      g.adj[r * g.cols + c] = n;
    }
}

static void placeMines(int safe) {
  int sc = safe % g.cols, sr = safe / g.cols, n = g.cols * g.rows, placed = 0;
  while (placed < g.mines) {
    int i = esp_random() % n;
    int c = i % g.cols, r = i / g.cols;
    if (g.mine[i] || (abs(c - sc) <= 1 && abs(r - sr) <= 1)) continue;   // 첫 칸 주변은 항상 안전
    g.mine[i] = 1; placed++;
  }
  computeAdj();
}

static void newGame(uint8_t lv, bool sound = true) {
  setupLevel(lv);
  memset(g.mine, 0, sizeof(g.mine));
  memset(g.adj, 0, sizeof(g.adj));
  memset(g.st, HIDDEN, sizeof(g.st));
  g.status = G_READY; g.opened = 0; g.flags = 0; g.elapsedBase = 0; g.boomCell = -1;
  started = true;
  drawGameScreen();
  if (sound) Sfx::play(SFX_START);
}

// 연쇄 열기 (빈칸이면 주변까지). 연 칸 수를 돌려줌
static int floodOpen(int start) {
  static int16_t stack[MAX_CELLS];
  if (g.st[start] != HIDDEN) return 0;
  int sp = 0, count = 0;
  g.st[start] = OPEN; g.opened++; count++; drawCell(start, false);
  if (g.adj[start] == 0) stack[sp++] = start;
  while (sp) {
    int i = stack[--sp], c = i % g.cols, r = i / g.cols;
    for (int dr = -1; dr <= 1; dr++)
      for (int dc = -1; dc <= 1; dc++) {
        int rr = r + dr, cc = c + dc;
        if ((!dr && !dc) || rr < 0 || rr >= g.rows || cc < 0 || cc >= g.cols) continue;
        int j = rr * g.cols + cc;
        if (g.st[j] != HIDDEN || g.mine[j]) continue;
        g.st[j] = OPEN; g.opened++; count++; drawCell(j, false);
        if (g.adj[j] == 0) stack[sp++] = j;
      }
  }
  return count;
}

static void lose(int i) {
  g.elapsedBase = elapsedSec();
  g.status = G_LOST; g.boomCell = i; g.endMs = millis();
  lcd.startWrite();
  for (int k = 0; k < g.cols * g.rows; k++)
    if ((g.mine[k] && g.st[k] != FLAG) || (g.st[k] == FLAG && !g.mine[k])) drawCell(k, false);
  drawFace(FACE_DEAD);
  lcd.endWrite();
  Sfx::play(SFX_BOOM);
  ledStart(LED_BOOM, 1400);
}

static void checkWin() {
  if (g.status != G_PLAY || g.opened != g.cols * g.rows - g.mines) return;
  g.elapsedBase = elapsedSec();
  g.status = G_WON; g.endMs = millis();
  lcd.startWrite();
  for (int k = 0; k < g.cols * g.rows; k++)
    if (g.mine[k] && g.st[k] != FLAG) { g.st[k] = FLAG; drawCell(k, false); }
  g.flags = g.mines;
  drawMineCounter();
  drawTimer();
  drawFace(FACE_COOL);
  uint16_t t = g.elapsedBase;
  bool record = (t < best[g.level]);
  if (record) { best[g.level] = t; savePrefs(); }
  char l2[40];
  snprintf(l2, sizeof(l2), record ? "%u초 · 신기록!" : "%u초 걸렸어요", (unsigned)t);
  drawBanner(record ? "축하해요! 성공!" : "성공!", l2);
  lcd.endWrite();
  Sfx::play(record ? SFX_RECORD : SFX_WIN);
  ledStart(LED_WIN, 2600);
}

static void doReveal(int i) {
  if (g.st[i] != HIDDEN) return;
  if (g.status == G_READY) {
    placeMines(i);
    g.status = G_PLAY; g.startMs = millis(); g.elapsedBase = 0;
  }
  if (g.mine[i]) { lose(i); return; }
  lcd.startWrite();
  int n = floodOpen(i);
  lcd.endWrite();
  Sfx::play(n > 1 ? SFX_FLOOD : SFX_OPEN);
  checkWin();
}

static void doChord(int i) {
  if (g.st[i] != OPEN || g.adj[i] == 0 || g.status != G_PLAY) return;
  int c = i % g.cols, r = i / g.cols, fl = 0, hidden = 0;
  for (int dr = -1; dr <= 1; dr++)
    for (int dc = -1; dc <= 1; dc++) {
      int rr = r + dr, cc = c + dc;
      if ((!dr && !dc) || rr < 0 || rr >= g.rows || cc < 0 || cc >= g.cols) continue;
      uint8_t s = g.st[rr * g.cols + cc];
      if (s == FLAG) fl++; else if (s == HIDDEN) hidden++;
    }
  if (hidden == 0) return;
  if (fl != g.adj[i]) { Sfx::play(SFX_ERROR); return; }
  int boom = -1, total = 0;
  lcd.startWrite();
  for (int dr = -1; dr <= 1; dr++)
    for (int dc = -1; dc <= 1; dc++) {
      int rr = r + dr, cc = c + dc;
      if ((!dr && !dc) || rr < 0 || rr >= g.rows || cc < 0 || cc >= g.cols) continue;
      int j = rr * g.cols + cc;
      if (g.st[j] != HIDDEN) continue;
      if (g.mine[j]) boom = j; else total += floodOpen(j);
    }
  lcd.endWrite();
  if (boom >= 0) { lose(boom); return; }
  if (total) Sfx::play(SFX_CHORD);
  checkWin();
}

static void toggleFlag(int i) {
  if (g.status == G_WON || g.status == G_LOST) return;
  if (g.st[i] == HIDDEN)    { g.st[i] = FLAG;   g.flags++; Sfx::play(SFX_FLAG); ledStart(LED_FLASH, 250, 0, 20, 70); }
  else if (g.st[i] == FLAG) { g.st[i] = HIDDEN; g.flags--; Sfx::play(SFX_UNFLAG); }
  else return;
  lcd.startWrite();
  drawCell(i, false);
  drawMineCounter();
  lcd.endWrite();
}

// =====================================================================
//                              입력 처리
// =====================================================================
static struct {
  uint32_t t0 = 0; uint8_t target = T_NONE; int16_t cell = -1; bool consumed = false;
} tp;

static int16_t cellAt(int x, int y) {
  const int tol = 6;                         // 판 가장자리 살짝 밖도 허용
  int w = g.cols * g.cell, h = g.rows * g.cell;
  if (x < g.bx - tol || x >= g.bx + w + tol || y < g.by - tol || y >= g.by + h + tol) return -1;
  int c = constrain((x - g.bx) / g.cell, 0, g.cols - 1);
  int r = constrain((y - g.by) / g.cell, 0, g.rows - 1);
  if (x < g.bx) c = 0;
  if (y < g.by) r = 0;
  return r * g.cols + c;
}

static bool gameActive() { return g.status == G_READY || g.status == G_PLAY; }

// 누르고 있는 동안 '눌린 칸' 표시
static int16_t pressedList[9];
static uint8_t pressedN = 0;

static void setPressedFor(int16_t cell) {
  int16_t nl[9]; uint8_t nn = 0;
  if (cell >= 0 && gameActive()) {
    if (g.st[cell] == HIDDEN) nl[nn++] = cell;
    else if (g.st[cell] == OPEN && g.adj[cell]) {
      int c = cell % g.cols, r = cell / g.cols;
      for (int dr = -1; dr <= 1; dr++)
        for (int dc = -1; dc <= 1; dc++) {
          int rr = r + dr, cc = c + dc;
          if ((!dr && !dc) || rr < 0 || rr >= g.rows || cc < 0 || cc >= g.cols) continue;
          int j = rr * g.cols + cc;
          if (g.st[j] == HIDDEN) nl[nn++] = j;
        }
    }
  }
  lcd.startWrite();
  for (int a = 0; a < pressedN; a++) {
    bool keep = false;
    for (int b = 0; b < nn; b++) if (nl[b] == pressedList[a]) keep = true;
    if (!keep) drawCell(pressedList[a], false);
  }
  for (int b = 0; b < nn; b++) {
    bool had = false;
    for (int a = 0; a < pressedN; a++) if (pressedList[a] == nl[b]) had = true;
    if (!had) drawCell(nl[b], true);
  }
  lcd.endWrite();
  memcpy(pressedList, nl, sizeof(nl));
  pressedN = nn;
}
static void clearPressed() { setPressedFor(-1); }

static void shortAction(int i) {
  if (!flagMode) {
    if (g.st[i] == HIDDEN) doReveal(i);
    else if (g.st[i] == OPEN) doChord(i);
  } else {
    if (g.st[i] != OPEN) toggleFlag(i);
    else doChord(i);
  }
}
static void longAction(int i) {
  if (!flagMode) {
    if (g.st[i] != OPEN) toggleFlag(i);
    else doChord(i);
  } else {
    if (g.st[i] == HIDDEN) doReveal(i);
    else if (g.st[i] == FLAG) toggleFlag(i);
    else doChord(i);
  }
}

static void openMenu();
static void menuUp(int x, int y);

static void gameDown(int x, int y) {
  tp.consumed = false; tp.t0 = millis(); tp.cell = -1;
  if (y < TOP_H) {
    if (x >= 98 && x <= 142) { tp.target = T_FACE; drawFace(curFace(), true); }
    else tp.target = T_NONE;
  } else if (y >= BOT_Y - 4) {
    if (x < 110)       { tp.target = T_MODE; drawModeButton(true); }
    else if (x >= 176) { tp.target = T_MENU; drawMenuButton(true); }
    else tp.target = T_NONE;
  } else {
    tp.target = T_BOARD;
    tp.cell = cellAt(x, y);
    if (gameActive()) { setPressedFor(tp.cell); drawFace(FACE_OH); }
  }
}

static void gameMove(int x, int y) {
  if (tp.target != T_BOARD) return;
  int16_t c = cellAt(x, y);
  if (c != tp.cell) {
    tp.cell = c; tp.t0 = millis();
    if (!tp.consumed && gameActive()) setPressedFor(c);
  }
}

static void gameHold() {
  if (tp.target == T_BOARD && !tp.consumed && gameActive() && tp.cell >= 0 &&
      millis() - tp.t0 >= LONG_PRESS_MS) {
    tp.consumed = true;
    clearPressed();
    longAction(tp.cell);
    if (gameActive()) drawFace(FACE_SMILE);
  }
}

static void gameUp(int x, int y) {
  switch (tp.target) {
    case T_FACE:
      newGame(level);
      break;
    case T_MODE:
      flagMode = !flagMode;
      drawModeButton(false);
      Sfx::play(SFX_TAP);
      break;
    case T_MENU:
      drawMenuButton(false);
      Sfx::play(SFX_TAP);
      openMenu();
      break;
    case T_BOARD:
      if (!gameActive()) {                       // 끝난 판을 탭하면 새 게임
        if (millis() - g.endMs > 700) newGame(level);
        break;
      }
      clearPressed();
      if (!tp.consumed && tp.cell >= 0) shortAction(tp.cell);
      if (gameActive()) drawFace(FACE_SMILE);
      break;
  }
  tp.target = T_NONE;
}

// =====================================================================
//                              메뉴 화면
// =====================================================================
static uint8_t levelAtOpen = 0;
static const char* LEVEL_NAMES[3] = {"쉬움", "보통", "어려움"};

static void drawLevelRow() {
  lcd.fillRect(0, 40, 240, 50, C_GRAY);
  text("난이도 (바꾸면 새 게임)", 6, 48, &fonts::efontKR_12, C_BAR, textdatum_t::middle_left);
  for (int i = 0; i < 3; i++) button(4 + i * 78, 58, 74, 30, LEVEL_NAMES[i], i == level);
}

static void drawMenu() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  drawTitleBar("지뢰찾기 메뉴");
  drawLevelRow();

  text("최고 기록", 6, 112, &fonts::efontKR_12, C_BAR, textdatum_t::middle_left);
  for (int i = 0; i < 3; i++) {
    char b[24];
    if (best[i] == 0xFFFF) snprintf(b, sizeof(b), "%s  -", LEVEL_NAMES[i]);
    else snprintf(b, sizeof(b), "%s  %u초", LEVEL_NAMES[i], (unsigned)best[i]);
    text(b, 20, 136 + i * 24, &fonts::efontKR_16, C_BLACK, textdatum_t::middle_left);
  }
  drawMineIcon(160, 120, 64);

  button(4,   244, 112, 34, "새 게임");
  button(124, 244, 112, 34, "기록 지우기");
  button(4,   284, 232, 32, "게임으로 돌아가기", true);
  lcd.endWrite();
}

static void openMenu() {
  if (g.status == G_PLAY) g.elapsedBase = elapsedSec();     // 시계 멈춤
  screen = SCR_MENU;
  levelAtOpen = level;
  drawMenu();
}

static void closeMenu(bool forceNew = false) {
  savePrefs();
  screen = SCR_GAME;
  if (forceNew || level != levelAtOpen) { newGame(level); return; }
  if (g.status == G_PLAY) g.startMs = millis();               // 시계 다시
  drawGameScreen();
  if (g.status == G_WON) drawBanner("성공!", "얼굴을 누르면 새 게임");
}

static void menuUp(int x, int y) {
  if (inside(x, y, 0, 54, 240, 38)) {
    level = constrain(x / 80, 0, 2);
    drawLevelRow();
    Sfx::play(SFX_TAP);
  } else if (inside(x, y, 4, 244, 112, 34)) {
    Sfx::play(SFX_TAP); closeMenu(true);
  } else if (inside(x, y, 124, 244, 112, 34)) {
    for (auto& b : best) b = 0xFFFF;
    savePrefs(); Sfx::play(SFX_UNFLAG); drawMenu();
  } else if (y >= 282) {
    Sfx::play(SFX_TAP); closeMenu();
  }
}

// =====================================================================
//                     앱 약속 4가지 (교탁 도우미가 부름)
// =====================================================================
static void start() {
  static bool loaded = false;
  if (!loaded) { loadPrefs(); loaded = true; }
  screen = SCR_GAME;
  paused = false;
  tp.target = T_NONE; pressedN = 0;
  if (!started) { newGame(level, false); return; }
  if (g.status == G_PLAY) g.startMs = millis();             // 하던 판 이어서
  drawGameScreen();
  if (g.status == G_WON) drawBanner("성공!", "얼굴을 누르면 새 게임");
}

static void update() {
  if (screen == SCR_GAME) {
    if (Sys::touching) gameHold();
    if (g.status == G_PLAY) {
      uint16_t e = elapsedSec();
      if (e != shownTime) { shownTime = e; drawTimer(); }
    }
  }
  ledUpdate();
}

static void touch(uint8_t ev, int x, int y) {
  if (screen == SCR_GAME) {
    if (ev == TOUCH_DOWN) gameDown(x, y);
    else if (ev == TOUCH_MOVE) gameMove(x, y);
    else gameUp(x, y);
  } else if (ev == TOUCH_UP) {
    menuUp(x, y);
  }
}

static void stop() {
  if (screen == SCR_GAME && g.status == G_PLAY) g.elapsedBase = elapsedSec();
  paused = true;
  savePrefs();
  rgbLedWrite(PIN_WS2812, 0, 0, 0);
  led.fx = LED_OFF;
}

const App app = {
  "지뢰찾기", "쉬는 시간에 한 판", C_MINE, icon,
  start, update, touch, stop,
  nullptr,   // BOOT 버튼: 안 씀
  false,     // 자동 절전: 함
  true       // 완성!
};

}  // namespace AppMine
