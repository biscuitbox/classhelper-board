// =====================================================================
//  clock_time.h  —  시계용 시간 도구 (한국 시간 KST)
//
//  이 보드에는 따로 시계 칩(RTC)이 없습니다. 그래서 세 겹으로 시간을 지킵니다.
//   ① 시계 모듈(DS3231, 동전 전지 포함)을 I2C 단자에 꽂으면 저절로 찾아서 씁니다.
//      → 배터리가 다 닳아 꺼져도 시간이 그대로 (가장 확실)
//   ② 시간을 30분마다 보드 저장공간에 적어 둡니다. 꺼졌다 켜지면 마지막으로 적은
//      시간부터 다시 가고, 화면에 "시간 확인"이 뜹니다 (꺼져 있던 동안은 빠짐).
//   ③ config.h 에서 CLOCK_WIFI 를 1 로 하면 인터넷 시간으로 맞춥니다.
//  · 절전 중에도 시간은 흐르지만 조금씩 어긋날 수 있습니다(하루 몇 분).
//
//  📁 이 파일은 고치지 않아도 됩니다.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <time.h>
#include <sys/time.h>
#include <Wire.h>
#include <Preferences.h>
#include "config.h"
#if CLOCK_WIFI
  #include <WiFi.h>
  #include "esp_sntp.h"
#endif

namespace ClockTime {

static void useKoreaTime() {
  static bool done = false;
  if (!done) { setenv("TZ", "KST-9", 1); tzset(); done = true; }
}
static time_t now() { useKoreaTime(); return time(nullptr); }
static bool   valid() { return now() > 1735657200; }          // 2025-01-01 이후면 맞춘 시간
static void   setSystem(time_t t) { timeval tv = {t, 0}; settimeofday(&tv, nullptr); }
static void   local(time_t t, struct tm& out) { useKoreaTime(); localtime_r(&t, &out); }
static time_t make(struct tm& t) { useKoreaTime(); t.tm_isdst = 0; return mktime(&t); }

// ---------- ① 시계 모듈 DS3231 (I2C 주소 0x68, 있으면 씀) ----------
static const uint8_t RTC_ADDR = 0x68;
static bool rtcFound = false;
static uint8_t bcd2dec(uint8_t b) { return (b >> 4) * 10 + (b & 0x0F); }
static uint8_t dec2bcd(uint8_t d) { return ((d / 10) << 4) | (d % 10); }
static bool rtcRead(time_t& out) {
  Wire.beginTransmission(RTC_ADDR); Wire.write(0x0F);            // 상태: 멈춘 적 있으면(OSF) 못 믿음
  if (Wire.endTransmission(false) != 0 || Wire.requestFrom(RTC_ADDR, (uint8_t)1) != 1) return false;
  if (Wire.read() & 0x80) return false;
  Wire.beginTransmission(RTC_ADDR); Wire.write(0x00);
  if (Wire.endTransmission(false) != 0 || Wire.requestFrom(RTC_ADDR, (uint8_t)7) != 7) return false;
  uint8_t r[7]; for (int i = 0; i < 7; i++) r[i] = Wire.read();
  struct tm t = {};
  t.tm_sec  = bcd2dec(r[0] & 0x7F);
  t.tm_min  = bcd2dec(r[1] & 0x7F);
  if (r[2] & 0x40) { int h = bcd2dec(r[2] & 0x1F) % 12; t.tm_hour = h + ((r[2] & 0x20) ? 12 : 0); }  // 12시간 방식
  else t.tm_hour = bcd2dec(r[2] & 0x3F);
  t.tm_mday = bcd2dec(r[4] & 0x3F);
  t.tm_mon  = bcd2dec(r[5] & 0x1F) - 1;
  t.tm_year = bcd2dec(r[6]) + 100;                                 // 2000년 + 
  if (t.tm_year < 125 || t.tm_mon < 0 || t.tm_mon > 11 || t.tm_mday < 1) return false;
  out = make(t);
  return true;
}
static void rtcWrite(time_t when) {
  if (!rtcFound) return;
  struct tm t; local(when, t);
  Wire.beginTransmission(RTC_ADDR);
  Wire.write(0x00);
  Wire.write(dec2bcd(t.tm_sec)); Wire.write(dec2bcd(t.tm_min)); Wire.write(dec2bcd(t.tm_hour));   // 24시간 방식
  Wire.write(dec2bcd(t.tm_wday + 1)); Wire.write(dec2bcd(t.tm_mday));
  Wire.write(dec2bcd(t.tm_mon + 1)); Wire.write(dec2bcd(t.tm_year - 100));
  Wire.endTransmission();
  Wire.beginTransmission(RTC_ADDR); Wire.write(0x0F); Wire.write(0x00); Wire.endTransmission();  // 멈춤 표시 지움
}

// ---------- ② 보드 저장공간에 적어 두기 ----------
static bool restored = false;                  // 저장해 둔 시간으로 되살림 → 확인 필요
static uint32_t lastSaveMs = 0;
static void save() {
  if (!valid()) return;
  Preferences p; p.begin("clocktime", false);
  p.putUInt("t", (uint32_t)now());
  p.end();
  lastSaveMs = millis();
}

// 시간을 새로 맞춤 (화면에서 맞추기 / 인터넷 시간): 보드·시계 모듈·저장공간 모두
static void set(time_t t) {
  setSystem(t);
  rtcWrite(t);
  restored = false;
  save();
}
static bool needsCheck() { return restored; }
static bool hasRtc() { return rtcFound; }

// setup() 에서 한 번 (Wire.begin 다음): 시간 되살리기
static void begin() {
  useKoreaTime();
  Wire.beginTransmission(RTC_ADDR);
  rtcFound = (Wire.endTransmission() == 0);
  time_t t;
  if (rtcFound && rtcRead(t)) { setSystem(t); restored = false; return; }   // ① 시계 모듈이 제일 정확
  if (valid()) return;                         // 절전에서 깨어남 → 시간이 계속 흘렀음
  Preferences p; p.begin("clocktime", true);
  uint32_t saved = p.getUInt("t", 0);
  p.end();
  if (saved > 1735657200UL) { setSystem((time_t)saved); restored = true; }  // ② 마지막으로 적어 둔 시간부터
}

// loop() 에서 계속: 30분마다 적어 두기
static void tick() {
  if (valid() && millis() - lastSaveMs > 30UL * 60 * 1000) save();
}

// ---------- 인터넷 시간 ----------
enum SyncState { SYNC_OFF, SYNC_IDLE, SYNC_WIFI, SYNC_NTP, SYNC_OK, SYNC_FAIL };
static SyncState syncState = CLOCK_WIFI ? SYNC_IDLE : SYNC_OFF;
static uint32_t  syncT0 = 0, lastOk = 0;

static bool wifiReady() { return CLOCK_WIFI && strlen(WIFI_SSID) > 0; }
static bool busy() { return syncState == SYNC_WIFI || syncState == SYNC_NTP; }

#if CLOCK_WIFI
static void wifiOff() {
  esp_sntp_stop();
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);                       // 블루투스와 배터리를 위해 다 맞추면 바로 끔
}
#endif

static void startSync() {
#if CLOCK_WIFI
  if (!wifiReady() || busy()) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  syncState = SYNC_WIFI;
  syncT0 = millis();
#endif
}

// 시계 화면에서 계속 부름: 연결 → 시간 받기 → 와이파이 끄기
static void poll() {
#if CLOCK_WIFI
  if (syncState == SYNC_WIFI) {
    if (WiFi.status() == WL_CONNECTED) {
      configTzTime("KST-9", "pool.ntp.org", "time.google.com", "time.windows.com");
      syncState = SYNC_NTP; syncT0 = millis();
    } else if (millis() - syncT0 > 20000) { wifiOff(); syncState = SYNC_FAIL; }
  } else if (syncState == SYNC_NTP) {
    if (sntp_get_sync_status() == SNTP_SYNC_STATUS_COMPLETED && valid()) {
      wifiOff(); syncState = SYNC_OK; lastOk = millis();
      rtcWrite(now()); restored = false; save();
    } else if (millis() - syncT0 > 15000) { wifiOff(); syncState = SYNC_FAIL; }
  }
#endif
}

}  // namespace ClockTime
