// =====================================================================
//  touch_ft6336.h  —  FT6336G 정전식 터치 (I2C 0x38) 최소 드라이버
// =====================================================================
#pragma once
#include <Wire.h>
#include "config.h"

namespace Touch {
  static const uint8_t ADDR = 0x38;
  static uint8_t chipId = 0;

  static bool writeReg(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(ADDR);
    Wire.write(reg);
    Wire.write(val);
    return Wire.endTransmission() == 0;
  }

  static int readReg(uint8_t reg) {
    Wire.beginTransmission(ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return -1;
    if (Wire.requestFrom(ADDR, (uint8_t)1) != 1) return -1;
    return Wire.read();
  }

  static bool begin() {
    pinMode(PIN_TP_INT, INPUT_PULLUP);
    pinMode(PIN_TP_RST, OUTPUT);
    digitalWrite(PIN_TP_RST, LOW);
    delay(10);
    digitalWrite(PIN_TP_RST, HIGH);
    delay(300);
    int id = readReg(0xA3);           // 칩 ID (FT6336G = 0x64)
    chipId = (id < 0) ? 0 : (uint8_t)id;
    writeReg(0xA4, 0x00);             // G_MODE: 누르고 있는 동안 INT = LOW
    return id >= 0;
  }

  // 원시 좌표 읽기 (패널 기준 0..239 / 0..319)
  static bool readRaw(int16_t &x, int16_t &y) {
    Wire.beginTransmission(ADDR);
    Wire.write(0x02);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom(ADDR, (uint8_t)5) != 5) return false;
    uint8_t n  = Wire.read() & 0x0F;
    uint8_t xh = Wire.read(), xl = Wire.read();
    uint8_t yh = Wire.read(), yl = Wire.read();
    if (n == 0 || n > 2) return false;
    int16_t rx = ((xh & 0x0F) << 8) | xl;
    int16_t ry = ((yh & 0x0F) << 8) | yl;
#if TOUCH_SWAP_XY
    int16_t t = rx; rx = ry; ry = t;
#endif
#if TOUCH_MIRROR_X
    rx = 239 - rx;
#endif
#if TOUCH_MIRROR_Y
    ry = 319 - ry;
#endif
    x = rx; y = ry;
    return true;
  }

  // 절전 진입 전: 저전력 감시 모드 (터치하면 INT 로 깨움)
  static void enterMonitor() {
    writeReg(0x86, 0x01);             // CTRL: 자동 감시 모드 허용
    writeReg(0xA5, 0x01);             // POWER_MODE = monitor
  }
}
