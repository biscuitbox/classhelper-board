// =====================================================================
//  ble_hid.h  —  보드를 '블루투스 키보드 + 마우스 + 소리 조절기'로 만들기
//
//  PC의 블루투스 설정 → 장치 추가 → config.h 의 BT_NAME(예: ClassHelper-01)을
//  한 번 고르면 연결됩니다. 다음부터는 보드를 켜면 저절로 다시 연결돼요.
//  보드 패키지(esp32 3.x)에 들어 있는 BLE 라이브러리만 씁니다 — 따로 설치할 것 없음.
//
//  앱에서 쓰는 법
//    Hid::key(KEY_RIGHT_ARROW);            // 키 하나 누르고 떼기
//    Hid::key('.');                        // 글자 키
//    Hid::combo(KEY_LEFT_CTRL, 'l');       // Ctrl+L 같은 두 키 조합
//    Hid::combo(KEY_LEFT_SHIFT, KEY_F5);   // Shift+F5
//    Hid::combo3(KEY_LEFT_CTRL, KEY_LEFT_SHIFT, KEY_F5);  // 세 키 조합
//    Hid::typeNumber(12);                  // 숫자 12 를 치고 Enter (PPT 12번 슬라이드로)
//    Hid::mouseMove(dx, dy);               // 마우스 움직이기 (-127 ~ 127)
//    Hid::mouseDown(); Hid::mouseUp(); Hid::click();
//    Hid::media(CONSUMER_CONTROL_VOLUME_INCREMENT);   // 소리 크게 / _DECREMENT / CONSUMER_CONTROL_MUTE
//    Hid::connected()                      // PC와 블루투스로 연결됐으면 true
//    Hid::state()                          // 0 기다리는 중 / 1 연결 중(보안 확인 전) / 2 연결됨
//    Hid::bondCount(), Hid::forgetAll()    // 기억한 PC 수 / 모두 잊기 (점검 화면에서 씀)
//
//  💡 글자 단축키(b, w, e 등)는 PC가 '한글' 입력 상태면 안 먹을 수 있어요.
//     그래서 PPT 검은 화면은 'b' 대신 '.', 흰 화면은 'w' 대신 ',' 를 씁니다.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEHIDDevice.h>
#include <BLESecurity.h>
#if defined(CONFIG_NIMBLE_ENABLED)
  #include <host/ble_gap.h>
  #include <host/ble_store.h>
  #include <host/ble_gatt.h>
  #include <host/ble_hs_mbuf.h>
#else
  #include <esp_gap_ble_api.h>
#endif
#include "config.h"

// ---------- 키 이름 (아두이노 Keyboard 라이브러리와 같은 번호) ----------
#define KEY_LEFT_CTRL   0x80
#define KEY_LEFT_SHIFT  0x81
#define KEY_LEFT_ALT    0x82
#define KEY_LEFT_GUI    0x83     // 윈도우 키
#define KEY_UP_ARROW    0xDA
#define KEY_DOWN_ARROW  0xD9
#define KEY_LEFT_ARROW  0xD8
#define KEY_RIGHT_ARROW 0xD7
#define KEY_BACKSPACE   0xB2
#define KEY_TAB         0xB3
#define KEY_RETURN      0xB0
#define KEY_ESC         0xB1
#define KEY_PAGE_UP     0xD3
#define KEY_PAGE_DOWN   0xD6
#define KEY_HOME        0xD2
#define KEY_END         0xD5
#define KEY_F5          0xC6
#define CONSUMER_CONTROL_PLAY_PAUSE       0x00CD
#define CONSUMER_CONTROL_MUTE             0x00E2
#define CONSUMER_CONTROL_VOLUME_INCREMENT 0x00E9
#define CONSUMER_CONTROL_VOLUME_DECREMENT 0x00EA
#define MOUSE_LEFT 0x01

namespace Hid {

// ---------- HID 보고서 모양 (키보드 1 / 마우스 2 / 소리 조절 3) ----------
static const uint8_t REPORT_MAP[] = {
  // 키보드 — Report ID 1
  0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
  0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,  // 조합키 8개
  0x95, 0x01, 0x75, 0x08, 0x81, 0x01,                                                              // 예약 1바이트
  0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02,                          // LED (출력)
  0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
  0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x73, 0x05, 0x07, 0x19, 0x00, 0x29, 0x73, 0x81, 0x00,  // 키 6개
  0xC0,
  // 마우스 — Report ID 2
  0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85, 0x02, 0x09, 0x01, 0xA1, 0x00,
  0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02,  // 단추 3개
  0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
  0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,  // X, Y, 휠
  0xC0, 0xC0,
  // 소리 조절(Consumer) — Report ID 3
  0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x03,
  0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
  0xC0
};

// 아스키 글자 → HID 키 번호 (0x80 이 붙으면 Shift 필요)
#define SH 0x80
static const uint8_t ASCII_MAP[128] = {
  0,0,0,0,0,0,0,0, 0x2A,0x2B,0x28,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0x29,0,0,0,0,
  0x2C, 0x1E|SH, 0x34|SH, 0x20|SH, 0x21|SH, 0x22|SH, 0x24|SH, 0x34,   //  !"#$%&'
  0x26|SH, 0x27|SH, 0x25|SH, 0x2E|SH, 0x36, 0x2D, 0x37, 0x38,         // ()*+,-./
  0x27, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26,         // 0-9
  0x33|SH, 0x33, 0x36|SH, 0x2E, 0x37|SH, 0x38|SH, 0x1F|SH,            // :;<=>?@
  0x04|SH,0x05|SH,0x06|SH,0x07|SH,0x08|SH,0x09|SH,0x0A|SH,0x0B|SH,0x0C|SH,0x0D|SH,0x0E|SH,0x0F|SH,0x10|SH,
  0x11|SH,0x12|SH,0x13|SH,0x14|SH,0x15|SH,0x16|SH,0x17|SH,0x18|SH,0x19|SH,0x1A|SH,0x1B|SH,0x1C|SH,0x1D|SH, // A-Z
  0x2F, 0x31, 0x30, 0x23|SH, 0x2D|SH, 0x35,                           // [\]^_`
  0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,
  0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1A,0x1B,0x1C,0x1D,    // a-z
  0x2F|SH, 0x31|SH, 0x30|SH, 0x35|SH, 0                               // {|}~
};
#undef SH

static BLEHIDDevice*      hid      = nullptr;
static BLEServer*         server   = nullptr;
static BLECharacteristic* inKey    = nullptr;
static BLECharacteristic* inMouse  = nullptr;
static BLECharacteristic* inMedia  = nullptr;
static uint8_t            mods = 0, keys[6] = {0}, buttons = 0;

// 연결 상태는 '켜짐/꺼짐' 표시를 따로 두지 않고, 그때그때 블루투스 칩에 직접 물어봅니다.
// (예전 방식은 연결·끊김 알림 순서가 꼬이면 PC는 '연결됨'인데 보드는 '기다리는 중'으로 남을 수 있었음)
static volatile uint16_t  connHandle = 0xFFFF;   // 지금 연결된 PC 번호
static volatile int       authResult = -1;       // 마지막 보안 확인: -1 아직, 0 성공, 그 밖 = 실패 코드
static volatile bool      secured    = false;    // (Bluedroid 용) 보안 확인 끝남

#if defined(CONFIG_NIMBLE_ENABLED)
// ⚠ 이 보드 패키지(esp32 3.3.x)의 블루투스 라이브러리는 Windows가 붙을 때 '연결됨' 알림을 놓치는 일이 있습니다.
//    (그러면 라이브러리는 연결이 0개라고 믿고 키를 보내지 않음 → PC는 '연결됨', 보드는 '기다리는 중')
//    그래서 연결은 블루투스 칩(NimBLE)에 번호마다 직접 물어서 찾고, 키도 라이브러리를 거치지 않고 직접 보냅니다.
static volatile int lastDisc = -1;                 // 마지막으로 끊긴 이유 (0x213 = PC가 끊음, 0x208 = 신호 끊김)

struct LinkScan { int n, secured; uint16_t handle; uint16_t h[3]; bool enc[3]; };
static volatile uint16_t seenHandle = 0xFFFF;      // 사건으로 알게 된 연결 번호 (있으면 먼저 확인)
static void scanAdd(LinkScan& r, uint16_t h) {
  if (r.n >= 3) return;
  for (int i = 0; i < r.n; i++) if (r.h[i] == h) return;
  ble_gap_conn_desc d;
  if (ble_gap_conn_find(h, &d) != 0) return;
  r.h[r.n] = h; r.enc[r.n] = d.sec_state.encrypted; r.n++;
  r.handle = h;
  if (d.sec_state.encrypted) r.secured++;
}
static LinkScan scanLinks() {
  LinkScan r = {};
  r.handle = 0xFFFF;
  uint16_t s = seenHandle;
  if (s != 0xFFFF) scanAdd(r, s);
  if (connHandle != 0xFFFF) scanAdd(r, connHandle);
  for (uint16_t h = 0; h < 32; h++) scanAdd(r, h);  // 연결 번호는 작은 수 → 0~31 을 차례로 물어봄
  return r;
}
static uint32_t linkCount() { return scanLinks().n; }

// 입력 보고(키·마우스·소리)를 연결된 PC에 직접 보냄 (보안 확인이 끝난 연결에만)
static void sendReport(BLECharacteristic* c, const uint8_t* data, size_t len) {
  if (!c) return;
  c->setValue((uint8_t*)data, len);                // PC가 읽을 때 돌려줄 값도 맞춰 둠
  LinkScan r = scanLinks();
  for (int i = 0; i < r.n; i++) {
    if (!r.enc[i]) continue;
    os_mbuf* om = ble_hs_mbuf_from_flat(data, len);
    if (!om) continue;
    int rc = ble_gatts_notify_custom(r.h[i], c->getHandle(), om);   // om 은 성공·실패와 상관없이 블루투스 쪽이 정리
    if (rc != 0) Serial.printf("[HID] 보내기 실패 rc=%d\n", rc);
  }
}

// 블루투스 사건은 블루투스 전용 작업(스택이 작음)에서 불리므로 여기서는 적어 두기만 하고,
// 시리얼 출력은 loop() 의 Hid::poll() 에서 합니다.
struct BtLog { uint8_t type; uint16_t handle; int val; };
static volatile BtLog btLog[16];
static volatile uint8_t logHead = 0, logTail = 0;
static void pushLog(uint8_t t, uint16_t h, int v) {
  uint8_t n = (logHead + 1) & 15;
  if (n == logTail) return;                        // 가득 차면 버림
  btLog[logHead].type = t; btLog[logHead].handle = h; btLog[logHead].val = v;
  logHead = n;
}
static ble_gap_event_listener gapListener;
static int onGapEvent(ble_gap_event* e, void*) {
  switch (e->type) {
    case BLE_GAP_EVENT_CONNECT:
      if (e->connect.status == 0) seenHandle = e->connect.conn_handle;
      pushLog(1, e->connect.conn_handle, e->connect.status); break;
    case BLE_GAP_EVENT_LINK_ESTAB:
      if (e->link_estab.status == 0) seenHandle = e->link_estab.conn_handle;
      pushLog(6, e->link_estab.conn_handle, e->link_estab.status); break;
    case BLE_GAP_EVENT_DISCONNECT:
      lastDisc = e->disconnect.reason;
      pushLog(2, e->disconnect.conn.conn_handle, e->disconnect.reason);
      break;
    case BLE_GAP_EVENT_ENC_CHANGE:     pushLog(3, e->enc_change.conn_handle, e->enc_change.status); break;
    case BLE_GAP_EVENT_SUBSCRIBE:      pushLog(4, e->subscribe.attr_handle, e->subscribe.cur_notify); break;
    case BLE_GAP_EVENT_REPEAT_PAIRING: pushLog(5, 0, 0); break;
    default: break;
  }
  return 0;
}

// loop() 에서 부름: 적어 둔 블루투스 사건을 시리얼 모니터(115200)에 [BT] 로 출력,
// 연결이 모두 끊겼는데 광고(PC가 찾을 수 있게 알리기)가 멈춰 있으면 다시 시작
static void poll() {
  while (logTail != logHead) {
    BtLog l = {btLog[logTail].type, btLog[logTail].handle, btLog[logTail].val};
    logTail = (logTail + 1) & 15;
    switch (l.type) {
      case 1: Serial.printf("[BT] 연결 사건 handle=%u status=%d\n", l.handle, l.val); break;
      case 6: Serial.printf("[BT] 연결 확정 handle=%u status=%d\n", l.handle, l.val); break;
      case 2: Serial.printf("[BT] 끊김 handle=%u 이유=0x%X\n", l.handle, l.val); break;
      case 3: Serial.printf("[BT] 보안 확인 %s (status=%d)\n", l.val == 0 ? "성공" : "실패", l.val); break;
      case 4: Serial.printf("[BT] PC가 알림 구독 attr=%u notify=%d\n", l.handle, l.val); break;
      case 5: Serial.println("[BT] 예전 기억으로 다시 페어링 → 예전 기억 지우고 받아들임"); break;
    }
  }
  static uint32_t last = 0;
  static int lastSt = -1;
  if (millis() - last > 1000) {                    // 1초마다 상태 확인
    last = millis();
    LinkScan r = scanLinks();
    int st = r.n == 0 ? 0 : (r.secured ? 2 : 1);
    if (st != lastSt) {
      lastSt = st;
      Serial.printf("[BT] 상태: 연결 %d개 (번호 %d), 보안 확인 %d개 / 라이브러리가 센 연결 %u\n",
                    r.n, r.n ? r.handle : -1, r.secured, server ? (unsigned)server->getConnectedCount() : 0);
    }
    if (r.n == 0 && !ble_gap_adv_active()) BLEDevice::startAdvertising();
  }
}
#else
static uint32_t linkCount() { return server ? server->getConnectedCount() : 0; }
static volatile int lastDisc = -1;
static void poll() {}
#endif

static void restartAdvertising() {
  if (linkCount() == 0) BLEDevice::startAdvertising();   // 연결된 PC가 없을 때만 다시 알림
}

class ServerCb : public BLEServerCallbacks {
#if defined(CONFIG_NIMBLE_ENABLED)
  void onConnect(BLEServer*, ble_gap_conn_desc* d) override { connHandle = d->conn_handle; authResult = -1; }
  void onDisconnect(BLEServer*, ble_gap_conn_desc* d) override {
    if (d->conn_handle == connHandle) connHandle = 0xFFFF;
    restartAdvertising();                         // 끊기면 다시 연결을 기다림
  }
#else
  void onConnect(BLEServer*) override    { secured = false; authResult = -1; }
  void onDisconnect(BLEServer*) override {
    secured = false;
    BLEDevice::startAdvertising();
  }
#endif
};
class SecurityCb : public BLESecurityCallbacks {
  bool     onSecurityRequest() override       { return true; }
  uint32_t onPassKeyRequest() override        { return 0; }
  void     onPassKeyNotify(uint32_t) override {}
  bool     onConfirmPIN(uint32_t) override    { return true; }
#if defined(CONFIG_BLUEDROID_ENABLED)
  void onAuthenticationComplete(esp_ble_auth_cmpl_t a) override {
    secured = a.success; authResult = a.success ? 0 : (a.fail_reason ? a.fail_reason : 1);
  }
#elif defined(CONFIG_NIMBLE_ENABLED)
  void onAuthenticationComplete(ble_gap_conn_desc*) override {}
  void onAuthenticationComplete(ble_gap_conn_desc*, int status) override { authResult = status; }
#endif
};

static constexpr bool available() { return true; }
static const char* name() { return BT_NAME; }

// 0 = 기다리는 중(PC가 찾을 수 있음) / 1 = 연결은 됐는데 보안 확인 전·실패 / 2 = 연결됨(키가 감)
static int state() {
  if (linkCount() == 0) return 0;
#if defined(CONFIG_NIMBLE_ENABLED)
  return scanLinks().secured ? 2 : 1;
#else
  return secured ? 2 : 1;
#endif
}
static bool connected() { return linkCount() > 0; }   // 키를 보내도 되는지
static int  lastAuth()  { return authResult; }
static int  lastDisconnect() { return lastDisc; }   // -1 = 아직 없음

// 이 보드가 기억하고 있는 PC 수 (보드 안 저장공간에 남아 있어서, 코드를 다시 올려도 지워지지 않음)
static int bondCount() {
#if defined(CONFIG_NIMBLE_ENABLED)
  int n = 0;
  if (ble_store_util_count(BLE_STORE_OBJ_TYPE_PEER_SEC, &n) != 0) return -1;
  return n;
#else
  return esp_ble_get_bond_device_num();
#endif
}

// 기억한 PC를 모두 지움. 부른 쪽에서 곧바로 ESP.restart() 하세요.
// 지운 뒤에는 PC 쪽에서도 이 장치를 '제거'하고 다시 '장치 추가' 해야 합니다.
static void forgetAll() {
#if defined(CONFIG_NIMBLE_ENABLED)
  LinkScan r = scanLinks();
  if (r.handle != 0xFFFF) ble_gap_terminate(r.handle, BLE_ERR_REM_USER_CONN_TERM);
  ble_store_clear();
#else
  int n = esp_ble_get_bond_device_num();
  if (n > 0) {
    esp_ble_bond_dev_t* list = (esp_ble_bond_dev_t*)malloc(sizeof(esp_ble_bond_dev_t) * n);
    if (list && esp_ble_get_bond_device_list(&n, list) == ESP_OK)
      for (int i = 0; i < n; i++) esp_ble_remove_bond_device(list[i].bd_addr);
    free(list);
  }
#endif
}

// setup() 에서 한 번만 부릅니다 (ClassHelper.ino 가 알아서 부름)
static void begin() {
  BLEDevice::init(BT_NAME);
#if defined(CONFIG_NIMBLE_ENABLED)
  ble_gap_event_listener_register(&gapListener, onGapEvent, nullptr);
  Serial.printf("[BT] 시작: %s\n", BT_NAME);
#endif
  BLESecurity* sec = new BLESecurity();
  sec->setCapability(ESP_IO_CAP_NONE);           // 숫자 입력 없이 바로 연결 (Just Works)
  sec->setAuthenticationMode(true, false, true); // 연결 정보 기억(본딩)
  BLEDevice::setSecurityCallbacks(new SecurityCb());

  server = BLEDevice::createServer();
  server->setCallbacks(new ServerCb());

  hid = new BLEHIDDevice(server);
  inKey   = hid->inputReport(1);
  hid->outputReport(1);                          // 캡스락 등 LED (받기만 함)
  inMouse = hid->inputReport(2);
  inMedia = hid->inputReport(3);

  hid->manufacturer()->setValue("Maker Teacher");
  hid->pnp(0x02, 0x303A, 0x4001, 0x0100);
  hid->hidInfo(0x00, 0x01);
  hid->reportMap((uint8_t*)REPORT_MAP, sizeof(REPORT_MAP));
  hid->startServices();
  hid->setBatteryLevel(100);

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->setAppearance(0x03C1);                    // 키보드 모양
  adv->addServiceUUID(hid->hidService()->getUUID());
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.printf("[BT] 기다리는 중 (기억한 PC %d대)\n", bondCount());
}

static void setBattery(uint8_t pct) { if (hid) hid->setBatteryLevel(pct); }

// ---------- 키보드 ----------
static void logSend(const char* what) {          // 보내기 전에 시리얼에 한 줄 (재부팅되면 마지막 줄이 범인)
  Serial.printf("[HID] %s 보냄 (라이브러리 연결 수 %u, 보드가 본 연결 %d, 남은 스택 %u)\n", what,
                server ? (unsigned)server->getConnectedCount() : 0, (int)linkCount(),
                (unsigned)uxTaskGetStackHighWaterMark(NULL));
  Serial.flush();
}
static void notifyReport(BLECharacteristic* c, uint8_t* r, size_t n) {
#if defined(CONFIG_NIMBLE_ENABLED)
  sendReport(c, r, n);
#else
  c->setValue(r, n); c->notify();
#endif
}
static void sendKeys() {
  if (!connected() || !inKey) return;
  uint8_t r[8] = {mods, 0, keys[0], keys[1], keys[2], keys[3], keys[4], keys[5]};
  notifyReport(inKey, r, sizeof(r));
}
static void press(uint8_t k) {
  uint8_t code;
  if (k >= 136)      code = k - 136;                          // 화살표·F5 같은 특수 키
  else if (k >= 128) { mods |= (1 << (k - 128)); sendKeys(); return; }  // Ctrl·Shift·Alt·윈도우
  else {
    code = ASCII_MAP[k];
    if (code & 0x80) { mods |= 0x02; code &= 0x7F; }          // 대문자·기호는 Shift
  }
  if (!code) return;
  for (int i = 0; i < 6; i++) if (keys[i] == code) { sendKeys(); return; }
  for (int i = 0; i < 6; i++) if (!keys[i]) { keys[i] = code; break; }
  sendKeys();
}
static void releaseAll() {
  mods = 0; memset(keys, 0, sizeof(keys));
  sendKeys();
}

static void key(uint8_t k)                          { logSend("키"); press(k); delay(12); releaseAll(); Serial.println("[HID] 키 끝"); }
static void combo(uint8_t m, uint8_t k)             { logSend("조합 키"); press(m); press(k); delay(20); releaseAll(); Serial.println("[HID] 조합 키 끝"); }
static void combo3(uint8_t a, uint8_t b, uint8_t k) { logSend("조합 키3"); press(a); press(b); press(k); delay(20); releaseAll(); Serial.println("[HID] 조합 키3 끝"); }
static void typeNumber(int n) {
  char buf[8];
  snprintf(buf, sizeof(buf), "%d", n);
  for (char* p = buf; *p; p++) { key(*p); delay(12); }
  key(KEY_RETURN);
}

// ---------- 마우스 ----------
static void sendMouse(int8_t dx, int8_t dy) {
  if (!connected() || !inMouse) return;
  uint8_t r[4] = {buttons, (uint8_t)dx, (uint8_t)dy, 0};
  notifyReport(inMouse, r, sizeof(r));
}
static void mouseMove(int dx, int dy) {
  dx = constrain(dx, -127, 127); dy = constrain(dy, -127, 127);
  if (dx || dy) sendMouse(dx, dy);
}
static void mouseDown() { logSend("마우스 누름"); buttons |= MOUSE_LEFT;  sendMouse(0, 0); }
static void mouseUp()   { buttons &= ~MOUSE_LEFT; sendMouse(0, 0); }
static void click()     { mouseDown(); delay(15); mouseUp(); Serial.println("[HID] 클릭 끝"); }

// ---------- 소리 크게·작게·음소거 ----------
static void media(uint16_t usage) {
  if (!connected() || !inMedia) return;
  logSend("소리 조절");
  uint8_t r[2] = {(uint8_t)(usage & 0xFF), (uint8_t)(usage >> 8)};
  notifyReport(inMedia, r, 2);
  delay(20);
  r[0] = r[1] = 0;
  notifyReport(inMedia, r, 2);
  Serial.println("[HID] 소리 조절 끝");
}

}  // namespace Hid
