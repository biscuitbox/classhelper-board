// =====================================================================
//  es8311.h  —  ES8311 오디오 코덱 최소 설정 (I2C 0x18)
//  슬레이브 모드, MCLK = 256 x fs (ESP32 가 공급), 16bit I2S, DAC 재생
//  레지스터 순서는 Espressif es8311 드라이버(esp_codec_dev)를 따랐습니다.
// =====================================================================
#pragma once
#include <Wire.h>

namespace ES8311 {
  static const uint8_t ADDR = 0x18;
  static bool present = false;

  static bool wr(uint8_t reg, uint8_t val) {
    Wire.beginTransmission(ADDR);
    Wire.write(reg);
    Wire.write(val);
    return Wire.endTransmission() == 0;
  }

  // MCLK(I2S)가 이미 출력되고 있어야 합니다.
  static bool begin(uint8_t dacVolume = 0xBF) {   // 0xBF = 0 dB
    Wire.beginTransmission(ADDR);
    present = (Wire.endTransmission() == 0);
    if (!present) return false;

    wr(0x00, 0x1F); delay(20);   // 리셋
    wr(0x00, 0x00);
    wr(0x00, 0x80);              // 전원 ON, 슬레이브 모드

    // 클럭: MCLK 핀 사용, 모든 클럭 ON, 256fs (pre_div=1, x1)
    wr(0x01, 0x3F);
    wr(0x02, 0x00);
    wr(0x03, 0x10);              // ADC OSR
    wr(0x04, 0x10);              // DAC OSR
    wr(0x05, 0x00);              // ADC/DAC 분주 = 1
    wr(0x06, 0x03);              // BCLK 분주(마스터일 때만 의미)
    wr(0x07, 0x00);
    wr(0x08, 0xFF);              // LRCK = MCLK/256

    // 직렬 포맷: I2S, 16bit, 음소거 해제
    wr(0x09, 0x0C);
    wr(0x0A, 0x0C);

    wr(0x0B, 0x00);
    wr(0x0C, 0x00);
    wr(0x10, 0x1F);
    wr(0x11, 0x7F);

    // 아날로그 전원 ON, DAC ON, 출력 드라이버 ON
    wr(0x0D, 0x01);
    wr(0x0E, 0x02);
    wr(0x12, 0x00);
    wr(0x13, 0x10);
    wr(0x14, 0x1A);
    wr(0x15, 0x40);
    wr(0x16, 0x24);
    wr(0x17, 0xBF);
    wr(0x1B, 0x0A);
    wr(0x1C, 0x6A);
    wr(0x37, 0x08);              // DAC EQ 우회
    wr(0x45, 0x00);

    wr(0x31, 0x00);              // DAC 음소거 해제
    wr(0x32, dacVolume);         // DAC 볼륨
    return true;
  }

  static void setVolume(uint8_t v) { if (present) wr(0x32, v); }

  // 절전용 전원 차단
  static void powerDown() {
    if (!present) return;
    wr(0x32, 0x00);
    wr(0x17, 0x00);
    wr(0x0E, 0xFF);
    wr(0x12, 0x02);
    wr(0x14, 0x00);
    wr(0x0D, 0xFA);
    wr(0x15, 0x00);
    wr(0x02, 0x10);
    wr(0x00, 0x00);
    wr(0x00, 0x1F);
    wr(0x01, 0x30);
    wr(0x01, 0x00);
    wr(0x45, 0x00);
    wr(0x0D, 0xFC);
    wr(0x02, 0x00);
  }
}
