// =====================================================================
//  교탁 도우미  (LCDwiki ES3C28P · ESP32-S3 2.8" 터치 보드)
//
//  첫 화면에서 기능을 골라 씁니다.
//    💣 지뢰찾기   (app_mine.h)
//    🚦 소음 신호등 (app_noise.h)
//    🎤 프레젠터   (app_presenter.h)
//  기능 화면에서 왼쪽 위 🏠 를 0.7초 누르고 있으면 첫 화면으로 돌아옵니다.
//
//  📁 이 파일(교탁 도우미 본체)은 고치지 않아도 됩니다.
//     바이브코딩으로 바꾸는 곳은 app_○○.h 파일 하나씩입니다.
//
//  필요한 것
//    - 보드 패키지 "esp32 by Espressif Systems" 3.x
//    - 라이브러리 "LovyanGFX"
//    - Tools → Board: ESP32S3 Dev Module / Flash Size: 16MB / PSRAM: OPI PSRAM
//    - (프레젠터를 쓸 때) Tools → USB Mode: USB-OTG (TinyUSB)
// =====================================================================
#include <Arduino.h>
#include <Wire.h>
#include <Preferences.h>

#include "config.h"
#include "helper.h"
#include "touch_ft6336.h"
#include "es8311.h"
#include "sfx.h"
#include "mic.h"
#include "usb_hid.h"

// ---------- 앱 파일 (하나씩 늘어납니다) ----------
#include "app_mine.h"
#include "app_noise.h"
#include "app_presenter.h"

static const App* APPS[] = { &AppMine::app, &AppNoise::app, &AppPresenter::app };
static const int  APP_N  = sizeof(APPS) / sizeof(APPS[0]);

static Preferences sysPrefs;

// 지금 화면: -1 = 첫 화면, -2 = 설정, -3 = 점검, 0~ = 앱 번호
enum : int { SCR_HOME = -1, SCR_SETTINGS = -2, SCR_DIAG = -3 };
static int screen = SCR_HOME;

// =====================================================================
//                              설정 저장
// =====================================================================
static void loadSys() {
  sysPrefs.begin("helper", true);
  Sys::cfg.vol      = sysPrefs.getUChar("vol", 2);
  Sys::cfg.bright   = sysPrefs.getUChar("br", 1);
  Sys::cfg.dimIdx   = sysPrefs.getUChar("dim", 1);
  Sys::cfg.flip     = sysPrefs.getUChar("flip", 0);
  Sys::cfg.startApp = sysPrefs.getUChar("start", 0);
  sysPrefs.end();
  if (Sys::cfg.vol > 3)    Sys::cfg.vol = 2;
  if (Sys::cfg.bright > 2) Sys::cfg.bright = 1;
  if (Sys::cfg.dimIdx > 3) Sys::cfg.dimIdx = 1;
  if (Sys::cfg.flip > 1)   Sys::cfg.flip = 0;
  if (Sys::cfg.startApp > APP_N) Sys::cfg.startApp = 0;
}
static void saveSys() {
  sysPrefs.begin("helper", false);
  sysPrefs.putUChar("vol", Sys::cfg.vol);
  sysPrefs.putUChar("br", Sys::cfg.bright);
  sysPrefs.putUChar("dim", Sys::cfg.dimIdx);
  sysPrefs.putUChar("flip", Sys::cfg.flip);
  sysPrefs.putUChar("start", Sys::cfg.startApp);
  sysPrefs.end();
}

// =====================================================================
//                              첫 화면
// =====================================================================
static int appBtnY(int i) { return 70 + i * 70; }

static void drawAppButton(int i, bool pressed = false) {
  const App* a = APPS[i];
  int x = 8, y = appBtnY(i), w = 224, h = 62;
  bool ok = a->ready;
  uint16_t face = ok ? a->color : 0x4208;
  lcd.fillRoundRect(x, y, w, h, 10, face);
  if (pressed) {
    lcd.drawRoundRect(x, y, w, h, 10, C_WHITE);
    lcd.drawRoundRect(x + 1, y + 1, w - 2, h - 2, 9, C_WHITE);
  }
  // 아이콘 동그라미
  lcd.fillCircle(x + 34, y + h / 2, 24, ok ? C_WHITE : 0x6B4D);
  if (ok && a->icon) a->icon(x + 34, y + h / 2);
  else text("?", x + 34, y + h / 2 + 1, &fonts::efontKR_24_b, 0x9CD3);
  text(a->name, x + 68, y + 21, &fonts::efontKR_24_b, ok ? C_WHITE : 0x9CD3, textdatum_t::middle_left);
  text(ok ? a->desc : "다음 시간에 만들어요", x + 68, y + 46, &fonts::efontKR_12,
       ok ? C_WHITE : 0x8410, textdatum_t::middle_left);
}

static void drawHome() {
  lcd.startWrite();
  lcd.fillScreen(C_BG);
  text(DEVICE_TITLE, 120, 26, &fonts::efontKR_24_b, C_WHITE);
  text(DEVICE_OWNER, 120, 52, &fonts::efontKR_14, 0xAD55);
  for (int i = 0; i < APP_N; i++) drawAppButton(i);
  button(8, 284, 224, 30, "설정 · 점검", false, &fonts::efontKR_16, 0x39E7, C_WHITE);
  lcd.endWrite();
}

// =====================================================================
//                              설정 화면
// =====================================================================
static const char* VOL_NAME[4]    = {"끔", "작게", "보통", "크게"};
static const char* BRIGHT_NAME[3] = {"어둡게", "보통", "밝게"};
static const char* DIM_NAME[4]    = {"1분", "3분", "10분", "안 함"};
static const char* FLIP_NAME[2]   = {"기본", "뒤집기"};
static const char* START_NAME[4]  = {"첫 화면", "지뢰", "소음", "발표"};

void drawDiag();
static int rowY(int k) { return 36 + k * 46; }

static void drawOptRow(int k, const char* title, const char* const* names, int n, int sel) {
  int y = rowY(k);
  lcd.fillRect(0, y, 240, 46, C_GRAY);
  text(title, 6, y + 8, &fonts::efontKR_12, C_BAR, textdatum_t::middle_left);
  int w = (232 - (n - 1) * 4) / n;
  for (int i = 0; i < n; i++) button(4 + i * (w + 4), y + 17, w, 26, names[i], i == sel);
}
static int optIndex(int x, int n) {
  int w = (232 - (n - 1) * 4) / n;
  return constrain((x - 4) / (w + 4), 0, n - 1);
}

static void drawSettings() {
  lcd.startWrite();
  lcd.fillScreen(C_GRAY);
  drawTitleBar("설정");
  drawOptRow(0, "소리 크기", VOL_NAME, 4, Sys::cfg.vol);
  drawOptRow(1, "화면 밝기", BRIGHT_NAME, 3, Sys::cfg.bright);
  drawOptRow(2, "안 만지면 화면 어둡게", DIM_NAME, 4, Sys::cfg.dimIdx);
  drawOptRow(3, "화면 방향", FLIP_NAME, 2, Sys::cfg.flip);
  drawOptRow(4, "켜면 바로 시작", START_NAME, 1 + APP_N, Sys::cfg.startApp);
  button(4,   288, 112, 28, "하드웨어 점검");
  button(124, 288, 112, 28, "첫 화면으로", true);
  lcd.endWrite();
}

static void settingsUp(int x, int y) {
  if (y >= 286) {
    Sfx::play(SFX_TAP);
    if (x < 120) { saveSys(); screen = SCR_DIAG; drawDiag(); }
    else         { saveSys(); screen = SCR_HOME; drawHome(); }
    return;
  }
  for (int k = 0; k < 5; k++) {
    if (y < rowY(k) + 14 || y >= rowY(k) + 46) continue;
    switch (k) {
      case 0: Sys::cfg.vol = optIndex(x, 4); Sfx::setGain(Sys::VOL_GAIN[Sys::cfg.vol]);
              drawOptRow(0, "소리 크기", VOL_NAME, 4, Sys::cfg.vol); break;
      case 1: Sys::cfg.bright = optIndex(x, 3); lcd.setBrightness(Sys::BRIGHT_VAL[Sys::cfg.bright]);
              drawOptRow(1, "화면 밝기", BRIGHT_NAME, 3, Sys::cfg.bright); break;
      case 2: Sys::cfg.dimIdx = optIndex(x, 4);
              drawOptRow(2, "안 만지면 화면 어둡게", DIM_NAME, 4, Sys::cfg.dimIdx); break;
      case 3: { uint8_t f = optIndex(x, 2);
                if (f != Sys::cfg.flip) { Sys::cfg.flip = f; lcd.setRotation(f ? 2 : 0); drawSettings(); } } break;
      case 4: Sys::cfg.startApp = optIndex(x, 1 + APP_N);
              drawOptRow(4, "켜면 바로 시작", START_NAME, 1 + APP_N, Sys::cfg.startApp); break;
    }
    Sfx::play(SFX_TAP);
    return;
  }
}

// =====================================================================
//                       하드웨어 점검 화면
// =====================================================================
static uint8_t diagSfx = SFX_TAP;
static float   diagDb  = -90;

static void drawDiagInfo() {
  char buf[64];
  lcd.fillRect(0, 34, 240, 96, C_BLACK);
  snprintf(buf, sizeof(buf), "터치 칩: 0x%02X %s", Touch::chipId, Touch::chipId ? "(정상)" : "(응답 없음)");
  text(buf, 6, 44, &fonts::efontKR_12, C_WHITE, textdatum_t::middle_left);
  snprintf(buf, sizeof(buf), "오디오 코덱: %s", ES8311::present ? "정상" : "응답 없음");
  text(buf, 6, 60, &fonts::efontKR_12, C_WHITE, textdatum_t::middle_left);
  snprintf(buf, sizeof(buf), "USB 키보드: %s", !Hid::available() ? "USB Mode가 TinyUSB 아님"
                                              : (Hid::connected() ? "PC 연결됨" : "PC 연결 안 됨"));
  text(buf, 6, 76, &fonts::efontKR_12, C_WHITE, textdatum_t::middle_left);
  snprintf(buf, sizeof(buf), "마이크: %.0f dBFS", diagDb);
  text(buf, 6, 92, &fonts::efontKR_12, C_WHITE, textdatum_t::middle_left);
  text("화면을 터치하면 점이 찍혀요.", 6, 112, &fonts::efontKR_12, 0xBDF7, textdatum_t::middle_left);
}

void drawDiag() {
  lcd.startWrite();
  lcd.fillScreen(C_BLACK);
  drawTitleBar("하드웨어 점검");
  drawDiagInfo();
  const int pts[4][2] = {{14, 146}, {226, 146}, {14, 270}, {226, 270}};
  for (auto& p : pts) {
    lcd.drawFastHLine(p[0] - 8, p[1], 17, C_YELLOW);
    lcd.drawFastVLine(p[0], p[1] - 8, 17, C_YELLOW);
  }
  button(4, 288, 140, 28, "효과음 듣기");
  lcd.endWrite();
  Mic::start();
}

static void diagDown(int x, int y) {
  if (y > 132 && y < 284) {
    lcd.fillCircle(x, y, 3, 0x07FF);
    char buf[24];
    snprintf(buf, sizeof(buf), "x=%3d y=%3d", x, y);
    lcd.fillRect(150, 290, 90, 26, C_BLACK);
    text(buf, 150, 303, &fonts::Font2, C_WHITE, textdatum_t::middle_left);
  }
}
static void diagUp(int x, int y) {
  if (y >= 286 && x < 146) {
    Sfx::play(diagSfx);
    if (++diagSfx >= SFX_COUNT) diagSfx = SFX_TAP;
  }
}
static void diagUpdate() {
  static uint32_t last = 0;
  if (Mic::hasNew()) diagDb = Mic::db();
  if (millis() - last > 500) { last = millis(); drawDiagInfo(); }
}

// =====================================================================
//                         화면 바꾸기
// =====================================================================
static void openApp(int i) {
  if (i < 0 || i >= APP_N || !APPS[i]->ready) return;
  screen = i;
  lcd.setTextSize(1);
  APPS[i]->start();
}

static void goHome() {
  if (screen >= 0) APPS[screen]->stop();
  if (screen == SCR_DIAG) Mic::stop();
  if (screen == SCR_SETTINGS) saveSys();
  screen = SCR_HOME;
  Sfx::play(SFX_HOME);
  drawHome();
}

// =====================================================================
//                              터치 처리
// =====================================================================
static struct {
  bool down = false; int16_t x = 0, y = 0; uint8_t miss = 0;
  bool homeZone = false; uint32_t t0 = 0; int pressedApp = -1;
} tp;
static uint32_t lastActivity = 0;
static bool dimmed = false;

static bool readTouch(int16_t &x, int16_t &y) {
  int16_t rx, ry;
  if (!Touch::readRaw(rx, ry)) return false;
  rx = constrain(rx, 0, 239);
  ry = constrain(ry, 0, 319);
  if (Sys::cfg.flip) { rx = 239 - rx; ry = 319 - ry; }
  x = rx; y = constrain(ry + TOUCH_Y_OFFSET, 0, 319);
  return true;
}

static void onDown(int x, int y) {
  tp.t0 = millis();
  tp.homeZone = (screen != SCR_HOME) && x < 44 && y < 30;
  if (tp.homeZone) return;                   // 🏠 자리는 앱으로 보내지 않음
  if (screen == SCR_HOME) {
    tp.pressedApp = -1;
    for (int i = 0; i < APP_N; i++)
      if (inside(x, y, 8, appBtnY(i), 224, 62)) { tp.pressedApp = i; drawAppButton(i, true); }
  } else if (screen == SCR_DIAG) diagDown(x, y);
  else if (screen >= 0) APPS[screen]->touch(TOUCH_DOWN, x, y);
}

static void onMove(int x, int y) {
  if (tp.homeZone) return;
  if (screen >= 0) APPS[screen]->touch(TOUCH_MOVE, x, y);
  else if (screen == SCR_DIAG) diagDown(x, y);
}

static void onUp(int x, int y) {
  if (tp.homeZone) {                          // 짧게 누르고 뗌 → 안내만
    if (screen >= 0) drawHomeButton();
    else drawTitleBar(screen == SCR_SETTINGS ? "설정" : "하드웨어 점검");
    return;
  }
  if (screen == SCR_HOME) {
    int i = tp.pressedApp;
    tp.pressedApp = -1;
    if (i >= 0) {
      drawAppButton(i);
      if (!inside(x, y, 8, appBtnY(i), 224, 62)) return;
      if (APPS[i]->ready) { Sfx::play(SFX_START); openApp(i); }
      else Sfx::play(SFX_ERROR);
    } else if (y >= 280) {
      Sfx::play(SFX_TAP); screen = SCR_SETTINGS; drawSettings();
    }
  } else if (screen == SCR_SETTINGS) settingsUp(x, y);
  else if (screen == SCR_DIAG) diagUp(x, y);
  else if (screen >= 0) APPS[screen]->touch(TOUCH_UP, x, y);
}

// 🏠 길게 누르는 중
static void homeHold() {
  if (!tp.down || !tp.homeZone) return;
  uint32_t held = millis() - tp.t0;
  drawHomeProgress(min(1.0f, held / (float)HOME_HOLD_MS));
  if (held >= HOME_HOLD_MS) {
    tp.homeZone = false;
    tp.down = false;
    goHome();
    // 손가락을 뗄 때까지 다음 터치를 무시
    int16_t x, y;
    uint32_t t = millis();
    while (readTouch(x, y) && millis() - t < 3000) delay(15);
  }
}

// =====================================================================
//                              setup / loop
// =====================================================================
void setup() {
  Serial.begin(115200);
  pinMode(PIN_BOOT_BTN, INPUT_PULLUP);
  rgbLedWrite(PIN_WS2812, 0, 0, 0);
  loadSys();

  Hid::begin();                               // USB 키보드·마우스 (TinyUSB 모드일 때만)

  lcd.init();
  lcd.setRotation(Sys::cfg.flip ? 2 : 0);
  lcd.setBrightness(0);
  lcd.fillScreen(C_BG);

  Wire.begin(PIN_I2C_SDA, PIN_I2C_SCL, 400000);
  bool tok = Touch::begin();
  Serial.printf("[터치] %s, 칩 ID 0x%02X\n", tok ? "OK" : "응답 없음", Touch::chipId);

  Sfx::begin();
  Sfx::setGain(Sys::VOL_GAIN[Sys::cfg.vol]);
  Serial.printf("[오디오] ES8311 %s\n", ES8311::present ? "OK" : "응답 없음");

  int s = Sys::cfg.startApp - 1;
  if (s >= 0 && s < APP_N && APPS[s]->ready) openApp(s);
  else drawHome();

  for (int b = 0; b <= Sys::BRIGHT_VAL[Sys::cfg.bright]; b += 10) { lcd.setBrightness(b); delay(8); }
  lcd.setBrightness(Sys::BRIGHT_VAL[Sys::cfg.bright]);
  Sfx::play(SFX_START);
  lastActivity = millis();
}

void loop() {
  uint32_t now = millis();

  // ---- 터치 ----
  int16_t x, y;
  bool touched = readTouch(x, y);
  if (touched) {
    lastActivity = now;
    if (dimmed) {                              // 어두운 화면을 깨우는 터치는 동작하지 않음
      dimmed = false;
      lcd.setBrightness(Sys::BRIGHT_VAL[Sys::cfg.bright]);
      uint32_t t = millis();
      while (readTouch(x, y) && millis() - t < 3000) delay(15);
      return;
    }
    tp.miss = 0;
    if (!tp.down) { tp.down = true; tp.x = x; tp.y = y; onDown(x, y); }
    else if (x != tp.x || y != tp.y) { tp.x = x; tp.y = y; onMove(x, y); }
  } else if (tp.down) {
    if (++tp.miss >= 3) { tp.down = false; onUp(tp.x, tp.y); }   // 잠깐 끊김은 무시 (약 30ms)
  }
  Sys::touching = tp.down;
  homeHold();

  // ---- 앱 / 점검 화면 계속 실행 ----
  if (screen >= 0) APPS[screen]->update();
  else if (screen == SCR_DIAG) diagUpdate();

  // ---- BOOT 버튼 (짧게 누름) ----
  static uint32_t bootDown = 0;
  if (digitalRead(PIN_BOOT_BTN) == LOW) {
    if (!bootDown) bootDown = now;
  } else {
    if (bootDown && now - bootDown > 30) {
      lastActivity = now;
      if (dimmed) { dimmed = false; lcd.setBrightness(Sys::BRIGHT_VAL[Sys::cfg.bright]); }
      else if (screen >= 0 && APPS[screen]->button) APPS[screen]->button();
    }
    bootDown = 0;
  }

  // ---- 화면 자동 어둡게 ----
  uint32_t lim = Sys::DIM_MS[Sys::cfg.dimIdx];
  bool awake = (screen >= 0 && APPS[screen]->keepAwake);
  if (awake) lastActivity = now;
  if (lim && !dimmed && now - lastActivity > lim) {
    dimmed = true;
    lcd.setBrightness(Sys::BRIGHT_VAL[0] / 3);
  }

  delay(8);
}
