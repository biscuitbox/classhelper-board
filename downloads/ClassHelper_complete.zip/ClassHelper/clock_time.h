// =====================================================================
//  clock_time.h  —  시계용 시간 도구 (한국 시간 KST)
//
//  이 보드에는 따로 시계 칩(RTC)이 없습니다.
//   - 전원이 켜져 있는 동안·절전 중에는 시간이 계속 흐릅니다.
//   - 전원이 완전히 꺼지거나 RESET 하면 시간을 잊습니다 → 다시 맞춰야 함.
//   - 절전 중에는 시계가 조금씩 빨라지거나 느려질 수 있습니다(하루 몇 분).
//  config.h 에 와이파이 이름·비밀번호를 적고 CLOCK_WIFI 를 1 로 하면
//  시계 화면에 들어갈 때·6시간마다 인터넷 시간으로 저절로 맞춥니다.
//
//  📁 이 파일은 고치지 않아도 됩니다.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <time.h>
#include <sys/time.h>
#include "config.h"
#if CLOCK_WIFI
  #include <WiFi.h>
  #include "esp_sntp.h"
#endif

namespace ClockTime {

static void useKoreaTime() {
  static bool done = false;
  if (!done) { setenv("TZ", "KST-9", 1); tzset(); done = true; }
}
static time_t now() { useKoreaTime(); return time(nullptr); }
static bool   valid() { return now() > 1735657200; }          // 2025-01-01 이후면 맞춘 시간
static void   set(time_t t) { timeval tv = {t, 0}; settimeofday(&tv, nullptr); }
static void   local(time_t t, struct tm& out) { useKoreaTime(); localtime_r(&t, &out); }
static time_t make(struct tm& t) { useKoreaTime(); t.tm_isdst = 0; return mktime(&t); }

// ---------- 인터넷 시간 ----------
enum SyncState { SYNC_OFF, SYNC_IDLE, SYNC_WIFI, SYNC_NTP, SYNC_OK, SYNC_FAIL };
static SyncState syncState = CLOCK_WIFI ? SYNC_IDLE : SYNC_OFF;
static uint32_t  syncT0 = 0, lastOk = 0;

static bool wifiReady() { return CLOCK_WIFI && strlen(WIFI_SSID) > 0; }
static bool busy() { return syncState == SYNC_WIFI || syncState == SYNC_NTP; }

#if CLOCK_WIFI
static void wifiOff() {
  esp_sntp_stop();
  WiFi.disconnect(true);
  WiFi.mode(WIFI_OFF);                       // 블루투스와 배터리를 위해 다 맞추면 바로 끔
}
#endif

static void startSync() {
#if CLOCK_WIFI
  if (!wifiReady() || busy()) return;
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  syncState = SYNC_WIFI;
  syncT0 = millis();
#endif
}

// 시계 화면에서 계속 부름: 연결 → 시간 받기 → 와이파이 끄기
static void poll() {
#if CLOCK_WIFI
  if (syncState == SYNC_WIFI) {
    if (WiFi.status() == WL_CONNECTED) {
      configTzTime("KST-9", "pool.ntp.org", "time.google.com", "time.windows.com");
      syncState = SYNC_NTP; syncT0 = millis();
    } else if (millis() - syncT0 > 20000) { wifiOff(); syncState = SYNC_FAIL; }
  } else if (syncState == SYNC_NTP) {
    if (sntp_get_sync_status() == SNTP_SYNC_STATUS_COMPLETED && valid()) {
      wifiOff(); syncState = SYNC_OK; lastOk = millis();
    } else if (millis() - syncT0 > 15000) { wifiOff(); syncState = SYNC_FAIL; }
  }
#endif
}

}  // namespace ClockTime
