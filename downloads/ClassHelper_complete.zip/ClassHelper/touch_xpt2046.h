// =====================================================================
//  touch_xpt2046.h  —  대체 보드 E32R28T-1 의 저항식 터치 (XPT2046) + 터치 보정
//
//  저항식 터치는 손가락이 닿은 '전압'을 재는 방식이라, 보드마다 숫자가 조금씩 달라요.
//  그래서 처음 켤 때 화면 네 귀퉁이의 + 를 차례로 눌러 '어디를 누르면 어떤 숫자인지'를
//  한 번 맞춰 두고(터치 보정), 보드 안에 저장합니다. 코드를 다시 올려도 지워지지 않아요.
//
//  다시 맞추려면: 설정 → 점검 → [터치 보정], 또는 켜고 5초 안에 BOOT 를 1초 누르기
//  기본 보드(ES3C28P)의 touch_ft6336.h 와 쓰는 법이 같습니다 (begin / readRaw / chipId).
// =====================================================================
#pragma once
#include <Preferences.h>
#include "config.h"
#include "helper.h"
#include "sfx.h"

namespace Touch {
  static uint8_t chipId = 0;            // 0 = 응답 없음, 0x46 = XPT2046 준비됨 (점검 화면용)
  static bool    calOk  = false;        // 터치 보정을 해 두었는지
  static float   K[6] = {240.0f / 4096, 0, 0, 0, 320.0f / 4096, 0};   // 화면 x = K0·ax + K1·ay + K2, y = K3·ax + K4·ay + K5

  // 터치 칩이 잰 숫자 그대로 (0~4095). 안 눌렀으면 false
  static bool readAdc(int& ax, int& ay) {
    lgfx::touch_point_t tp;
    if (!lcd.getTouchRaw(&tp, 1)) return false;
    ax = tp.x; ay = tp.y;
    return true;
  }

  static bool loadCal() {
    Preferences p; p.begin("touchcal", true);
    bool ok = p.getBytesLength("k") == sizeof(K);
    if (ok) p.getBytes("k", K, sizeof(K));
    p.end();
    return ok;
  }
  static void saveCal() {
    Preferences p; p.begin("touchcal", false);
    p.putBytes("k", K, sizeof(K));
    p.end();
  }

  static bool begin() {
    pinMode(PIN_TP_INT, INPUT);
    int ax, ay;
    readAdc(ax, ay);                    // 첫 읽기 (칩 깨우기)
    chipId = lcd.touch() ? 0x46 : 0;
    calOk = loadCal();
    return chipId != 0;
  }
  static bool needsCalibration() { return !calOk; }

  // 원시 좌표 (패널 기준 세로 0번 방향, 0..239 / 0..319)
  static bool readRaw(int16_t& x, int16_t& y) {
    static int16_t lx = -100, ly = -100;
    static bool was = false;
    int ax, ay;
    if (!readAdc(ax, ay)) { was = false; return false; }
    float fx = K[0] * ax + K[1] * ay + K[2];
    float fy = K[3] * ax + K[4] * ay + K[5];
    int16_t nx = (int16_t)constrain((int)(fx + 0.5f), 0, 239);
    int16_t ny = (int16_t)constrain((int)(fy + 0.5f), 0, 319);
    // 손가락을 가만히 대고 있어도 숫자가 1~2씩 흔들려서, 아주 작은 흔들림은 무시
    if (was && abs(nx - lx) <= 2 && abs(ny - ly) <= 2) { nx = lx; ny = ly; }
    lx = nx; ly = ny; was = true;
    x = nx; y = ny;
    return true;
  }

  static void enterMonitor() {}         // XPT2046 은 따로 할 일 없음 (누르면 INT 가 LOW)

  // ---------------------------- 터치 보정 ----------------------------
  // 3x3 연립방정식 (최소제곱) — 네 점으로 '숫자 → 화면 위치' 공식을 구함
  static bool solve3(double m[3][3], double v[3], double out[3]) {
    double det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
               - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
               + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    if (fabs(det) < 1e-9) return false;
    for (int c = 0; c < 3; c++) {
      double t[3][3];
      for (int r = 0; r < 3; r++) for (int k = 0; k < 3; k++) t[r][k] = (k == c) ? v[r] : m[r][k];
      out[c] = (t[0][0] * (t[1][1] * t[2][2] - t[1][2] * t[2][1])
              - t[0][1] * (t[1][0] * t[2][2] - t[1][2] * t[2][0])
              + t[0][2] * (t[1][0] * t[2][1] - t[1][1] * t[2][0])) / det;
    }
    return true;
  }

  static void drawTarget(int x, int y, uint16_t c) {
    lcd.drawCircle(x, y, 10, c);
    lcd.drawFastHLine(x - 16, y, 33, c);
    lcd.drawFastVLine(x, y - 16, 33, c);
    lcd.fillCircle(x, y, 2, c);
  }

  // 한 점 누르기: 꾹 누른 동안 여러 번 재서 가운데 값, 손을 떼야 다음으로
  static bool capture(int& ax, int& ay) {
    int n = 0, xs[24], ys[24];
    uint32_t t0 = millis();
    while (millis() - t0 < 60000) {                       // 1분 안에 안 누르면 그만
      int x, y;
      if (readAdc(x, y)) { if (n < 24) { xs[n] = x; ys[n] = y; n++; } }
      else if (n > 0 && n < 8) n = 0;                     // 너무 짧게 스친 것은 다시
      if (n >= 24) break;
      delay(15);
    }
    if (n < 8) return false;
    std::sort(xs, xs + n); std::sort(ys, ys + n);
    ax = xs[n / 2]; ay = ys[n / 2];
    uint32_t t = millis();
    int x, y;
    while (readAdc(x, y) && millis() - t < 5000) delay(15);   // 뗄 때까지 기다림
    delay(150);
    return true;
  }

  // 화면 네 귀퉁이 + 를 차례로 눌러 보정 (setup 이나 점검 화면에서 부름)
  static void calibrate() {
    uint8_t keepRot = Sys::rot;
    setScreenRot(0);
    const int SX[4] = {24, 216, 216, 24}, SY[4] = {24, 24, 296, 296};
    for (int attempt = 0; attempt < 3; attempt++) {
      int ax[4], ay[4];
      bool ok = true;
      for (int i = 0; i < 4 && ok; i++) {
        lcd.startWrite();
        lcd.fillScreen(C_BAR);
        text("터치 보정", 120, 112, &fonts::efontKR_24_b, C_WHITE);
        text("+ 가운데를 손톱이나 펜으로", 120, 148, &fonts::efontKR_16, C_WHITE);
        text("꾹 눌렀다가 떼세요", 120, 170, &fonts::efontKR_16, C_WHITE);
        char b[16]; snprintf(b, sizeof(b), "%d / 4", i + 1);
        text(b, 120, 200, &fonts::efontKR_16_b, C_YELLOW);
        if (attempt) text("한 번 더 해 볼게요", 120, 226, &fonts::efontKR_12, 0xFD20);
        drawTarget(SX[i], SY[i], C_YELLOW);
        lcd.endWrite();
        ok = capture(ax[i], ay[i]);
        if (ok) { drawTarget(SX[i], SY[i], C_GO); Sfx::play(SFX_TAP); delay(120); }
      }
      if (!ok) break;
      // 최소제곱으로 공식 구하기
      double m[3][3] = {}, vx[3] = {}, vy[3] = {};
      for (int i = 0; i < 4; i++) {
        double r[3] = {(double)ax[i], (double)ay[i], 1.0};
        for (int a = 0; a < 3; a++) {
          for (int c = 0; c < 3; c++) m[a][c] += r[a] * r[c];
          vx[a] += r[a] * SX[i]; vy[a] += r[a] * SY[i];
        }
      }
      double kx[3], ky[3];
      if (!solve3(m, vx, kx) || !solve3(m, vy, ky)) { Sfx::play(SFX_ERROR); continue; }
      // 네 점이 서로 맞는지 확인 (한 점을 잘못 누르면 어긋남)
      double worst = 0;
      for (int i = 0; i < 4; i++) {
        double ex = kx[0] * ax[i] + kx[1] * ay[i] + kx[2] - SX[i];
        double ey = ky[0] * ax[i] + ky[1] * ay[i] + ky[2] - SY[i];
        worst = fmax(worst, sqrt(ex * ex + ey * ey));
      }
      if (worst > 18) { Sfx::play(SFX_ERROR); continue; }
      for (int k = 0; k < 3; k++) { K[k] = (float)kx[k]; K[3 + k] = (float)ky[k]; }
      calOk = true;
      saveCal();
      lcd.fillScreen(C_BAR);
      text("터치 보정 끝!", 120, 150, &fonts::efontKR_24_b, C_WHITE);
      text("점검 화면에서 확인할 수 있어요", 120, 184, &fonts::efontKR_12, 0xBDF7);
      Sfx::play(SFX_FLAG);
      delay(1000);
      break;
    }
    setScreenRot(keepRot);
  }
}
