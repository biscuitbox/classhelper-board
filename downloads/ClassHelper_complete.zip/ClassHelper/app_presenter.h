// =====================================================================
//  app_presenter.h  —  🎤 수업 프레젠터  (3차시)
//
//  PC와 블루투스로 연결하면 보드가 '무선 키보드 + 마우스'가 됩니다.
//  아래 4장(탭)을 화면 아래에서 골라 써요.
//    ① 넘기기   : ◀ ▶, 슬라이드쇼 시작·끝, 번호로 가기
//    ② 포인터   : 레이저·펜·지우개, 화면을 문지르면 마우스가 움직이는 터치패드
//    ③ 화면·소리: 검은 화면/흰 화면, PC 소리 크게·작게·음소거, 동영상 재생
//    ④ 타이머   : 1·3·5·10분, 끝나면 화면이 깜빡이고 알림음
//  - 위쪽 [PPT]/[구글] 단추로 파워포인트 ↔ 구글 슬라이드 단축키를 바꿔요
//  - 보드 뒷면 BOOT 단추 = 다음 장 (화면을 안 보고 넘길 때)
//
//  처음 한 번: PC 블루투스 설정 → 장치 추가 → config.h 의 BT_NAME(예: ClassHelper-01)
//  연결 전에는 ①~③ 장에 연결 방법이 보이고, 연결되면 저절로 단추가 나타납니다.
//
//  ✏️ 바이브코딩으로 바꿔 보기 좋은 곳
//   - sendAction() : 단추마다 어떤 키를 보낼지
//   - PAD_SPEED    : 터치패드 마우스 빠르기
//   - PRESET_MIN   : 타이머 빠른 단추 (분)
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"
#include "ble_hid.h"

namespace AppPresenter {

static Preferences prefs;

// ------------------------------ 설정값 ------------------------------
#define PAD_SPEED   2.4f                      // 터치패드 1px 움직이면 마우스 몇 px
static const uint8_t PRESET_MIN[4] = {1, 3, 5, 10};

enum : uint8_t { TAB_SLIDE, TAB_POINTER, TAB_SCREEN, TAB_TIMER };
static const char* TAB_NAME[4] = {"넘기기", "포인터", "화면·소리", "타이머"};

// 단추가 하는 일 (번호표)
enum : uint8_t {
  A_NONE, A_PREV, A_NEXT, A_START_FIRST, A_START_HERE, A_END, A_KEYPAD,
  A_LASER, A_PEN, A_ERASER, A_ARROW, A_ERASE_ALL,
  A_BLACK, A_WHITE, A_VOL_DOWN, A_MUTE, A_VOL_UP, A_VIDEO, A_HIDE_CURSOR,
  A_T_PRESET0, A_T_PRESET1, A_T_PRESET2, A_T_PRESET3, A_T_MINUS, A_T_TOGGLE, A_T_PLUS, A_T_RESET,
  A_K0, A_K1, A_K2, A_K3, A_K4, A_K5, A_K6, A_K7, A_K8, A_K9, A_K_BACK, A_K_GO, A_K_CLOSE,
};

// ------------------------------ 상태 ------------------------------
static uint8_t tab = TAB_SLIDE;
static bool    google = false;                // false = 파워포인트, true = 구글 슬라이드
static uint8_t tool = A_ARROW;                // 포인터 장에서 지금 고른 도구
static bool    keypadOn = false;
static int     keypadNum = 0;

// 타이머 (앱 밖에 있어도 시간은 흘러요)
static uint32_t tTotal = 5 * 60000UL;         // 설정한 시간
static uint32_t tLeftPaused = 5 * 60000UL;    // 멈춰 있을 때 남은 시간
static uint32_t tEndAt = 0;
static bool     tRunning = false, tDone = false;
static uint32_t tDoneAt = 0;

// ------------------------------ 단추 목록 ------------------------------
struct Btn { int16_t x, y, w, h; uint8_t act; const char* label; bool enabled; };
static Btn  btns[20];
static int  nb = 0;
static int  pressed = -1;

static bool hidReady() { return Hid::connected(); }

static void loadPrefs() {
  prefs.begin("pres", true);
  google = prefs.getBool("google", false);
  tTotal = prefs.getUInt("ttotal", 5 * 60000UL);
  prefs.end();
  tLeftPaused = tTotal;
}
static void savePrefs() {
  prefs.begin("pres", false);
  prefs.putBool("google", google);
  prefs.putUInt("ttotal", tTotal);
  prefs.end();
}

// =====================================================================
//                              그리기
// =====================================================================
static void icon(int cx, int cy) {             // 첫 화면 아이콘: 화면 + ▶
  lcd.fillRoundRect(cx - 18, cy - 14, 36, 24, 3, C_PRES);
  lcd.fillTriangle(cx - 5, cy - 8, cx - 5, cy + 4, cx + 6, cy - 2, C_WHITE);
  lcd.fillRect(cx - 2, cy + 10, 4, 6, C_DARK);
  lcd.fillRect(cx - 10, cy + 15, 20, 3, C_DARK);
}

static void drawBtn(int i, bool down = false) {
  const Btn& b = btns[i];
  uint16_t face = !b.enabled ? 0x8410 : (b.act == tool && tab == TAB_POINTER && b.act >= A_LASER && b.act <= A_ARROW)
                                       ? C_ACCENT : C_WHITE;
  uint16_t ink  = (face == C_WHITE) ? C_BLACK : C_WHITE;
  if ((b.act == A_PREV || b.act == A_NEXT) && b.h >= 100) {    // 큰 화살표 단추
    face = b.enabled ? (b.act == A_NEXT ? C_PRES : 0x5AEB) : 0x8410;
    lcd.fillRoundRect(b.x, b.y, b.w, b.h, 12, face);
    int cx = b.x + b.w / 2, cy = b.y + b.h / 2 - 8, s = 26;
    if (b.act == A_NEXT) lcd.fillTriangle(cx - s * 2 / 3, cy - s, cx - s * 2 / 3, cy + s, cx + s, cy, C_WHITE);
    else                 lcd.fillTriangle(cx + s * 2 / 3, cy - s, cx + s * 2 / 3, cy + s, cx - s, cy, C_WHITE);
    text(b.label, cx, b.y + b.h - 18, &fonts::efontKR_16_b, C_WHITE);
  } else {
    lcd.fillRoundRect(b.x, b.y, b.w, b.h, 8, face);
    lcd.drawRoundRect(b.x, b.y, b.w, b.h, 8, C_DARK);
    text(b.label, b.x + b.w / 2, b.y + b.h / 2 + 1,
         (b.h >= 44) ? &fonts::efontKR_16_b : &fonts::efontKR_14, ink);
  }
  if (down) {
    lcd.drawRoundRect(b.x, b.y, b.w, b.h, 8, C_YELLOW);
    lcd.drawRoundRect(b.x + 1, b.y + 1, b.w - 2, b.h - 2, 7, C_YELLOW);
    lcd.drawRoundRect(b.x + 2, b.y + 2, b.w - 4, b.h - 4, 6, C_YELLOW);
  }
}

static void addBtn(int x, int y, int w, int h, uint8_t act, const char* label, bool enabled = true) {
  if (nb >= 20) return;
  btns[nb] = {(int16_t)x, (int16_t)y, (int16_t)w, (int16_t)h, act, label, enabled};
  drawBtn(nb);
  nb++;
}

static void drawModeToggle() {
  button(172, 3, 64, 24, google ? "구글" : "PPT", true, &fonts::efontKR_14);
}
static void drawConnDot() {
  int st = Hid::state();                     // 초록 = 연결됨 / 노랑 = 보안 확인 중 / 회색 = 기다리는 중
  uint16_t c = st == 2 ? 0x07E0 : (st == 1 ? C_YELLOW : 0x8410);
  lcd.fillCircle(160, 15, 5, c);
  // 배터리 (아이콘만)
  lcd.fillRect(122, 8, 26, 14, C_BAR);
  if (Sys::battery >= 0) {
    int p = Sys::battery;
    lcd.drawRect(122, 9, 20, 11, C_WHITE);
    lcd.fillRect(142, 12, 2, 5, C_WHITE);
    lcd.fillRect(124, 11, 16 * p / 100, 7, p > 50 ? C_GO : (p > 20 ? C_WAIT : C_STOP));
  }
}

static void timerText(char* buf, size_t n, uint32_t ms) {
  uint32_t s = (ms + 999) / 1000;
  snprintf(buf, n, "%02u:%02u", (unsigned)(s / 60), (unsigned)(s % 60));
}
static uint32_t timerLeft() {
  if (!tRunning) return tLeftPaused;
  int32_t d = (int32_t)(tEndAt - millis());
  return d > 0 ? (uint32_t)d : 0;
}

static void drawTabs() {
  for (int i = 0; i < 4; i++) {
    int x = i * 60;
    bool sel = (i == tab);
    lcd.fillRect(x, 278, 60, 42, sel ? C_BG : 0x31A6);
    if (sel) lcd.fillRect(x + 6, 278, 48, 4, C_PRES);
    char tb[8];
    const char* label = TAB_NAME[i];
    if (i == TAB_TIMER && tRunning && tab != TAB_TIMER) { timerText(tb, sizeof(tb), timerLeft()); label = tb; }
    text(label, x + 30, 300, &fonts::efontKR_14, sel ? C_WHITE : 0xAD55);
    if (i) lcd.drawFastVLine(x, 284, 30, 0x4208);
  }
}

static void contentClear() { lcd.fillRect(0, 30, 240, 248, C_BG); nb = 0; }

static void drawPair() {                       // 블루투스 연결 전 안내
  lcd.fillRoundRect(10, 40, 220, 228, 10, 0x18E3);
  lcd.drawRoundRect(10, 40, 220, 228, 10, 0x4A69);
  text("PC와 연결해 주세요", 120, 64, &fonts::efontKR_16_b, C_WHITE);
  text("1. PC 설정 → 블루투스", 24, 98, &fonts::efontKR_14, C_WHITE, textdatum_t::middle_left);
  text("2. 장치 추가 → Bluetooth", 24, 122, &fonts::efontKR_14, C_WHITE, textdatum_t::middle_left);
  text("3. 이 이름을 고르기", 24, 146, &fonts::efontKR_14, C_WHITE, textdatum_t::middle_left);
  lcd.fillRoundRect(24, 162, 192, 34, 8, C_BLACK);
  text(Hid::name(), 120, 180, &fonts::FreeSansBold9pt7b, C_YELLOW);
  text("다음부터는 켜기만 하면 이어져요", 120, 216, &fonts::efontKR_12, 0xAD55);
  text("PC는 '연결됨'인데 이 화면이면", 120, 236, &fonts::efontKR_12, 0x7BEF);
  text("설정 → 점검 → BT 기억 지우기", 120, 252, &fonts::efontKR_12, 0x7BEF);
}

static void drawKeypad() {
  contentClear();
  lcd.fillRoundRect(6, 34, 160, 38, 8, C_BLACK);
  char b[12];
  if (keypadNum) snprintf(b, sizeof(b), "%d", keypadNum); else strcpy(b, "-");
  text("번호", 14, 53, &fonts::efontKR_12, 0xAD55, textdatum_t::middle_left);
  lcd.setFont(&fonts::Font4);
  lcd.setTextDatum(textdatum_t::middle_right);
  lcd.setTextColor(C_WHITE);
  lcd.drawString(b, 158, 54);
  addBtn(170, 34, 64, 38, A_K_CLOSE, "닫기");
  static const char* KL[12] = {"1","2","3","4","5","6","7","8","9","지움","0","이동"};
  static const uint8_t KA[12] = {A_K1,A_K2,A_K3,A_K4,A_K5,A_K6,A_K7,A_K8,A_K9,A_K_BACK,A_K0,A_K_GO};
  for (int i = 0; i < 12; i++) addBtn(6 + (i % 3) * 77, 78 + (i / 3) * 49, 74, 45, KA[i], KL[i]);
}

static void drawTimerFace() {                   // 타이머 숫자·막대만 다시 그리기
  uint32_t left = timerLeft();
  float p = tTotal ? (float)left / tTotal : 0;
  uint16_t col = (p > 0.5f) ? C_GO : (p > 0.2f ? C_WAIT : C_STOP);
  if (!tRunning && !tDone) col = C_WHITE;
  char b[8];
  timerText(b, sizeof(b), left);
  lcd.fillRect(0, 34, 240, 110, C_BG);
  lcd.setFont(&fonts::Font7);
  lcd.setTextSize(1.4f);
  lcd.setTextDatum(textdatum_t::middle_center);
  lcd.setTextColor(col);
  lcd.drawString(b, 120, 84);
  lcd.setTextSize(1);
  lcd.fillRoundRect(10, 128, 220, 12, 6, 0x31A6);
  if (p > 0) lcd.fillRoundRect(10, 128, (int)(220 * p), 12, 6, col);
}

static void drawTimerDone(bool on) {
  lcd.fillRect(0, 30, 240, 248, on ? C_STOP : C_BG);
  lcd.setFont(&fonts::efontKR_24_b);
  lcd.setTextSize(1.6f);
  lcd.setTextDatum(textdatum_t::middle_center);
  lcd.setTextColor(C_WHITE);
  lcd.drawString("시간 끝!", 120, 130);
  lcd.setTextSize(1);
  text("화면을 누르면 멈춰요", 120, 200, &fonts::efontKR_16, C_WHITE);
  nb = 0;
}

static void drawContent() {
  lcd.startWrite();
  if (tab == TAB_TIMER && tDone) { drawTimerDone(true); lcd.endWrite(); return; }
  if (keypadOn && tab == TAB_SLIDE) { drawKeypad(); lcd.endWrite(); return; }
  contentClear();
  if (!Hid::connected() && tab != TAB_TIMER) { drawPair(); lcd.endWrite(); return; }

  switch (tab) {
    case TAB_SLIDE:
      addBtn(6,  36, 84, 142, A_PREV, "이전");
      addBtn(96, 36, 138, 142, A_NEXT, "다음");
      addBtn(6,   184, 74, 42, A_START_FIRST, "처음부터");
      addBtn(83,  184, 74, 42, A_START_HERE,  "이 장부터");
      addBtn(160, 184, 74, 42, A_END,         "끝내기");
      addBtn(6,   232, 228, 42, A_KEYPAD,     "번호로 가기");
      break;

    case TAB_POINTER:
      addBtn(4,   34, 56, 38, A_LASER,  "레이저");
      addBtn(62,  34, 56, 38, A_PEN,    "펜", !google);
      addBtn(120, 34, 56, 38, A_ERASER, "지우개", !google);
      addBtn(178, 34, 58, 38, A_ARROW,  "화살표", !google);
      // 터치패드
      lcd.fillRoundRect(6, 78, 228, 158, 10, 0x2124);
      lcd.drawRoundRect(6, 78, 228, 158, 10, 0x5AEB);
      for (int gx = 26; gx < 234; gx += 20)
        for (int gy = 96; gy < 234; gy += 20) lcd.drawPixel(gx, gy, 0x4A69);
      text("문지르면 마우스가 움직여요", 120, 146, &fonts::efontKR_14, 0x9CF3);
      text((tool == A_PEN || tool == A_ERASER) ? "펜·지우개: 문지르면 그려져요" : "톡 누르면 클릭",
           120, 168, &fonts::efontKR_12, 0x7BEF);
      addBtn(6,   240, 74, 36, A_ERASE_ALL, "다 지우기", !google);
      addBtn(83,  240, 74, 36, A_PREV, "이전");
      addBtn(160, 240, 74, 36, A_NEXT, "다음");
      break;

    case TAB_SCREEN:
      addBtn(6,   36, 111, 64, A_BLACK, "검은 화면");
      addBtn(123, 36, 111, 64, A_WHITE, "흰 화면");
      addBtn(6,   106, 74, 52, A_VOL_DOWN, "소리 -");
      addBtn(83,  106, 74, 52, A_MUTE,     "음소거");
      addBtn(160, 106, 74, 52, A_VOL_UP,   "소리 +");
      addBtn(6,   164, 111, 52, A_VIDEO,       "동영상 재생", !google);
      addBtn(123, 164, 111, 52, A_HIDE_CURSOR, "커서 숨기기", !google);
      text("슬라이드쇼 화면에서 눌러요", 120, 236, &fonts::efontKR_12, 0xAD55);
      text("검은·흰 화면은 한 번 더 누르면 돌아와요", 120, 256, &fonts::efontKR_12, 0xAD55);
      break;

    case TAB_TIMER:
      drawTimerFace();
      for (int i = 0; i < 4; i++) {
        static char lb[4][8];
        snprintf(lb[i], sizeof(lb[i]), "%u분", PRESET_MIN[i]);
        addBtn(4 + i * 59, 148, 55, 40, A_T_PRESET0 + i, lb[i]);
      }
      addBtn(6,   196, 64, 44, A_T_MINUS,  "-1분");
      addBtn(74,  196, 92, 44, A_T_TOGGLE, tRunning ? "멈춤" : "시작");
      addBtn(170, 196, 64, 44, A_T_PLUS,   "+1분");
      addBtn(6,   246, 228, 28, A_T_RESET,  "처음 시간으로");
      break;
  }
  lcd.endWrite();
}

static void drawAll() {
  lcd.startWrite();
  lcd.fillScreen(C_BG);
  drawTitleBar("프레젠터");
  drawConnDot();
  drawModeToggle();
  drawTabs();
  lcd.endWrite();
  drawContent();
}

// =====================================================================
//                         단추 → 키 보내기
// =====================================================================
static void timerSet(uint32_t ms) {
  tTotal = ms; tLeftPaused = ms; tRunning = false; tDone = false;
  savePrefs();
}

static void sendAction(uint8_t a) {
  switch (a) {
    // ① 넘기기
    case A_PREV:        Hid::key(KEY_LEFT_ARROW);  break;
    case A_NEXT:        Hid::key(KEY_RIGHT_ARROW); break;
    case A_START_FIRST: if (google) Hid::combo3(KEY_LEFT_CTRL, KEY_LEFT_SHIFT, KEY_F5);
                        else        Hid::key(KEY_F5);                         break;
    case A_START_HERE:  if (google) Hid::combo(KEY_LEFT_CTRL, KEY_F5);
                        else        Hid::combo(KEY_LEFT_SHIFT, KEY_F5);       break;
    case A_END:         Hid::key(KEY_ESC); break;

    // ② 포인터 (PPT 단축키: Ctrl+L 레이저 / Ctrl+P 펜 / Ctrl+E 지우개 / Ctrl+A 화살표 / E 다 지우기)
    case A_LASER:  if (google) Hid::key('l'); else Hid::combo(KEY_LEFT_CTRL, 'l');
                   tool = (tool == A_LASER && google) ? A_ARROW : A_LASER; break;
    case A_PEN:    Hid::combo(KEY_LEFT_CTRL, 'p'); tool = A_PEN;    break;
    case A_ERASER: Hid::combo(KEY_LEFT_CTRL, 'e'); tool = A_ERASER; break;
    case A_ARROW:  Hid::combo(KEY_LEFT_CTRL, 'a'); tool = A_ARROW;  break;
    case A_ERASE_ALL: Hid::key('e'); break;

    // ③ 화면·소리  (PPT 는 한/영 상태와 상관없는 '.' ',' 사용)
    case A_BLACK:  Hid::key(google ? 'b' : '.'); break;
    case A_WHITE:  Hid::key(google ? 'w' : ','); break;
    case A_VOL_DOWN: Hid::media(CONSUMER_CONTROL_VOLUME_DECREMENT); break;
    case A_MUTE:     Hid::media(CONSUMER_CONTROL_MUTE);             break;
    case A_VOL_UP:   Hid::media(CONSUMER_CONTROL_VOLUME_INCREMENT); break;
    case A_VIDEO:       Hid::combo(KEY_LEFT_ALT, 'p');  break;
    case A_HIDE_CURSOR: Hid::combo(KEY_LEFT_CTRL, 'h'); break;
  }
}

static void onButton(uint8_t a) {
  // 번호 키패드
  if (a >= A_K0 && a <= A_K9) {
    if (keypadNum < 1000) keypadNum = keypadNum * 10 + (a - A_K0);
    Sfx::play(SFX_KEY); drawContent(); return;
  }
  switch (a) {
    case A_KEYPAD:  keypadOn = true; keypadNum = 0; Sfx::play(SFX_TAP); drawContent(); return;
    case A_K_CLOSE: keypadOn = false; Sfx::play(SFX_TAP); drawContent(); return;
    case A_K_BACK:  keypadNum /= 10; Sfx::play(SFX_KEY); drawContent(); return;
    case A_K_GO:
      if (keypadNum > 0 && hidReady()) { Hid::typeNumber(keypadNum); Sfx::play(SFX_KEY); }
      else Sfx::play(SFX_ERROR);
      keypadOn = false; drawContent(); return;

    // ④ 타이머 (PC 연결 없이도 작동)
    case A_T_PRESET0: case A_T_PRESET1: case A_T_PRESET2: case A_T_PRESET3:
      timerSet(PRESET_MIN[a - A_T_PRESET0] * 60000UL); Sfx::play(SFX_TAP); drawContent(); return;
    case A_T_MINUS: case A_T_PLUS: {
      int32_t d = (a == A_T_PLUS) ? 60000 : -60000;
      if (tRunning) { if (d > 0 || timerLeft() > 60000) { tEndAt += d; tTotal = max<int32_t>(60000, (int32_t)tTotal + d); } }
      else { int32_t v = (int32_t)tLeftPaused + d; if (v >= 60000 && v <= 99 * 60000) { tLeftPaused = v; tTotal = v; } }
      Sfx::play(SFX_TAP); drawTimerFace(); return;
    }
    case A_T_TOGGLE:
      if (tRunning) { tLeftPaused = timerLeft(); tRunning = false; }
      else if (tLeftPaused > 0) { tEndAt = millis() + tLeftPaused; tRunning = true; tDone = false; }
      Sfx::play(SFX_TAP); drawContent(); drawTabs(); return;
    case A_T_RESET:
      tRunning = false; tLeftPaused = tTotal; tDone = false;
      Sfx::play(SFX_TAP); drawContent(); drawTabs(); return;
  }
  // 나머지 = PC 로 키 보내기
  if (!hidReady()) { Sfx::play(SFX_ERROR); toast("블루투스 연결부터 해 주세요", C_STOP); delay(600); drawContent(); return; }
  uint8_t oldTool = tool;
  sendAction(a);
  Sfx::play(SFX_KEY);
  if (tool != oldTool) drawContent();           // 도구 바뀐 것 표시
}

// =====================================================================
//                              터치패드
// =====================================================================
static struct { bool on = false; int lx = 0, ly = 0; float ax = 0, ay = 0; uint32_t t0 = 0; int dist = 0; bool drag = false; } pad;
static bool inPad(int x, int y) { return tab == TAB_POINTER && Hid::connected() && inside(x, y, 6, 78, 228, 158); }

static void padDown(int x, int y) {
  pad.on = true; pad.lx = x; pad.ly = y; pad.ax = pad.ay = 0; pad.t0 = millis(); pad.dist = 0;
  pad.drag = (tool == A_PEN || tool == A_ERASER);
  if (pad.drag && hidReady()) Hid::mouseDown();          // 펜·지우개: 누른 채로 움직이면 그려짐
}
static void padMove(int x, int y) {
  int dx = x - pad.lx, dy = y - pad.ly;
  pad.lx = x; pad.ly = y;
  pad.dist += abs(dx) + abs(dy);
  pad.ax += dx * PAD_SPEED; pad.ay += dy * PAD_SPEED;
  int mx = (int)pad.ax, my = (int)pad.ay;
  pad.ax -= mx; pad.ay -= my;
  if (hidReady()) Hid::mouseMove(mx, my);
}
static void padUp() {
  pad.on = false;
  if (!hidReady()) return;
  if (pad.drag) Hid::mouseUp();
  else if (pad.dist < 8 && millis() - pad.t0 < 300) { Hid::click(); Sfx::play(SFX_KEY); }
}

// =====================================================================
//                     앱 약속 4가지 (교탁 도우미가 부름)
// =====================================================================
static void start() {
  static bool loaded = false;
  if (!loaded) { loadPrefs(); loaded = true; }
  pressed = -1; pad.on = false; keypadOn = false;
  drawAll();
}

static void update() {
  uint32_t now = millis();
  // PC 연결 상태 점
  static bool lastConn = false;
  bool c = Hid::connected();
  if (c != lastConn) {                       // 연결되거나 끊기면 화면을 다시 그림
    lastConn = c;
    drawConnDot();
    if (tab != TAB_TIMER) { keypadOn = false; pressed = -1; pad.on = false; drawContent(); }
    Sfx::play(c ? SFX_FLAG : SFX_UNFLAG);
  }
  static int lastSt = -1;
  int st = Hid::state();
  static uint32_t lastBat = 0;
  if (st != lastSt || now - lastBat > 15000) { lastSt = st; lastBat = now; drawConnDot(); }

  // 타이머
  if (tRunning && timerLeft() == 0) {
    tRunning = false; tDone = true; tDoneAt = now; tLeftPaused = 0;
    Sfx::play(SFX_ALARM);
    tab = TAB_TIMER; keypadOn = false;           // 어느 장에 있든 타이머 장으로
    drawTabs(); drawContent();
  }
  static uint32_t lastTick = 0;
  if (now - lastTick >= 250) {
    lastTick = now;
    if (tDone) {
      bool on = ((now - tDoneAt) / 500) % 2 == 0;
      static bool lastOn = true;
      if (tab == TAB_TIMER && on != lastOn) { lastOn = on; lcd.startWrite(); drawTimerDone(on); lcd.endWrite(); }
      if (now - tDoneAt > 60000) { tDone = false; tLeftPaused = tTotal; if (tab == TAB_TIMER) drawContent(); }
    } else if (tRunning) {
      static uint32_t lastSec = 0;
      uint32_t s = timerLeft() / 1000;
      if (s != lastSec) {
        lastSec = s;
        if (tab == TAB_TIMER) drawTimerFace(); else drawTabs();
      }
    }
  }
}

static int btnAt(int x, int y) {
  for (int i = 0; i < nb; i++)
    if (inside(x, y, btns[i].x, btns[i].y, btns[i].w, btns[i].h)) return i;
  return -1;
}

static void touch(uint8_t ev, int x, int y) {
  if (ev == TOUCH_DOWN) {
    if (tab == TAB_TIMER && tDone) {             // 시간 끝 화면 → 누르면 멈춤
      tDone = false; tLeftPaused = tTotal; Sfx::play(SFX_TAP); drawContent(); return;
    }
    if (inPad(x, y)) { padDown(x, y); return; }
    pressed = btnAt(x, y);
    if (pressed >= 0 && btns[pressed].enabled) drawBtn(pressed, true);
    return;
  }
  if (ev == TOUCH_MOVE) {
    if (pad.on) padMove(x, y);
    return;
  }
  // TOUCH_UP
  if (pad.on) { padUp(); return; }

  if (y < 30) {                                  // 제목줄
    if (x >= 168) { google = !google; savePrefs(); tool = A_ARROW; Sfx::play(SFX_TAP); drawModeToggle(); drawContent(); }
    return;
  }
  if (y >= 278) {                                // 아래 탭
    uint8_t t = constrain(x / 60, 0, 3);
    if (t != tab) { tab = t; keypadOn = false; Sfx::play(SFX_TAP); drawTabs(); drawContent(); }
    pressed = -1;
    return;
  }
  int i = pressed;
  pressed = -1;
  if (i < 0 || i >= nb) return;
  drawBtn(i);
  if (!btns[i].enabled) { Sfx::play(SFX_ERROR); return; }
  if (btnAt(x, y) != i) return;                  // 손가락을 단추 밖으로 빼면 취소
  onButton(btns[i].act);
}

static void stop() {
  if (pad.on && pad.drag && hidReady()) Hid::mouseUp();   // 눌린 채로 남지 않게
  pad.on = false;
  savePrefs();
}

// 보드 뒷면 BOOT 단추 = 다음 장
static void bootButton() {
  if (hidReady()) { Hid::key(KEY_RIGHT_ARROW); Sfx::play(SFX_KEY); }
  else Sfx::play(SFX_ERROR);
}

const App app = {
  "프레젠터", "PPT 넘기기·포인터·타이머", C_PRES, icon,
  start, update, touch, stop,
  bootButton,  // BOOT 버튼 = 다음 장
  true,        // 수업 중 화면이 어두워지지 않게
  true         // 완성!
};

}  // namespace AppPresenter
