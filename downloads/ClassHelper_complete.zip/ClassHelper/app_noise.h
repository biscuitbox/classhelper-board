// =====================================================================
//  app_noise.h  —  🚦 교실 소음 신호등  (2차시)
//
//  보드 마이크로 교실 소리 크기를 재서 화면 전체 색으로 알려 줍니다.
//    초록 = 좋아요 / 노랑 = 조금만 작게 / 빨강 = 너무 시끄러워요
//  - 모드: 수업 / 모둠(너그럽게) / 시험(엄격하게) — 모드마다 기준이 달라요
//  - [기준] : 교실이 조용할 때 눌러서 "조용한 소리"를 저장 (처음 켤 때는 자동)
//  - 경고음: 빨강이 2초 넘게 이어질 때만 울리고, 한 번 울리면 10초 쉬어요
//
//  ✏️ 바이브코딩으로 바꿔 보기 좋은 곳
//   - THRESH : 모드별 노랑·빨강 기준 (조용할 때보다 몇 단계 커지면?)
//   - MSG    : 화면에 나오는 말
//   - 색      : C_GO / C_WAIT / C_STOP (helper.h)
// =====================================================================
#pragma once
#include "helper.h"
#include "sfx.h"
#include "mic.h"

namespace AppNoise {

static Preferences prefs;
static LGFX_Sprite meter(&lcd);     // 소음 막대 (깜빡임 없이 그리려고 '그림판'에 먼저 그림)
static LGFX_Sprite graph(&lcd);     // 최근 1분 그래프

// ------------------------------ 설정값 ------------------------------
enum : uint8_t { GREEN = 0, YELLOW = 1, RED = 2 };
static const char* MODE_NAME[3] = {"수업", "모둠", "시험"};
// 모드별 [노랑 기준, 빨강 기준] — '조용할 때'보다 몇 단계(dB) 커졌을 때인지
static const float THRESH[3][2] = { {10, 18},    // 수업
                                    {15, 24},    // 모둠 활동: 너그럽게
                                    { 6, 12} };  // 시험: 엄격하게
static const float SCALE_MAX = 30;               // 막대 끝 = +30 단계

static const char* MSG[3][2] = {
  {"좋아요!",          "지금처럼 해 주세요"},
  {"조금만 작게",       "목소리를 줄여 볼까요?"},
  {"너무 시끄러워요!",  "잠깐 멈추고 조용히"},
};
static const uint16_t STATE_COLOR[3] = { C_GO, C_WAIT, C_STOP };

#define RED_BEEP_MS      1400    // 빨강이 된 뒤 이만큼 더 이어지면 경고음 (빨강 판정 0.6초 + 1.4초 = 2초)
#define BEEP_COOLDOWN_MS 10000   // 한 번 울리면 10초 쉬기
#define CAL_MS           3000    // 기준 맞추기: 3초 동안 조용한 소리 재기

// ------------------------------ 상태 ------------------------------
static uint8_t  mode = 0;
static bool     beepOn = true;
static float    baseDb = -60;            // 조용할 때 소리 (저장됨)
static bool     hasBase = false;
static float    level = 0;               // 부드럽게 만든 '조용할 때보다 얼마나 큰지'
static uint8_t  state = GREEN, cand = GREEN;
static uint32_t candSince = 0, redSince = 0, lastBeep = 0;
static uint8_t  hist[60];                // 1초마다 최댓값 (0~SCALE_MAX)
static uint8_t  histPos = 0;
static float    secMax = 0;
static uint32_t secStart = 0;
static bool     calibrating = false;
static uint32_t calStart = 0;
static double   calSum = 0;
static int      calN = 0;
static int      pressedBtn = -1;

static void loadPrefs() {
  prefs.begin("noise", true);
  mode    = prefs.getUChar("mode", 0);
  beepOn  = prefs.getBool("beep", true);
  hasBase = prefs.isKey("base");
  baseDb  = prefs.getFloat("base", -60);
  prefs.end();
  if (mode > 2) mode = 0;
}
static void savePrefs() {
  prefs.begin("noise", false);
  prefs.putUChar("mode", mode);
  prefs.putBool("beep", beepOn);
  if (hasBase) prefs.putFloat("base", baseDb);
  prefs.end();
}

// =====================================================================
//                              그리기
// =====================================================================
// 첫 화면 아이콘: 작은 신호등
static void icon(int cx, int cy) {
  lcd.fillRoundRect(cx - 12, cy - 21, 24, 42, 6, C_BLACK);
  lcd.fillCircle(cx, cy - 12, 5, C_STOP);
  lcd.fillCircle(cx, cy,      5, C_WAIT);
  lcd.fillCircle(cx, cy + 12, 5, C_GO);
}

static void drawBeepButton() {
  button(166, 3, 70, 24, beepOn ? "경고음 켬" : "경고음 끔", beepOn, &fonts::efontKR_12,
         0x4A69, C_WHITE);
}

static uint16_t dim(uint16_t c) {         // 꺼진 신호등 색 (어둡게)
  uint8_t r = ((c >> 11) & 0x1F) << 3, g = ((c >> 5) & 0x3F) << 2, b = (c & 0x1F) << 3;
  return rgb(r / 5, g / 5, b / 5);
}

static void drawPanel() {
  uint16_t bg = STATE_COLOR[state];
  uint16_t ink = (state == YELLOW) ? C_BLACK : C_WHITE;
  lcd.startWrite();
  lcd.fillRect(0, 30, 240, 168, bg);
  char m[20];
  snprintf(m, sizeof(m), "%s 모드", MODE_NAME[mode]);
  text(m, 8, 42, &fonts::efontKR_12, ink, textdatum_t::middle_left);

  // 신호등 (왼쪽부터 빨강·노랑·초록)
  lcd.fillRoundRect(30, 50, 180, 56, 28, C_BLACK);
  const uint8_t order[3] = {RED, YELLOW, GREEN};
  for (int i = 0; i < 3; i++) {
    uint8_t s = order[i];
    int cx = 66 + i * 54;
    lcd.fillCircle(cx, 78, 22, (s == state) ? STATE_COLOR[s] : dim(STATE_COLOR[s]));
    if (s == state) lcd.drawCircle(cx, 78, 23, C_WHITE);
  }

  // 큰 글자
  lcd.setFont(&fonts::efontKR_24_b);
  lcd.setTextSize(state == RED ? 1.15f : 1.5f);   // 긴 말은 조금 작게
  lcd.setTextDatum(textdatum_t::middle_center);
  lcd.setTextColor(ink);
  lcd.drawString(MSG[state][0], 120, 140);
  lcd.setTextSize(1);
  text(MSG[state][1], 120, 178, &fonts::efontKR_16, ink);
  lcd.endWrite();
}

static void drawMeter() {
  meter.fillScreen(C_BG);
  meter.setFont(&fonts::efontKR_12);
  meter.setTextColor(C_WHITE);
  meter.setTextDatum(textdatum_t::middle_left);
  meter.drawString("소음", 4, 21);
  const int bx = 36, bw = 172, by = 10, bh = 22;
  meter.fillRect(bx, by, bw, bh, 0x2104);
  float y1 = THRESH[mode][0], y2 = THRESH[mode][1];
  int w = (int)(bw * constrain(level / SCALE_MAX, 0.0f, 1.0f));
  int x1 = bx + (int)(bw * y1 / SCALE_MAX), x2 = bx + (int)(bw * y2 / SCALE_MAX);
  // 구간별 색으로 채우기
  meter.fillRect(bx, by, min(w, x1 - bx), bh, C_GO);
  if (w > x1 - bx) meter.fillRect(x1, by, min(w, x2 - bx) - (x1 - bx), bh, C_WAIT);
  if (w > x2 - bx) meter.fillRect(x2, by, w - (x2 - bx), bh, C_STOP);
  // 기준선
  meter.fillRect(x1, by - 4, 2, bh + 8, C_WAIT);
  meter.fillRect(x2, by - 4, 2, bh + 8, C_STOP);
  meter.drawRect(bx, by, bw, bh, C_DARK);
  char b[8];
  snprintf(b, sizeof(b), "%d", (int)(level + 0.5f));
  meter.setTextDatum(textdatum_t::middle_right);
  meter.drawString(b, 236, 21);
  meter.pushSprite(0, 198);
}

static void drawGraph() {
  graph.fillScreen(C_BG);
  graph.setFont(&fonts::efontKR_12);
  graph.setTextColor(0xAD55);
  graph.setTextDatum(textdatum_t::middle_left);
  graph.drawString("최근", 4, 12);
  graph.drawString("1분", 4, 28);
  const int gx = 36, gy = 2, gh = 36;
  graph.drawFastHLine(gx, gy + gh, 180, C_DARK);
  int yl = gy + gh - (int)(gh * THRESH[mode][0] / SCALE_MAX);
  int rl = gy + gh - (int)(gh * THRESH[mode][1] / SCALE_MAX);
  for (int x = gx; x < gx + 180; x += 4) { graph.drawPixel(x, yl, C_WAIT); graph.drawPixel(x, rl, C_STOP); }
  for (int i = 0; i < 60; i++) {
    uint8_t v = hist[(histPos + i) % 60];          // 왼쪽이 오래된 값
    int h = gh * v / (int)SCALE_MAX;
    uint16_t c = v >= THRESH[mode][1] ? C_STOP : (v >= THRESH[mode][0] ? C_WAIT : C_GO);
    if (h > 0) graph.fillRect(gx + i * 3, gy + gh - h, 2, h, c);
  }
  graph.pushSprite(0, 240);
}

static void drawButtons() {
  lcd.fillRect(0, 282, 240, 38, C_BG);
  for (int i = 0; i < 3; i++) button(4 + i * 58, 286, 54, 30, MODE_NAME[i], i == mode);
  button(178, 286, 58, 30, "기준", false, &fonts::efontKR_16, 0x4A69, C_WHITE);
}

static void drawCalibration(int secLeft) {
  lcd.startWrite();
  lcd.fillRect(0, 30, 240, 168, C_BAR);
  text("조용히 해 주세요", 120, 70, &fonts::efontKR_24_b, C_WHITE);
  text("조용한 소리를 재고 있어요", 120, 104, &fonts::efontKR_16, 0xBDF7);
  char b[8];
  snprintf(b, sizeof(b), "%d", secLeft);
  lcd.setFont(&fonts::Font7);
  lcd.setTextSize(1);
  lcd.setTextDatum(textdatum_t::middle_center);
  lcd.setTextColor(C_WHITE, C_BAR);
  lcd.drawString(b, 120, 156);
  lcd.endWrite();
}

static void drawAll() {
  lcd.startWrite();
  lcd.fillScreen(C_BG);
  drawTitleBar("소음 신호등");
  drawBeepButton();
  drawButtons();
  lcd.endWrite();
  if (calibrating) drawCalibration(3); else drawPanel();
  drawMeter();
  drawGraph();
}

// =====================================================================
//                              동작
// =====================================================================
static void startCalibration() {
  calibrating = true;
  calStart = millis() + 400;              // 버튼 소리가 끝난 뒤부터 재기
  calSum = 0; calN = 0;
  drawCalibration(3);
}

static void finishCalibration() {
  calibrating = false;
  if (calN > 5) { baseDb = (float)(calSum / calN); hasBase = true; savePrefs(); }
  level = 0; state = cand = GREEN; candSince = millis();
  drawPanel();
  Sfx::play(SFX_FLAG);
}

// 새 측정값 하나 처리
static void onSample(float db) {
  uint32_t now = millis();
  if (calibrating) {
    if ((int32_t)(now - calStart) >= 0) { calSum += db; calN++; }
    return;
  }
  float rel = constrain(db - baseDb, 0.0f, SCALE_MAX);
  // 커질 때는 빨리, 작아질 때는 천천히 따라가기 (깜빡임 방지)
  level += (rel - level) * (rel > level ? 0.45f : 0.08f);

  uint8_t target = level >= THRESH[mode][1] ? RED : (level >= THRESH[mode][0] ? YELLOW : GREEN);
  if (target != cand) { cand = target; candSince = now; }
  uint32_t need = (cand > state) ? 600 : 1500;        // 나빠질 땐 0.6초, 좋아질 땐 1.5초 유지돼야 바뀜
  if (cand != state && now - candSince >= need) {
    state = cand;
    if (state == RED) redSince = now;
    drawPanel();
  }
  // 경고음
  if (beepOn && state == RED && now - redSince >= RED_BEEP_MS && now - lastBeep >= BEEP_COOLDOWN_MS) {
    Sfx::play(SFX_ALERT);
    lastBeep = now;
  }
  if (level > secMax) secMax = level;
}

// =====================================================================
//                     앱 규칙 4가지 (교탁 도우미가 부름)
// =====================================================================
static void start() {
  static bool loaded = false;
  if (!loaded) {
    loadPrefs();
    meter.createSprite(240, 42);
    graph.createSprite(240, 42);
    memset(hist, 0, sizeof(hist));
    loaded = true;
  }
  level = 0; state = cand = GREEN; candSince = millis();
  secMax = 0; secStart = millis();
  pressedBtn = -1;
  Mic::start();
  calibrating = false;
  drawAll();
  if (!hasBase) startCalibration();       // 처음 쓸 때는 기준부터 맞추기
}

static void update() {
  uint32_t now = millis();
  while (Mic::hasNew()) onSample(Mic::db());

  if (calibrating) {
    static int shown = -1;
    int left = 3 - (int)((int32_t)(now - calStart) / 1000);
    if (left < 1) left = 1;
    if (left != shown) { shown = left; drawCalibration(left); }
    if ((int32_t)(now - calStart) >= CAL_MS) { shown = -1; finishCalibration(); }
    return;
  }

  static uint32_t lastMeter = 0;
  if (now - lastMeter >= 80) { lastMeter = now; drawMeter(); }

  if (now - secStart >= 1000) {           // 1초마다 그래프에 한 칸
    secStart = now;
    hist[histPos] = (uint8_t)(secMax + 0.5f);
    histPos = (histPos + 1) % 60;
    secMax = 0;
    drawGraph();
  }
}

static int buttonAt(int x, int y) {
  if (y < 284) return -1;
  if (x < 4 + 3 * 58) return constrain((x - 4) / 58, 0, 2);
  return 3;
}

static void touch(uint8_t ev, int x, int y) {
  if (ev == TOUCH_DOWN) {
    pressedBtn = buttonAt(x, y);
    if (pressedBtn >= 0 && pressedBtn < 3) buttonPressed(4 + pressedBtn * 58, 286, 54, 30);
    if (pressedBtn == 3) buttonPressed(178, 286, 58, 30);
    return;
  }
  if (ev != TOUCH_UP) return;

  if (inside(x, y, 166, 0, 74, 30)) {                    // 경고음 켜고 끄기
    beepOn = !beepOn; savePrefs(); drawBeepButton();
    Sfx::play(SFX_TAP);
    return;
  }
  int b = buttonAt(x, y);
  int was = pressedBtn;
  pressedBtn = -1;
  if (b < 0 || b != was) { drawButtons(); return; }
  Sfx::play(SFX_TAP);
  if (b < 3) {
    mode = b; savePrefs();
    drawButtons();
    if (!calibrating) drawPanel();
    drawGraph();
  } else {
    drawButtons();
    startCalibration();
  }
}

static void stop() {
  Mic::stop();                            // ⚠️ 나갈 때 마이크 끄기
  savePrefs();
}

const App app = {
  "소음 신호등", "교실 소리를 색으로 보여요", C_NOISE, icon,
  start, update, touch, stop,
  nullptr,   // BOOT 버튼: 안 씀
  true,      // 화면이 계속 보여야 하니 자동으로 어두워지지 않음
  true       // 완성!
};

}  // namespace AppNoise
