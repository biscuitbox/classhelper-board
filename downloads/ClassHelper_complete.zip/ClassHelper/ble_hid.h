// =====================================================================
//  ble_hid.h  —  보드를 '블루투스 키보드 + 마우스 + 소리 조절기'로 만들기
//
//  PC의 블루투스 설정 → 장치 추가 → config.h 의 BT_NAME(예: ClassHelper-01)을
//  한 번 고르면 연결됩니다. 다음부터는 보드를 켜면 저절로 다시 연결돼요.
//  보드 패키지(esp32 3.x)에 들어 있는 BLE 라이브러리만 씁니다 — 따로 설치할 것 없음.
//
//  앱에서 쓰는 법
//    Hid::key(KEY_RIGHT_ARROW);            // 키 하나 누르고 떼기
//    Hid::key('.');                        // 글자 키
//    Hid::combo(KEY_LEFT_CTRL, 'l');       // Ctrl+L 같은 두 키 조합
//    Hid::combo(KEY_LEFT_SHIFT, KEY_F5);   // Shift+F5
//    Hid::combo3(KEY_LEFT_CTRL, KEY_LEFT_SHIFT, KEY_F5);  // 세 키 조합
//    Hid::typeNumber(12);                  // 숫자 12 를 치고 Enter (PPT 12번 슬라이드로)
//    Hid::mouseMove(dx, dy);               // 마우스 움직이기 (-127 ~ 127)
//    Hid::mouseDown(); Hid::mouseUp(); Hid::click();
//    Hid::media(CONSUMER_CONTROL_VOLUME_INCREMENT);   // 소리 크게 / _DECREMENT / CONSUMER_CONTROL_MUTE
//    Hid::connected()                      // PC와 블루투스로 연결됐으면 true
//
//  💡 글자 단축키(b, w, e 등)는 PC가 '한글' 입력 상태면 안 먹을 수 있어요.
//     그래서 PPT 검은 화면은 'b' 대신 '.', 흰 화면은 'w' 대신 ',' 를 씁니다.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEHIDDevice.h>
#include <BLESecurity.h>
#include "config.h"

// ---------- 키 이름 (아두이노 Keyboard 라이브러리와 같은 번호) ----------
#define KEY_LEFT_CTRL   0x80
#define KEY_LEFT_SHIFT  0x81
#define KEY_LEFT_ALT    0x82
#define KEY_LEFT_GUI    0x83     // 윈도우 키
#define KEY_UP_ARROW    0xDA
#define KEY_DOWN_ARROW  0xD9
#define KEY_LEFT_ARROW  0xD8
#define KEY_RIGHT_ARROW 0xD7
#define KEY_BACKSPACE   0xB2
#define KEY_TAB         0xB3
#define KEY_RETURN      0xB0
#define KEY_ESC         0xB1
#define KEY_PAGE_UP     0xD3
#define KEY_PAGE_DOWN   0xD6
#define KEY_HOME        0xD2
#define KEY_END         0xD5
#define KEY_F5          0xC6
#define CONSUMER_CONTROL_PLAY_PAUSE       0x00CD
#define CONSUMER_CONTROL_MUTE             0x00E2
#define CONSUMER_CONTROL_VOLUME_INCREMENT 0x00E9
#define CONSUMER_CONTROL_VOLUME_DECREMENT 0x00EA
#define MOUSE_LEFT 0x01

namespace Hid {

// ---------- HID 보고서 모양 (키보드 1 / 마우스 2 / 소리 조절 3) ----------
static const uint8_t REPORT_MAP[] = {
  // 키보드 — Report ID 1
  0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
  0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,  // 조합키 8개
  0x95, 0x01, 0x75, 0x08, 0x81, 0x01,                                                              // 예약 1바이트
  0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02,                          // LED (출력)
  0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
  0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x73, 0x05, 0x07, 0x19, 0x00, 0x29, 0x73, 0x81, 0x00,  // 키 6개
  0xC0,
  // 마우스 — Report ID 2
  0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85, 0x02, 0x09, 0x01, 0xA1, 0x00,
  0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02,  // 단추 3개
  0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
  0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,  // X, Y, 휠
  0xC0, 0xC0,
  // 소리 조절(Consumer) — Report ID 3
  0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x03,
  0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
  0xC0
};

// 아스키 글자 → HID 키 번호 (0x80 이 붙으면 Shift 필요)
#define SH 0x80
static const uint8_t ASCII_MAP[128] = {
  0,0,0,0,0,0,0,0, 0x2A,0x2B,0x28,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0x29,0,0,0,0,
  0x2C, 0x1E|SH, 0x34|SH, 0x20|SH, 0x21|SH, 0x22|SH, 0x24|SH, 0x34,   //  !"#$%&'
  0x26|SH, 0x27|SH, 0x25|SH, 0x2E|SH, 0x36, 0x2D, 0x37, 0x38,         // ()*+,-./
  0x27, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26,         // 0-9
  0x33|SH, 0x33, 0x36|SH, 0x2E, 0x37|SH, 0x38|SH, 0x1F|SH,            // :;<=>?@
  0x04|SH,0x05|SH,0x06|SH,0x07|SH,0x08|SH,0x09|SH,0x0A|SH,0x0B|SH,0x0C|SH,0x0D|SH,0x0E|SH,0x0F|SH,0x10|SH,
  0x11|SH,0x12|SH,0x13|SH,0x14|SH,0x15|SH,0x16|SH,0x17|SH,0x18|SH,0x19|SH,0x1A|SH,0x1B|SH,0x1C|SH,0x1D|SH, // A-Z
  0x2F, 0x31, 0x30, 0x23|SH, 0x2D|SH, 0x35,                           // [\]^_`
  0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,
  0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1A,0x1B,0x1C,0x1D,    // a-z
  0x2F|SH, 0x31|SH, 0x30|SH, 0x35|SH, 0                               // {|}~
};
#undef SH

static BLEHIDDevice*      hid      = nullptr;
static BLECharacteristic* inKey    = nullptr;
static BLECharacteristic* inMouse  = nullptr;
static BLECharacteristic* inMedia  = nullptr;
static volatile bool      linked   = false;
static uint8_t            mods = 0, keys[6] = {0}, buttons = 0;

class ServerCb : public BLEServerCallbacks {
  void onConnect(BLEServer*) override    { linked = true; }
  void onDisconnect(BLEServer*) override {
    linked = false;
    BLEDevice::startAdvertising();          // 끊기면 다시 연결을 기다림
  }
};
class SecurityCb : public BLESecurityCallbacks {
  bool     onSecurityRequest() override       { return true; }
  uint32_t onPassKeyRequest() override        { return 0; }
  void     onPassKeyNotify(uint32_t) override {}
  bool     onConfirmPIN(uint32_t) override    { return true; }
#if defined(CONFIG_BLUEDROID_ENABLED)
  void onAuthenticationComplete(esp_ble_auth_cmpl_t) override {}
#elif defined(CONFIG_NIMBLE_ENABLED)
  void onAuthenticationComplete(ble_gap_conn_desc*) override {}
#endif
};

static constexpr bool available() { return true; }
static bool connected() { return linked; }
static const char* name() { return BT_NAME; }

// setup() 에서 한 번만 부릅니다 (ClassHelper.ino 가 알아서 부름)
static void begin() {
  BLEDevice::init(BT_NAME);
  BLESecurity* sec = new BLESecurity();
  sec->setCapability(ESP_IO_CAP_NONE);           // 숫자 입력 없이 바로 연결 (Just Works)
  sec->setAuthenticationMode(true, false, true); // 연결 정보 기억(본딩)
  BLEDevice::setSecurityCallbacks(new SecurityCb());

  BLEServer* server = BLEDevice::createServer();
  server->setCallbacks(new ServerCb());

  hid = new BLEHIDDevice(server);
  inKey   = hid->inputReport(1);
  hid->outputReport(1);                          // 캡스락 등 LED (받기만 함)
  inMouse = hid->inputReport(2);
  inMedia = hid->inputReport(3);

  hid->manufacturer()->setValue("Maker Teacher");
  hid->pnp(0x02, 0x303A, 0x4001, 0x0100);
  hid->hidInfo(0x00, 0x01);
  hid->reportMap((uint8_t*)REPORT_MAP, sizeof(REPORT_MAP));
  hid->startServices();
  hid->setBatteryLevel(100);

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->setAppearance(0x03C1);                    // 키보드 모양
  adv->addServiceUUID(hid->hidService()->getUUID());
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
}

static void setBattery(uint8_t pct) { if (hid) hid->setBatteryLevel(pct); }

// ---------- 키보드 ----------
static void sendKeys() {
  if (!linked || !inKey) return;
  uint8_t r[8] = {mods, 0, keys[0], keys[1], keys[2], keys[3], keys[4], keys[5]};
  inKey->setValue(r, sizeof(r));
  inKey->notify();
}
static void press(uint8_t k) {
  uint8_t code;
  if (k >= 136)      code = k - 136;                          // 화살표·F5 같은 특수 키
  else if (k >= 128) { mods |= (1 << (k - 128)); sendKeys(); return; }  // Ctrl·Shift·Alt·윈도우
  else {
    code = ASCII_MAP[k];
    if (code & 0x80) { mods |= 0x02; code &= 0x7F; }          // 대문자·기호는 Shift
  }
  if (!code) return;
  for (int i = 0; i < 6; i++) if (keys[i] == code) { sendKeys(); return; }
  for (int i = 0; i < 6; i++) if (!keys[i]) { keys[i] = code; break; }
  sendKeys();
}
static void releaseAll() {
  mods = 0; memset(keys, 0, sizeof(keys));
  sendKeys();
}

static void key(uint8_t k)                          { press(k); delay(12); releaseAll(); }
static void combo(uint8_t m, uint8_t k)             { press(m); press(k); delay(20); releaseAll(); }
static void combo3(uint8_t a, uint8_t b, uint8_t k) { press(a); press(b); press(k); delay(20); releaseAll(); }
static void typeNumber(int n) {
  char buf[8];
  snprintf(buf, sizeof(buf), "%d", n);
  for (char* p = buf; *p; p++) { key(*p); delay(12); }
  key(KEY_RETURN);
}

// ---------- 마우스 ----------
static void sendMouse(int8_t dx, int8_t dy) {
  if (!linked || !inMouse) return;
  uint8_t r[4] = {buttons, (uint8_t)dx, (uint8_t)dy, 0};
  inMouse->setValue(r, sizeof(r));
  inMouse->notify();
}
static void mouseMove(int dx, int dy) {
  dx = constrain(dx, -127, 127); dy = constrain(dy, -127, 127);
  if (dx || dy) sendMouse(dx, dy);
}
static void mouseDown() { buttons |= MOUSE_LEFT;  sendMouse(0, 0); }
static void mouseUp()   { buttons &= ~MOUSE_LEFT; sendMouse(0, 0); }
static void click()     { mouseDown(); delay(15); mouseUp(); }

// ---------- 소리 크게·작게·음소거 ----------
static void media(uint16_t usage) {
  if (!linked || !inMedia) return;
  uint8_t r[2] = {(uint8_t)(usage & 0xFF), (uint8_t)(usage >> 8)};
  inMedia->setValue(r, 2); inMedia->notify();
  delay(20);
  r[0] = r[1] = 0;
  inMedia->setValue(r, 2); inMedia->notify();
}

}  // namespace Hid
