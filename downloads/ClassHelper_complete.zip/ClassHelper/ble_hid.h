// =====================================================================
//  ble_hid.h  —  보드를 '블루투스 키보드 + 마우스 + 소리 조절기'로 만들기
//
//  PC의 블루투스 설정 → 장치 추가 → config.h 의 BT_NAME(예: ClassHelper-01)을
//  한 번 고르면 연결됩니다. 다음부터는 보드를 켜면 저절로 다시 연결돼요.
//  보드 패키지(esp32 3.x)에 들어 있는 BLE 라이브러리만 씁니다 — 따로 설치할 것 없음.
//
//  앱에서 쓰는 법
//    Hid::key(KEY_RIGHT_ARROW);            // 키 하나 누르고 떼기
//    Hid::key('.');                        // 글자 키
//    Hid::combo(KEY_LEFT_CTRL, 'l');       // Ctrl+L 같은 두 키 조합
//    Hid::combo(KEY_LEFT_SHIFT, KEY_F5);   // Shift+F5
//    Hid::combo3(KEY_LEFT_CTRL, KEY_LEFT_SHIFT, KEY_F5);  // 세 키 조합
//    Hid::typeNumber(12);                  // 숫자 12 를 치고 Enter (PPT 12번 슬라이드로)
//    Hid::mouseMove(dx, dy);               // 마우스 움직이기 (-127 ~ 127)
//    Hid::mouseDown(); Hid::mouseUp(); Hid::click();
//    Hid::media(CONSUMER_CONTROL_VOLUME_INCREMENT);   // 소리 크게 / _DECREMENT / CONSUMER_CONTROL_MUTE
//    Hid::connected()                      // PC와 블루투스로 연결됐으면 true
//    Hid::state()                          // 0 기다리는 중 / 1 연결 중(보안 확인 전) / 2 연결됨
//    Hid::bondCount(), Hid::forgetAll()    // 기억한 PC 수 / 모두 잊기 (점검 화면에서 씀)
//
//  💡 글자 단축키(b, w, e 등)는 PC가 '한글' 입력 상태면 안 먹을 수 있어요.
//     그래서 PPT 검은 화면은 'b' 대신 '.', 흰 화면은 'w' 대신 ',' 를 씁니다.
// =====================================================================
#pragma once
#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEHIDDevice.h>
#include <BLESecurity.h>
#if defined(CONFIG_NIMBLE_ENABLED)
  #include <host/ble_gap.h>
  #include <host/ble_store.h>
  #include <host/ble_gatt.h>
  #include <host/ble_hs_mbuf.h>
  #include <host/ble_hs.h>
#else
  #include <esp_gap_ble_api.h>
#endif
#include "config.h"

// ---------- 키 이름 (아두이노 Keyboard 라이브러리와 같은 번호) ----------
#define KEY_LEFT_CTRL   0x80
#define KEY_LEFT_SHIFT  0x81
#define KEY_LEFT_ALT    0x82
#define KEY_LEFT_GUI    0x83     // 윈도우 키
#define KEY_UP_ARROW    0xDA
#define KEY_DOWN_ARROW  0xD9
#define KEY_LEFT_ARROW  0xD8
#define KEY_RIGHT_ARROW 0xD7
#define KEY_BACKSPACE   0xB2
#define KEY_TAB         0xB3
#define KEY_RETURN      0xB0
#define KEY_ESC         0xB1
#define KEY_PAGE_UP     0xD3
#define KEY_PAGE_DOWN   0xD6
#define KEY_HOME        0xD2
#define KEY_END         0xD5
#define KEY_F5          0xC6
#define CONSUMER_CONTROL_PLAY_PAUSE       0x00CD
#define CONSUMER_CONTROL_MUTE             0x00E2
#define CONSUMER_CONTROL_VOLUME_INCREMENT 0x00E9
#define CONSUMER_CONTROL_VOLUME_DECREMENT 0x00EA
#define MOUSE_LEFT 0x01

namespace Hid {

// ---------- HID 보고서 모양 (키보드 1 / 마우스 2 / 소리 조절 3) ----------
static const uint8_t REPORT_MAP[] = {
  // 키보드 — Report ID 1
  0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x85, 0x01,
  0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7, 0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,  // 조합키 8개
  0x95, 0x01, 0x75, 0x08, 0x81, 0x01,                                                              // 예약 1바이트
  0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02,                          // LED (출력)
  0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
  0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x73, 0x05, 0x07, 0x19, 0x00, 0x29, 0x73, 0x81, 0x00,  // 키 6개
  0xC0,
  // 마우스 — Report ID 2
  0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x85, 0x02, 0x09, 0x01, 0xA1, 0x00,
  0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01, 0x95, 0x03, 0x75, 0x01, 0x81, 0x02,  // 단추 3개
  0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
  0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38, 0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,  // X, Y, 휠
  0xC0, 0xC0,
  // 소리 조절(Consumer) — Report ID 3
  0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x85, 0x03,
  0x15, 0x00, 0x26, 0xFF, 0x03, 0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00,
  0xC0
};

// 아스키 글자 → HID 키 번호 (0x80 이 붙으면 Shift 필요)
#define SH 0x80
static const uint8_t ASCII_MAP[128] = {
  0,0,0,0,0,0,0,0, 0x2A,0x2B,0x28,0,0,0,0,0, 0,0,0,0,0,0,0,0, 0,0,0,0x29,0,0,0,0,
  0x2C, 0x1E|SH, 0x34|SH, 0x20|SH, 0x21|SH, 0x22|SH, 0x24|SH, 0x34,   //  !"#$%&'
  0x26|SH, 0x27|SH, 0x25|SH, 0x2E|SH, 0x36, 0x2D, 0x37, 0x38,         // ()*+,-./
  0x27, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26,         // 0-9
  0x33|SH, 0x33, 0x36|SH, 0x2E, 0x37|SH, 0x38|SH, 0x1F|SH,            // :;<=>?@
  0x04|SH,0x05|SH,0x06|SH,0x07|SH,0x08|SH,0x09|SH,0x0A|SH,0x0B|SH,0x0C|SH,0x0D|SH,0x0E|SH,0x0F|SH,0x10|SH,
  0x11|SH,0x12|SH,0x13|SH,0x14|SH,0x15|SH,0x16|SH,0x17|SH,0x18|SH,0x19|SH,0x1A|SH,0x1B|SH,0x1C|SH,0x1D|SH, // A-Z
  0x2F, 0x31, 0x30, 0x23|SH, 0x2D|SH, 0x35,                           // [\]^_`
  0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10,
  0x11,0x12,0x13,0x14,0x15,0x16,0x17,0x18,0x19,0x1A,0x1B,0x1C,0x1D,    // a-z
  0x2F|SH, 0x31|SH, 0x30|SH, 0x35|SH, 0                               // {|}~
};
#undef SH

static BLEHIDDevice*      hid      = nullptr;
static BLEServer*         server   = nullptr;
static BLECharacteristic* inKey    = nullptr;
static BLECharacteristic* inMouse  = nullptr;
static BLECharacteristic* inMedia  = nullptr;
static uint8_t            battLevel = 100;

#if defined(CONFIG_NIMBLE_ENABLED)
// =====================================================================
//  ⚠ esp32 3.3.x 보드 패키지의 BLE 라이브러리(NimBLE)는 UUID가 같은 특성(characteristic)을
//    하나만 등록합니다. HID 는 키보드·마우스·소리 보고가 모두 같은 UUID(0x2A4D)라서
//    라이브러리로 만들면 키보드만 남고 마우스·소리 조절이 사라집니다.
//    그래서 HID 서비스는 블루투스 칩(NimBLE)에 직접 등록합니다.
// =====================================================================
static uint16_t hKeyIn = 0, hKeyOut = 0, hMouseIn = 0, hMediaIn = 0, hBatt = 0;
static uint8_t  valKeyIn[8] = {0}, valKeyOut[1] = {0}, valMouseIn[4] = {0}, valMediaIn[2] = {0};
static uint8_t  protoMode = 1;                     // 1 = 보고 모드

enum : uintptr_t { A_HID_INFO = 1, A_REPORT_MAP, A_HID_CTRL, A_PROTO, A_KEY_IN, A_KEY_OUT, A_MOUSE_IN, A_MEDIA_IN,
                   A_BATT, A_PNP, A_MANUF, R_KEY_IN, R_KEY_OUT, R_MOUSE_IN, R_MEDIA_IN };

static int putBytes(ble_gatt_access_ctxt* ctxt, const void* d, uint16_t n) {
  return os_mbuf_append(ctxt->om, d, n) == 0 ? 0 : BLE_ATT_ERR_INSUFFICIENT_RES;
}
static int gattAccess(uint16_t, uint16_t, ble_gatt_access_ctxt* ctxt, void* arg) {
  static const uint8_t HID_INFO[4] = {0x11, 0x01, 0x00, 0x02};          // HID 1.11, 나라 없음, 연결 가능
  static const uint8_t PNP[7] = {0x02, 0x3A, 0x30, 0x01, 0x40, 0x00, 0x01};  // USB VID 0x303A, PID 0x4001, 버전 1.0
  static const char MANUF[] = "Maker Teacher";
  bool write = (ctxt->op == BLE_GATT_ACCESS_OP_WRITE_CHR || ctxt->op == BLE_GATT_ACCESS_OP_WRITE_DSC);
  switch ((uintptr_t)arg) {
    case A_HID_INFO:   return putBytes(ctxt, HID_INFO, 4);
    case A_REPORT_MAP: return putBytes(ctxt, REPORT_MAP, sizeof(REPORT_MAP));
    case A_HID_CTRL:   return 0;                                        // 절전 알림 등 — 받기만 함
    case A_PROTO:
      if (write) { uint16_t n; ble_hs_mbuf_to_flat(ctxt->om, &protoMode, 1, &n); return 0; }
      return putBytes(ctxt, &protoMode, 1);
    case A_KEY_IN:     return putBytes(ctxt, valKeyIn, sizeof(valKeyIn));
    case A_KEY_OUT:
      if (write) { uint16_t n; ble_hs_mbuf_to_flat(ctxt->om, valKeyOut, 1, &n); return 0; }   // 캡스락 등 LED
      return putBytes(ctxt, valKeyOut, 1);
    case A_MOUSE_IN:   return putBytes(ctxt, valMouseIn, sizeof(valMouseIn));
    case A_MEDIA_IN:   return putBytes(ctxt, valMediaIn, sizeof(valMediaIn));
    case A_BATT:       return putBytes(ctxt, &battLevel, 1);
    case A_PNP:        return putBytes(ctxt, PNP, 7);
    case A_MANUF:      return putBytes(ctxt, MANUF, sizeof(MANUF) - 1);
    // 보고 참조(Report Reference): {보고 번호, 1 = 입력 / 2 = 출력}
    case R_KEY_IN:   { static const uint8_t v[2] = {1, 1}; return putBytes(ctxt, v, 2); }
    case R_KEY_OUT:  { static const uint8_t v[2] = {1, 2}; return putBytes(ctxt, v, 2); }
    case R_MOUSE_IN: { static const uint8_t v[2] = {2, 1}; return putBytes(ctxt, v, 2); }
    case R_MEDIA_IN: { static const uint8_t v[2] = {3, 1}; return putBytes(ctxt, v, 2); }
  }
  return BLE_ATT_ERR_UNLIKELY;
}

static const ble_uuid16_t U_HID_SVC = BLE_UUID16_INIT(0x1812), U_BATT_SVC = BLE_UUID16_INIT(0x180F), U_DIS_SVC = BLE_UUID16_INIT(0x180A);
static const ble_uuid16_t U_HID_INFO = BLE_UUID16_INIT(0x2A4A), U_REPORT_MAP = BLE_UUID16_INIT(0x2A4B), U_HID_CTRL = BLE_UUID16_INIT(0x2A4C);
static const ble_uuid16_t U_PROTO = BLE_UUID16_INIT(0x2A4E), U_REPORT = BLE_UUID16_INIT(0x2A4D), U_REPORT_REF = BLE_UUID16_INIT(0x2908);
static const ble_uuid16_t U_BATT = BLE_UUID16_INIT(0x2A19), U_PNP = BLE_UUID16_INIT(0x2A50), U_MANUF = BLE_UUID16_INIT(0x2A29);

#define HID_DSC(id) {{ &U_REPORT_REF.u, BLE_ATT_F_READ, 0, gattAccess, (void*)(uintptr_t)(id) }, { nullptr, 0, 0, nullptr, nullptr }}
static ble_gatt_dsc_def dKeyIn[2] = HID_DSC(R_KEY_IN), dKeyOut[2] = HID_DSC(R_KEY_OUT),
                        dMouseIn[2] = HID_DSC(R_MOUSE_IN), dMediaIn[2] = HID_DSC(R_MEDIA_IN);
#undef HID_DSC

static const ble_gatt_chr_flags F_IN  = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_READ_ENC | BLE_GATT_CHR_F_NOTIFY;
static const ble_gatt_chr_flags F_OUT = BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_READ_ENC | BLE_GATT_CHR_F_WRITE |
                                        BLE_GATT_CHR_F_WRITE_NO_RSP | BLE_GATT_CHR_F_WRITE_ENC;
static const ble_gatt_chr_def HID_CHRS[] = {
  { &U_HID_INFO.u,   gattAccess, (void*)A_HID_INFO,   nullptr,  BLE_GATT_CHR_F_READ, 0, nullptr, nullptr },
  { &U_REPORT_MAP.u, gattAccess, (void*)A_REPORT_MAP, nullptr,  BLE_GATT_CHR_F_READ, 0, nullptr, nullptr },
  { &U_HID_CTRL.u,   gattAccess, (void*)A_HID_CTRL,   nullptr,  BLE_GATT_CHR_F_WRITE_NO_RSP, 0, nullptr, nullptr },
  { &U_PROTO.u,      gattAccess, (void*)A_PROTO,      nullptr,  BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_WRITE_NO_RSP, 0, nullptr, nullptr },
  { &U_REPORT.u,     gattAccess, (void*)A_KEY_IN,     dKeyIn,   F_IN,  0, &hKeyIn,   nullptr },
  { &U_REPORT.u,     gattAccess, (void*)A_KEY_OUT,    dKeyOut,  F_OUT, 0, &hKeyOut,  nullptr },
  { &U_REPORT.u,     gattAccess, (void*)A_MOUSE_IN,   dMouseIn, F_IN,  0, &hMouseIn, nullptr },
  { &U_REPORT.u,     gattAccess, (void*)A_MEDIA_IN,   dMediaIn, F_IN,  0, &hMediaIn, nullptr },
  { nullptr, nullptr, nullptr, nullptr, 0, 0, nullptr, nullptr }
};
static const ble_gatt_chr_def BATT_CHRS[] = {
  { &U_BATT.u, gattAccess, (void*)A_BATT, nullptr, BLE_GATT_CHR_F_READ | BLE_GATT_CHR_F_NOTIFY, 0, &hBatt, nullptr },
  { nullptr, nullptr, nullptr, nullptr, 0, 0, nullptr, nullptr }
};
static const ble_gatt_chr_def DIS_CHRS[] = {
  { &U_PNP.u,   gattAccess, (void*)A_PNP,   nullptr, BLE_GATT_CHR_F_READ, 0, nullptr, nullptr },
  { &U_MANUF.u, gattAccess, (void*)A_MANUF, nullptr, BLE_GATT_CHR_F_READ, 0, nullptr, nullptr },
  { nullptr, nullptr, nullptr, nullptr, 0, 0, nullptr, nullptr }
};
static const ble_gatt_svc_def GATT_SVCS[] = {
  { BLE_GATT_SVC_TYPE_PRIMARY, &U_DIS_SVC.u,  nullptr, DIS_CHRS },
  { BLE_GATT_SVC_TYPE_PRIMARY, &U_HID_SVC.u,  nullptr, HID_CHRS },
  { BLE_GATT_SVC_TYPE_PRIMARY, &U_BATT_SVC.u, nullptr, BATT_CHRS },
  { 0, nullptr, nullptr, nullptr }
};
#endif
static uint8_t            mods = 0, keys[6] = {0}, buttons = 0;

// 연결 상태는 '켜짐/꺼짐' 표시를 따로 두지 않고, 그때그때 블루투스 칩에 직접 물어봅니다.
// (예전 방식은 연결·끊김 알림 순서가 꼬이면 PC는 '연결됨'인데 보드는 '기다리는 중'으로 남을 수 있었음)
static volatile uint16_t  connHandle = 0xFFFF;   // 지금 연결된 PC 번호
static volatile int       authResult = -1;       // 마지막 보안 확인: -1 아직, 0 성공, 그 밖 = 실패 코드
static volatile bool      secured    = false;    // (Bluedroid 용) 보안 확인 끝남

#if defined(CONFIG_NIMBLE_ENABLED)
// ⚠ 이 보드 패키지(esp32 3.3.x)의 블루투스 라이브러리는 Windows가 붙을 때 '연결됨' 알림을 놓치는 일이 있습니다.
//    (그러면 라이브러리는 연결이 0개라고 믿고 키를 보내지 않음 → PC는 '연결됨', 보드는 '기다리는 중')
//    그래서 연결은 블루투스 칩(NimBLE)에 번호마다 직접 물어서 찾고, 키도 라이브러리를 거치지 않고 직접 보냅니다.
static volatile int lastDisc = -1;                 // 마지막으로 끊긴 이유 (0x213 = PC가 끊음, 0x208 = 신호 끊김)

struct LinkScan { int n, secured; uint16_t handle; uint16_t h[3]; bool enc[3]; };
static volatile uint16_t seenHandle = 0xFFFF;      // 사건으로 알게 된 연결 번호 (있으면 먼저 확인)
static void scanAdd(LinkScan& r, uint16_t h) {
  if (r.n >= 3) return;
  for (int i = 0; i < r.n; i++) if (r.h[i] == h) return;
  ble_gap_conn_desc d;
  if (ble_gap_conn_find(h, &d) != 0) return;
  r.h[r.n] = h; r.enc[r.n] = d.sec_state.encrypted; r.n++;
  r.handle = h;
  if (d.sec_state.encrypted) r.secured++;
}
static LinkScan scanLinks() {
  LinkScan r = {};
  r.handle = 0xFFFF;
  uint16_t s = seenHandle;
  if (s != 0xFFFF) scanAdd(r, s);
  if (connHandle != 0xFFFF) scanAdd(r, connHandle);
  for (uint16_t h = 0; h < 32; h++) scanAdd(r, h);  // 연결 번호는 작은 수 → 0~31 을 차례로 물어봄
  return r;
}
static uint32_t linkCount() { return scanLinks().n; }

// 입력 보고(키·마우스·소리)를 연결된 PC에 직접 보냄 (보안 확인이 끝난 연결에만)
static void sendReport(uint16_t handle, const uint8_t* data, size_t len) {
  if (!handle) return;
  LinkScan r = scanLinks();
  for (int i = 0; i < r.n; i++) {
    if (!r.enc[i]) continue;
    os_mbuf* om = ble_hs_mbuf_from_flat(data, len);
    if (!om) continue;
    int rc = ble_gatts_notify_custom(r.h[i], handle, om);   // om 은 성공·실패와 상관없이 블루투스 쪽이 정리
    if (rc != 0) Serial.printf("[HID] 보내기 실패 rc=%d\n", rc);
  }
}

// 블루투스 사건은 블루투스 전용 작업(스택이 작음)에서 불리므로 여기서는 적어 두기만 하고,
// 시리얼 출력은 loop() 의 Hid::poll() 에서 합니다.
struct BtLog { uint8_t type; uint16_t handle; int val; };
static volatile BtLog btLog[16];
static volatile uint8_t logHead = 0, logTail = 0;
static void pushLog(uint8_t t, uint16_t h, int v) {
  uint8_t n = (logHead + 1) & 15;
  if (n == logTail) return;                        // 가득 차면 버림
  btLog[logHead].type = t; btLog[logHead].handle = h; btLog[logHead].val = v;
  logHead = n;
}
static ble_gap_event_listener gapListener;
static int onGapEvent(ble_gap_event* e, void*) {
  switch (e->type) {
    case BLE_GAP_EVENT_CONNECT:
      if (e->connect.status == 0) seenHandle = e->connect.conn_handle;
      pushLog(1, e->connect.conn_handle, e->connect.status); break;
    case BLE_GAP_EVENT_LINK_ESTAB:
      if (e->link_estab.status == 0) seenHandle = e->link_estab.conn_handle;
      pushLog(6, e->link_estab.conn_handle, e->link_estab.status); break;
    case BLE_GAP_EVENT_DISCONNECT:
      lastDisc = e->disconnect.reason;
      pushLog(2, e->disconnect.conn.conn_handle, e->disconnect.reason);
      break;
    case BLE_GAP_EVENT_ENC_CHANGE:     pushLog(3, e->enc_change.conn_handle, e->enc_change.status); break;
    case BLE_GAP_EVENT_SUBSCRIBE:      pushLog(4, e->subscribe.attr_handle, e->subscribe.cur_notify); break;
    case BLE_GAP_EVENT_REPEAT_PAIRING: pushLog(5, 0, 0); break;
    case BLE_GAP_EVENT_CONN_UPDATE:    pushLog(7, e->conn_update.conn_handle, e->conn_update.status); break;
    default: break;
  }
  return 0;
}

// loop() 에서 부름: 적어 둔 블루투스 사건을 시리얼 모니터(115200)에 [BT] 로 출력,
// 연결이 모두 끊겼는데 광고(PC가 찾을 수 있게 알리기)가 멈춰 있으면 다시 시작
static void pollBt() {
  while (logTail != logHead) {
    BtLog l = {btLog[logTail].type, btLog[logTail].handle, btLog[logTail].val};
    logTail = (logTail + 1) & 15;
    switch (l.type) {
      case 1: Serial.printf("[BT] 연결 사건 handle=%u status=%d\n", l.handle, l.val); break;
      case 6: Serial.printf("[BT] 연결 확정 handle=%u status=%d\n", l.handle, l.val); break;
      case 2: Serial.printf("[BT] 끊김 handle=%u 이유=0x%X\n", l.handle, l.val); break;
      case 3: Serial.printf("[BT] 보안 확인 %s (status=%d)\n", l.val == 0 ? "성공" : "실패", l.val); break;
      case 4: Serial.printf("[BT] PC가 알림 구독 attr=%u notify=%d\n", l.handle, l.val); break;
      case 5: Serial.println("[BT] 예전 기억으로 다시 페어링 → 예전 기억 지우고 받아들임"); break;
      case 7: {
        ble_gap_conn_desc d;
        if (ble_gap_conn_find(l.handle, &d) == 0)
          Serial.printf("[BT] 연결 간격 바뀜: %.2fms, 건너뛰기 %u, 끊김 판정 %ums (status=%d)\n",
                        d.conn_itvl * 1.25f, d.conn_latency, d.supervision_timeout * 10, l.val);
        break;
      }
    }
  }
  static uint32_t last = 0;
  static int lastSt = -1;
  if (millis() - last > 1000) {                    // 1초마다 상태 확인
    last = millis();
    LinkScan r = scanLinks();
    int st = r.n == 0 ? 0 : (r.secured ? 2 : 1);
    if (st != lastSt) {
      if (st == 2) {                               // 보안 확인까지 끝나면: 짧은 연결 간격을 PC에 부탁 (반응 빠르게)
        ble_gap_conn_desc d;
        if (ble_gap_conn_find(r.handle, &d) == 0)
          Serial.printf("[BT] 지금 연결 간격 %.2fms, 건너뛰기 %u\n", d.conn_itvl * 1.25f, d.conn_latency);
        ble_gap_upd_params p = {};
        p.itvl_min = 6; p.itvl_max = 12;               // 7.5 ~ 15ms
        p.latency = 0; p.supervision_timeout = 300;    // 3초
        int rc = ble_gap_update_params(r.handle, &p);
        Serial.printf("[BT] 연결 간격 7.5~15ms 요청 rc=%d\n", rc);
        Serial.printf("[BT] 보고 번호: 키 %u, 마우스 %u, 소리 %u\n", hKeyIn, hMouseIn, hMediaIn);
      }
      lastSt = st;
      Serial.printf("[BT] 상태: 연결 %d개 (번호 %d), 보안 확인 %d개 / 라이브러리가 센 연결 %u\n",
                    r.n, r.n ? r.handle : -1, r.secured, server ? (unsigned)server->getConnectedCount() : 0);
    }
    if (r.n == 0 && !ble_gap_adv_active()) BLEDevice::startAdvertising();
  }
}
#else
static uint32_t linkCount() { return server ? server->getConnectedCount() : 0; }
static volatile int lastDisc = -1;
static void pollBt() {}
#endif

static void restartAdvertising() {
  if (linkCount() == 0) BLEDevice::startAdvertising();   // 연결된 PC가 없을 때만 다시 알림
}

class ServerCb : public BLEServerCallbacks {
#if defined(CONFIG_NIMBLE_ENABLED)
  void onConnect(BLEServer*, ble_gap_conn_desc* d) override { connHandle = d->conn_handle; authResult = -1; }
  void onDisconnect(BLEServer*, ble_gap_conn_desc* d) override {
    if (d->conn_handle == connHandle) connHandle = 0xFFFF;
    restartAdvertising();                         // 끊기면 다시 연결을 기다림
  }
#else
  void onConnect(BLEServer*) override    { secured = false; authResult = -1; }
  void onDisconnect(BLEServer*) override {
    secured = false;
    BLEDevice::startAdvertising();
  }
#endif
};
class SecurityCb : public BLESecurityCallbacks {
  bool     onSecurityRequest() override       { return true; }
  uint32_t onPassKeyRequest() override        { return 0; }
  void     onPassKeyNotify(uint32_t) override {}
  bool     onConfirmPIN(uint32_t) override    { return true; }
#if defined(CONFIG_BLUEDROID_ENABLED)
  void onAuthenticationComplete(esp_ble_auth_cmpl_t a) override {
    secured = a.success; authResult = a.success ? 0 : (a.fail_reason ? a.fail_reason : 1);
  }
#elif defined(CONFIG_NIMBLE_ENABLED)
  void onAuthenticationComplete(ble_gap_conn_desc*) override {}
  void onAuthenticationComplete(ble_gap_conn_desc*, int status) override { authResult = status; }
#endif
};

static constexpr bool available() { return true; }
static const char* name() { return BT_NAME; }

// 0 = 기다리는 중(PC가 찾을 수 있음) / 1 = 연결은 됐는데 보안 확인 전·실패 / 2 = 연결됨(키가 감)
static int state() {
  if (linkCount() == 0) return 0;
#if defined(CONFIG_NIMBLE_ENABLED)
  return scanLinks().secured ? 2 : 1;
#else
  return secured ? 2 : 1;
#endif
}
static bool connected() { return linkCount() > 0; }   // 키를 보내도 되는지
static int  lastAuth()  { return authResult; }
static int  lastDisconnect() { return lastDisc; }   // -1 = 아직 없음

// 이 보드가 기억하고 있는 PC 수 (보드 안 저장공간에 남아 있어서, 코드를 다시 올려도 지워지지 않음)
static int bondCount() {
#if defined(CONFIG_NIMBLE_ENABLED)
  int n = 0;
  if (ble_store_util_count(BLE_STORE_OBJ_TYPE_PEER_SEC, &n) != 0) return -1;
  return n;
#else
  return esp_ble_get_bond_device_num();
#endif
}

// 기억한 PC를 모두 지움. 부른 쪽에서 곧바로 ESP.restart() 하세요.
// 지운 뒤에는 PC 쪽에서도 이 장치를 '제거'하고 다시 '장치 추가' 해야 합니다.
static void forgetAll() {
#if defined(CONFIG_NIMBLE_ENABLED)
  LinkScan r = scanLinks();
  if (r.handle != 0xFFFF) ble_gap_terminate(r.handle, BLE_ERR_REM_USER_CONN_TERM);
  ble_store_clear();
#else
  int n = esp_ble_get_bond_device_num();
  if (n > 0) {
    esp_ble_bond_dev_t* list = (esp_ble_bond_dev_t*)malloc(sizeof(esp_ble_bond_dev_t) * n);
    if (list && esp_ble_get_bond_device_list(&n, list) == ESP_OK)
      for (int i = 0; i < n; i++) esp_ble_remove_bond_device(list[i].bd_addr);
    free(list);
  }
#endif
}

// setup() 에서 한 번만 부릅니다 (ClassHelper.ino 가 알아서 부름)
static void begin() {
  BLEDevice::init(BT_NAME);
#if defined(CONFIG_NIMBLE_ENABLED)
  ble_gap_event_listener_register(&gapListener, onGapEvent, nullptr);
  Serial.printf("[BT] 시작: %s\n", BT_NAME);
#endif
  BLESecurity* sec = new BLESecurity();
  sec->setCapability(ESP_IO_CAP_NONE);           // 숫자 입력 없이 바로 연결 (Just Works)
  sec->setAuthenticationMode(true, false, true); // 연결 정보 기억(본딩)
  BLEDevice::setSecurityCallbacks(new SecurityCb());

  server = BLEDevice::createServer();
  server->setCallbacks(new ServerCb());

#if defined(CONFIG_NIMBLE_ENABLED)
  // HID·배터리·기기 정보 서비스를 블루투스 칩에 직접 등록 (위 ⚠ 설명 참고)
  int rc = ble_gatts_count_cfg(GATT_SVCS);
  if (rc == 0) rc = ble_gatts_add_svcs(GATT_SVCS);
  Serial.printf("[BT] HID 서비스 등록 rc=%d\n", rc);
#else
  hid = new BLEHIDDevice(server);
  inKey   = hid->inputReport(1);
  hid->outputReport(1);                          // 캡스락 등 LED (받기만 함)
  inMouse = hid->inputReport(2);
  inMedia = hid->inputReport(3);

  hid->manufacturer()->setValue("Maker Teacher");
  hid->pnp(0x02, 0x303A, 0x4001, 0x0100);
  hid->hidInfo(0x00, 0x01);
  hid->reportMap((uint8_t*)REPORT_MAP, sizeof(REPORT_MAP));
  hid->startServices();
  hid->setBatteryLevel(100);
#endif

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->setAppearance(0x03C1);                    // 키보드 모양
  adv->addServiceUUID(BLEUUID((uint16_t)0x1812));   // HID 서비스
  adv->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.printf("[BT] 기다리는 중 (기억한 PC %d대)\n", bondCount());
}

static void setBattery(uint8_t pct) {
  if (pct > 100) pct = 100;
  bool changed = (pct != battLevel);
  battLevel = pct;
#if defined(CONFIG_NIMBLE_ENABLED)
  if (changed && hBatt) ble_gatts_chr_updated(hBatt);   // 구독한 PC에 배터리 % 알림
#else
  if (hid) hid->setBatteryLevel(pct);
#endif
}

// ---------- 키보드 ----------
static void logSend(const char* what) {          // 보내기 전에 시리얼에 한 줄 (재부팅되면 마지막 줄이 범인)
  Serial.printf("[HID] %s 보냄 (라이브러리 연결 수 %u, 보드가 본 연결 %d, 남은 스택 %u)\n", what,
                server ? (unsigned)server->getConnectedCount() : 0, (int)linkCount(),
                (unsigned)uxTaskGetStackHighWaterMark(NULL));
  Serial.flush();
}
// ---------- 보고(키·마우스·소리)를 보내는 간격 ----------
// 블루투스는 정해진 박자(연결 간격, 보통 7.5~45ms)마다 한 번씩 주고받습니다.
// '누름'과 '뗌'을 한 박자 안에 연달아 보내면 PC가 앞의 '누름'을 놓쳐서 '두 번 눌러야 넘어가는' 일이 생깁니다.
// 그래서 같은 종류의 보고 사이를 연결 간격의 2배 이상 띄웁니다.
enum { CH_KEY = 0, CH_MOUSE = 1, CH_MEDIA = 2 };
static uint32_t lastReportAt[3] = {0, 0, 0};
static uint32_t reportGapMs() {
#if defined(CONFIG_NIMBLE_ENABLED)
  LinkScan r = scanLinks();
  ble_gap_conn_desc d;
  if (r.n && ble_gap_conn_find(r.handle, &d) == 0) {
    uint32_t itv = (uint32_t)d.conn_itvl * 5 / 4;          // 1.25ms 단위 → ms
    uint32_t g = itv * 2 + 5;
    return g < 25 ? 25 : (g > 150 ? 150 : g);
  }
#endif
  return 40;
}
static bool chanReady(int ch) {                  // 그 보고를 보낼 준비가 됐는지
#if defined(CONFIG_NIMBLE_ENABLED)
  return (ch == CH_KEY ? hKeyIn : ch == CH_MOUSE ? hMouseIn : hMediaIn) != 0;
#else
  return (ch == CH_KEY ? inKey : ch == CH_MOUSE ? inMouse : inMedia) != nullptr;
#endif
}
static void notifyReport(int ch, uint8_t* r, size_t n) {
  uint32_t g = reportGapMs(), el = millis() - lastReportAt[ch];
  if (el < g) delay(g - el);                                  // 앞 보고와 충분히 띄우기
#if defined(CONFIG_NIMBLE_ENABLED)
  uint8_t* keep = ch == CH_KEY ? valKeyIn : ch == CH_MOUSE ? valMouseIn : valMediaIn;
  memcpy(keep, r, n);                                         // PC가 읽을 때 돌려줄 값
  sendReport(ch == CH_KEY ? hKeyIn : ch == CH_MOUSE ? hMouseIn : hMediaIn, r, n);
#else
  BLECharacteristic* c = ch == CH_KEY ? inKey : ch == CH_MOUSE ? inMouse : inMedia;
  c->setValue(r, n); c->notify();
#endif
  lastReportAt[ch] = millis();
}
static void sendKeys() {
  if (!connected() || !chanReady(CH_KEY)) return;
  uint8_t r[8] = {mods, 0, keys[0], keys[1], keys[2], keys[3], keys[4], keys[5]};
  notifyReport(CH_KEY, r, sizeof(r));
}
static void press(uint8_t k) {
  uint8_t code;
  if (k >= 136)      code = k - 136;                          // 화살표·F5 같은 특수 키
  else if (k >= 128) { mods |= (1 << (k - 128)); sendKeys(); return; }  // Ctrl·Shift·Alt·윈도우
  else {
    code = ASCII_MAP[k];
    if (code & 0x80) { mods |= 0x02; code &= 0x7F; }          // 대문자·기호는 Shift
  }
  if (!code) return;
  for (int i = 0; i < 6; i++) if (keys[i] == code) { sendKeys(); return; }
  for (int i = 0; i < 6; i++) if (!keys[i]) { keys[i] = code; break; }
  sendKeys();
}
static void releaseAll() {
  mods = 0; memset(keys, 0, sizeof(keys));
  sendKeys();
}

static void key(uint8_t k)                          { logSend("키"); press(k); releaseAll(); Serial.println("[HID] 키 끝"); }
static void combo(uint8_t m, uint8_t k)             { logSend("조합 키"); press(m); press(k); releaseAll(); Serial.println("[HID] 조합 키 끝"); }
static void combo3(uint8_t a, uint8_t b, uint8_t k) { logSend("조합 키3"); press(a); press(b); press(k); releaseAll(); Serial.println("[HID] 조합 키3 끝"); }
static void typeNumber(int n) {
  char buf[8];
  snprintf(buf, sizeof(buf), "%d", n);
  for (char* p = buf; *p; p++) key(*p);
  key(KEY_RETURN);
}

// ---------- 마우스 ----------
// 터치패드로 문지르면 움직임이 아주 자주 생기므로, 모아 두었다가 보고 간격마다 한 번에 보냅니다.
static int pendX = 0, pendY = 0;
static void sendMouse(int8_t dx, int8_t dy) {
  if (!connected() || !chanReady(CH_MOUSE)) return;
  uint8_t r[4] = {buttons, (uint8_t)dx, (uint8_t)dy, 0};
  notifyReport(CH_MOUSE, r, sizeof(r));
}
static void flushMouse(bool force) {
  if (!pendX && !pendY) return;
  if (!force && millis() - lastReportAt[CH_MOUSE] < reportGapMs()) return;   // 아직 박자 전 → 더 모음
  int dx = constrain(pendX, -127, 127), dy = constrain(pendY, -127, 127);
  pendX -= dx; pendY -= dy;
  sendMouse(dx, dy);
}
static void mouseMove(int dx, int dy) {
  pendX += dx; pendY += dy;
  flushMouse(false);
}
static void mouseDown() { logSend("마우스 누름"); flushMouse(true); buttons |= MOUSE_LEFT;  sendMouse(0, 0); }
static void mouseUp()   { flushMouse(true); buttons &= ~MOUSE_LEFT; sendMouse(0, 0); }
static void click()     { mouseDown(); mouseUp(); Serial.println("[HID] 클릭 끝"); }

// ---------- 소리 크게·작게·음소거 ----------
static void media(uint16_t usage) {
  if (!connected() || !chanReady(CH_MEDIA)) return;
  logSend("소리 조절");
  uint8_t r[2] = {(uint8_t)(usage & 0xFF), (uint8_t)(usage >> 8)};
  notifyReport(CH_MEDIA, r, 2);
  r[0] = r[1] = 0;
  notifyReport(CH_MEDIA, r, 2);
  Serial.println("[HID] 소리 조절 끝");
}

// loop() 에서 부름 (ClassHelper.ino): 블루투스 기록 출력 + 남은 마우스 움직임 보내기
static void poll() {
  pollBt();
  flushMouse(false);
}

}  // namespace Hid
