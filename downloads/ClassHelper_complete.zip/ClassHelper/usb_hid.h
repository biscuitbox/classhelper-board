// =====================================================================
//  usb_hid.h  —  보드를 'USB 키보드 + 마우스 + 소리 조절기'로 만들기
//
//  ⚠️ 아두이노 IDE 메뉴  Tools → USB Mode → "USB-OTG (TinyUSB)"  로 바꿔야 작동합니다.
//     기본값(Hardware CDC and JTAG)으로 올리면 Hid::available() 이 false 가 되고
//     프레젠터 화면에 "USB Mode를 바꿔 주세요" 안내가 나옵니다. (다른 앱은 그대로 작동)
//
//  앱에서 쓰는 법
//    Hid::key(KEY_RIGHT_ARROW);            // 키 하나 누르고 떼기
//    Hid::key('.');                        // 글자 키
//    Hid::combo(KEY_LEFT_CTRL, 'l');       // Ctrl+L 같은 두 키 조합
//    Hid::combo(KEY_LEFT_SHIFT, KEY_F5);   // Shift+F5
//    Hid::combo3(KEY_LEFT_CTRL, KEY_LEFT_SHIFT, KEY_F5);  // 세 키 조합
//    Hid::typeNumber(12);                  // 숫자 12 를 치고 Enter (PPT 12번 슬라이드로)
//    Hid::mouseMove(dx, dy);               // 마우스 움직이기 (-127 ~ 127)
//    Hid::mouseDown(); Hid::mouseUp(); Hid::click();
//    Hid::media(CONSUMER_CONTROL_VOLUME_INCREMENT);   // 소리 크게 / _DECREMENT / CONSUMER_CONTROL_MUTE
//    Hid::connected()                      // PC가 보드를 키보드로 인식했으면 true
//
//  💡 글자 단축키(b, w, e 등)는 PC가 '한글' 입력 상태면 안 먹을 수 있어요.
//     그래서 PPT 검은 화면은 'b' 대신 '.', 흰 화면은 'w' 대신 ',' 를 씁니다.
// =====================================================================
#pragma once
#include <Arduino.h>

#if !ARDUINO_USB_MODE && CONFIG_TINYUSB_HID_ENABLED
  #define HID_OK 1
  #include "USB.h"
  #include "USBHIDKeyboard.h"
  #include "USBHIDMouse.h"
  #include "USBHIDConsumerControl.h"
#else
  #define HID_OK 0
  // USB Mode 가 TinyUSB 가 아닐 때도 앱 코드가 컴파일되도록 키 이름만 정의
  #define KEY_LEFT_CTRL   0x80
  #define KEY_LEFT_SHIFT  0x81
  #define KEY_LEFT_ALT    0x82
  #define KEY_LEFT_GUI    0x83
  #define KEY_UP_ARROW    0xDA
  #define KEY_DOWN_ARROW  0xD9
  #define KEY_LEFT_ARROW  0xD8
  #define KEY_RIGHT_ARROW 0xD7
  #define KEY_BACKSPACE   0xB2
  #define KEY_TAB         0xB3
  #define KEY_RETURN      0xB0
  #define KEY_ESC         0xB1
  #define KEY_PAGE_UP     0xD3
  #define KEY_PAGE_DOWN   0xD6
  #define KEY_HOME        0xD2
  #define KEY_END         0xD5
  #define KEY_F5          0xC6
  #define CONSUMER_CONTROL_PLAY_PAUSE       0x00CD
  #define CONSUMER_CONTROL_MUTE             0x00E2
  #define CONSUMER_CONTROL_VOLUME_INCREMENT 0x00E9
  #define CONSUMER_CONTROL_VOLUME_DECREMENT 0x00EA
#endif

namespace Hid {
#if HID_OK
  static USBHIDKeyboard        kb;
  static USBHIDMouse           mouse;
  static USBHIDConsumerControl cc;
#endif
  static bool started = false;

  static constexpr bool available() { return HID_OK; }

  // setup() 에서 한 번만 부릅니다 (교탁도우미.ino 가 알아서 부름)
  static void begin() {
#if HID_OK
    kb.begin();
    mouse.begin();
    cc.begin();
    USB.productName("ClassHelper");
    USB.manufacturerName("Maker Teacher");
    USB.begin();
    started = true;
#endif
  }

  static bool connected() {
#if HID_OK
    return started && (bool)USB;
#else
    return false;
#endif
  }

  static void key(uint8_t k) {
#if HID_OK
    kb.press(k); delay(15); kb.releaseAll();
#endif
  }
  static void combo(uint8_t mod, uint8_t k) {
#if HID_OK
    kb.press(mod); kb.press(k); delay(20); kb.releaseAll();
#endif
  }
  static void combo3(uint8_t m1, uint8_t m2, uint8_t k) {
#if HID_OK
    kb.press(m1); kb.press(m2); kb.press(k); delay(20); kb.releaseAll();
#endif
  }
  static void typeNumber(int n) {
#if HID_OK
    char buf[8];
    snprintf(buf, sizeof(buf), "%d", n);
    for (char* p = buf; *p; p++) { kb.press(*p); delay(12); kb.releaseAll(); delay(12); }
    key(KEY_RETURN);
#endif
  }

  static void mouseMove(int dx, int dy) {
#if HID_OK
    dx = constrain(dx, -127, 127); dy = constrain(dy, -127, 127);
    if (dx || dy) mouse.move((int8_t)dx, (int8_t)dy);
#endif
  }
  static void mouseDown() {
#if HID_OK
    mouse.press(MOUSE_LEFT);
#endif
  }
  static void mouseUp() {
#if HID_OK
    mouse.release(MOUSE_LEFT);
#endif
  }
  static void click() {
#if HID_OK
    mouse.click(MOUSE_LEFT);
#endif
  }

  static void media(uint16_t usage) {
#if HID_OK
    cc.press(usage); delay(20); cc.release();
#endif
  }
}
