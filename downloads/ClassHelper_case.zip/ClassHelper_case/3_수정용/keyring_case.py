"""
지뢰찾기 키링 케이스 (LCDwiki ES3C28P 2.8" ESP32-S3 보드용)  -  CadQuery 파라메트릭 모델

좌표계 (앞에서 화면을 볼 때, USB-C 가 아래쪽)
  x: 기판 왼쪽 가장자리 = 0  ->  오른쪽 50
  y: 기판 아래(USB) 가장자리 = 0  ->  위쪽 86
  z: 뒷면 바깥 = 0  ->  화면 쪽 위로

출력: back_shell.stl, back_shell_switch.stl, front_bezel.stl, boot_button.stl, keyring_case.step
"""
import cadquery as cq
import os, sys

OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------- 파라미터
PCB_W, PCB_H, PCB_T = 50.0, 86.0, 1.6
HOLES = [(4, 4), (46, 4), (4, 82), (46, 82)]       # Ø3.2 장착 구멍 (간격 42 x 78)

SIDE_GAP  = 3.0     # 좌우: 기판~벽 (배터리/스피커 플러그 전선 공간)
END_GAP   = 0.4     # 위아래: 기판~벽 (USB-C 가 벽에 가깝도록)
WALL      = 1.8
BACK_T    = 1.6     # 뒷판 두께
FRONT_T   = 1.2     # 앞 테두리 두께
CAV_D     = 13.5    # 뒷판 안쪽 ~ 기판 뒷면 (높이 11mm 스피커 + 부품 여유)
GLASS     = 4.0     # 기판 앞면 ~ 터치유리 윗면
GLASS_GAP = 0.1
CORNER_R  = 5.0
EDGE_R    = 1.2

WIN_W, WIN_H, WIN_CY, WIN_R, WIN_CH = 46.0, 64.0, 43.0, 1.5, 0.8   # 화면 창

# 부품 위치 (사진 실측, 오차 ±0.5mm)
USB_X, USB_W, USB_HGT = 25.5, 13.0, 7.5          # 케이블 몰딩이 들어가는 구멍
BOOT_XY  = (14.0, 4.0)
RESET_XY = (37.5, 4.0)
LED_XY   = (26.5, 46.5)
BTN_H    = 2.5      # BOOT 버튼 높이(기판 뒷면 기준)

# 스피커 포켓 (동봉 스피커 29 x 41 x 높이 11mm, 41mm 쪽을 세로로)
SPK_W, SPK_H, SPK_C = 29.6, 41.6, (25.0, 29.1)
# 배터리 포켓 (503035 = 5x30x35mm, 약 500mAh 기준)
BAT_W, BAT_H, BAT_C = 31.0, 35.5, (25.0, 50.9 + 35.5 / 2)
POCKET_RIB_H = 3.0

# 나중에 달 슬라이드 스위치 자리 (SS12D00 류, 왼쪽 벽)
SW_Y, SW_SLOT_L, SW_SLOT_H, SW_Z = 57.0, 5.0, 2.4, 4.5

# 키링 고리
LOOP_W, LOOP_LEN, LOOP_T, LOOP_HOLE = 12.0, 10.0, 4.0, 4.6

# 나사: M2 x 12 (태핑) 4개
# 나사: M3 x 12 렌치볼트(육각 홈 볼트, 머리 Ø5.5 x 3) 4개 — 앞 스탠드오프에 직접 나사산 형성
SCREW_LEN, SCREW_ENGAGE = 12.0, 4.0
SCREW_CLEAR, SCREW_PILOT, HEAD_D = 3.4, 2.5, 6.0
POST_D, STANDOFF_D = 8.6, 6.0

# ----------------------------------------------------------------- 파생 치수
X0, X1 = -SIDE_GAP - WALL, PCB_W + SIDE_GAP + WALL
Y0, Y1 = -END_GAP - WALL, PCB_H + END_GAP + WALL
IX0, IX1 = -SIDE_GAP, PCB_W + SIDE_GAP
IY0, IY1 = -END_GAP, PCB_H + END_GAP
Z_PCB_BACK = BACK_T + CAV_D
TUBE_TOP   = Z_PCB_BACK - BTN_H - 1.7     # BOOT 플런저 가이드 튜브 끝
Z_SPLIT    = Z_PCB_BACK + PCB_T          # 기판 앞면 = 앞/뒤 분할면
HEAD_DEPTH = Z_SPLIT + SCREW_ENGAGE - SCREW_LEN   # 볼트 머리가 앉는 깊이(뒷면 기준)
Z_LIP      = Z_SPLIT + GLASS + GLASS_GAP
H          = Z_LIP + FRONT_T
CX, CY     = (X0 + X1) / 2, (Y0 + Y1) / 2


def rrect(w, h, r, z0, z1, cx=0.0, cy=0.0):
    s = cq.Workplane("XY").workplane(offset=z0).center(cx, cy).rect(w, h).extrude(z1 - z0)
    return s.edges("|Z").fillet(r) if r > 0 else s


def box(x0, x1, y0, y1, z0, z1):
    return cq.Workplane("XY").box(x1 - x0, y1 - y0, z1 - z0).translate(((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2))


def cyl(d, z0, z1, x, y):
    return cq.Workplane("XY").workplane(offset=z0).center(x, y).circle(d / 2).extrude(z1 - z0)


def corner_brackets(cx, cy, w, h, z0, z1, t=1.0, arm=5.0):
    """포켓 네 귀퉁이 L자 가이드"""
    res = None
    for sx in (-1, 1):
        for sy in (-1, 1):
            ox, oy = cx + sx * (w / 2 + t / 2), cy + sy * (h / 2 + t / 2)
            a = box(ox - t / 2, ox + t / 2, oy - sy * arm - t / 2 if sy > 0 else oy - t / 2,
                    oy + t / 2 if sy > 0 else oy - sy * arm + t / 2, z0, z1)
            b = box(ox - sx * arm - t / 2 if sx > 0 else ox - t / 2,
                    ox + t / 2 if sx > 0 else ox - sx * arm + t / 2, oy - t / 2, oy + t / 2, z0, z1)
            u = a.union(b)
            res = u if res is None else res.union(u)
    return res


# ----------------------------------------------------------------- 바깥 형태
outer = (cq.Workplane("XY").center(CX, CY).rect(X1 - X0, Y1 - Y0).extrude(H)
         .edges("|Z").fillet(CORNER_R)
         .edges(">Z or <Z").fillet(EDGE_R))

usb_cut = (cq.Workplane("XY").box(USB_W, 8.0, USB_HGT).edges("|Y").fillet(2.4)
           .translate((USB_X, Y0 + 1.0, Z_PCB_BACK - 1.4)))

# ================================================================= 뒷 케이스
def make_back(switch_open=False):
    b = outer.intersect(box(X0 - 1, X1 + 1, Y0 - 1, Y1 + 1, -1, Z_SPLIT))
    b = b.cut(rrect(IX1 - IX0, IY1 - IY0, CORNER_R - WALL, BACK_T, Z_SPLIT + 1, (IX0 + IX1) / 2, (IY0 + IY1) / 2))

    # 키링 고리 (뒷판과 같은 면, 눕혀서 출력 → 튼튼)
    tab_c = Y1 + LOOP_LEN - LOOP_W / 2
    tab = (box(PCB_W / 2 - LOOP_W / 2, PCB_W / 2 + LOOP_W / 2, Y1 - WALL, tab_c, 0, LOOP_T)
           .union(cyl(LOOP_W, 0, LOOP_T, PCB_W / 2, tab_c)))
    tab = tab.edges(">Z").fillet(0.8)
    b = b.union(tab)
    b = b.cut(cyl(LOOP_HOLE, -1, LOOP_T + 1, PCB_W / 2, tab_c))

    # 나사 기둥
    for (hx, hy) in HOLES:
        b = b.union(cyl(POST_D, BACK_T - 0.01, Z_PCB_BACK, hx, hy))
    # 기판 좌우 위치잡이 리브 (커넥터 없는 곳)
    for (x0, x1, yc) in [(IX0, -0.3, 8.0), (IX0, -0.3, 75.0), (PCB_W + 0.3, IX1, 8.0), (PCB_W + 0.3, IX1, 79.0)]:
        b = b.union(box(x0 - 0.01 if x0 == IX0 else x0, x1 + 0.01 if x1 == IX1 else x1, yc - 1.5, yc + 1.5, BACK_T, Z_SPLIT))
    # 스피커 / 배터리 포켓 가이드
    b = b.union(corner_brackets(*SPK_C, SPK_W, SPK_H, BACK_T - 0.01, BACK_T + POCKET_RIB_H))
    b = b.union(corner_brackets(*BAT_C, BAT_W, BAT_H, BACK_T - 0.01, BACK_T + POCKET_RIB_H)
                .intersect(box(IX0, IX1, IY0, IY1, 0, H)))
    # BOOT 플런저 가이드 튜브
    b = b.union(cyl(6.2, BACK_T - 0.01, TUBE_TOP, *BOOT_XY))
    # 스위치 받침 가이드 (나중에 SS12D00 류 슬라이드 스위치)
    for yy in (SW_Y - 4.8, SW_Y + 4.8):
        b = b.union(box(IX0 - 0.01, 1.0, yy - 0.5, yy + 0.5, BACK_T, 6.5))

    # ---- 구멍들 ----
    for (hx, hy) in HOLES:
        b = b.cut(cyl(SCREW_CLEAR, -1, Z_PCB_BACK + 1, hx, hy))
        b = b.cut(cyl(HEAD_D, -1, HEAD_DEPTH, hx, hy))
    b = b.cut(cyl(3.4, -1, TUBE_TOP + 0.1, *BOOT_XY))             # BOOT 버튼
    b = b.cut(cyl(1.8, -1, BACK_T + 1, *RESET_XY))      # RESET 핀홀
    # 스피커 그릴 (육각 배열)
    gx, gy = SPK_C
    pitch = 3.0
    pts = []
    for r in range(-7, 8):
        for c in range(-4, 5):
            x = gx + c * pitch + (pitch / 2 if r % 2 else 0)
            y = gy + r * pitch * 0.866
            if abs(x - gx) <= 11 and abs(y - gy) <= 17:
                pts.append((x, y))
    grille = cq.Workplane("XY").workplane(offset=-1).pushPoints(pts).circle(0.8).extrude(BACK_T + 2)
    b = b.cut(grille)
    b = b.cut(usb_cut)
    # 스위치 창: 기본은 바깥 0.5mm 막(나중에 칼로 따냄), switch_open=True 면 뚫린 버전
    skin = 0.0 if switch_open else 0.5
    b = b.cut(box(X0 - 1 + (1 + skin), IX0 + 0.01, SW_Y - SW_SLOT_L / 2, SW_Y + SW_SLOT_L / 2,
                  SW_Z - SW_SLOT_H / 2, SW_Z + SW_SLOT_H / 2))
    return b


# ================================================================= 앞 베젤
def make_front():
    f = outer.intersect(box(X0 - 1, X1 + 1, Y0 - 1, Y1 + 1, Z_SPLIT, H + 1))
    f = f.cut(rrect(IX1 - IX0, IY1 - IY0, CORNER_R - WALL, Z_SPLIT - 1, Z_LIP, (IX0 + IX1) / 2, (IY0 + IY1) / 2))
    f = f.cut(rrect(WIN_W, WIN_H, WIN_R, Z_LIP - 1, H + 1, PCB_W / 2, WIN_CY))
    f = (f.faces(">Z").edges(cq.selectors.BoxSelector(
            (PCB_W / 2 - WIN_W / 2 - 1, WIN_CY - WIN_H / 2 - 1, H - 0.2),
            (PCB_W / 2 + WIN_W / 2 + 1, WIN_CY + WIN_H / 2 + 1, H + 0.2)))
         .chamfer(WIN_CH))
    # 기판을 눌러 잡는 스탠드오프 + 나사 구멍(태핑)
    for (hx, hy) in HOLES:
        f = f.union(cyl(STANDOFF_D, Z_SPLIT, Z_LIP + 0.01, hx, hy))
        f = f.cut(cyl(SCREW_PILOT, Z_SPLIT - 1, Z_LIP + 0.6, hx, hy))
    f = f.cut(usb_cut)
    return f


# ================================================================= BOOT 버튼 플런저
def make_plunger():
    # 바깥 끝(z=-0.8) ~ 플랜지(튜브 끝 위 0.8) ~ 버튼 누르는 팁(0.8)
    rod_len = TUBE_TOP + 0.8
    p = cq.Workplane("XY").circle(1.45).extrude(rod_len)
    p = p.faces("<Z").edges().fillet(0.5)
    p = p.union(cq.Workplane("XY").workplane(offset=rod_len).circle(2.6).extrude(0.8))
    p = p.union(cq.Workplane("XY").workplane(offset=rod_len + 0.8).circle(1.2).extrude(0.8))
    return p


if __name__ == "__main__":
    back = make_back(False)
    back_sw = make_back(True)
    front = make_front()
    plunger = make_plunger()

    # 출력 방향: 뒷 케이스는 뒷면이 바닥, 앞 베젤은 화면 면이 바닥
    front_print = front.rotate((0, 0, 0), (0, 1, 0), 180).translate((0, 0, H))
    cq.exporters.export(back, f"{OUT}/back_shell.stl", tolerance=0.02, angularTolerance=0.1)
    cq.exporters.export(back_sw, f"{OUT}/back_shell_switch.stl", tolerance=0.02, angularTolerance=0.1)
    cq.exporters.export(front_print, f"{OUT}/front_bezel.stl", tolerance=0.02, angularTolerance=0.1)
    cq.exporters.export(plunger, f"{OUT}/boot_button.stl", tolerance=0.02, angularTolerance=0.1)

    asm = (cq.Assembly(name="minesweeper_keyring")
           .add(back, name="back_shell", color=cq.Color(0.95, 0.75, 0.15))
           .add(front, name="front_bezel", color=cq.Color(0.2, 0.2, 0.22))
           .add(plunger.translate((BOOT_XY[0], BOOT_XY[1], -0.8)), name="boot_button", color=cq.Color(0.8, 0.1, 0.1)))
    asm.save(f"{OUT}/keyring_case.step")

    print(f"케이스 바깥 크기: {X1 - X0:.1f} x {Y1 - Y0:.1f} (+고리 {LOOP_LEN:.1f}) x {H:.1f} mm")
    print(f"볼트 머리 홈: Ø{HEAD_D} 깊이 {HEAD_DEPTH:.1f}mm, 스탠드오프 물림 {SCREW_ENGAGE}mm")
    print(f"분할면 z={Z_SPLIT:.1f}, 기판 뒷면 z={Z_PCB_BACK:.1f}, 앞 테두리 z={Z_LIP:.1f}")
    for n, s in [("back", back), ("front", front), ("plunger", plunger)]:
        bb = s.val().BoundingBox()
        print(n, "valid" if s.val().isValid() else "INVALID", f"vol={s.val().Volume():.0f}mm3",
              f"bbox=({bb.xmin:.1f},{bb.ymin:.1f},{bb.zmin:.1f})-({bb.xmax:.1f},{bb.ymax:.1f},{bb.zmax:.1f})")
