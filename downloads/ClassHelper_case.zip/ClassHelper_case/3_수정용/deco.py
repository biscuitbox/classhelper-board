"""
4색 장식 버전 (뱀부랩 H2S + AMS)
  - 장식은 표면에 0.6mm(0.2mm x 3층) 매립 → 바닥 첫 3층에서만 색이 바뀜
  - 같은 좌표계의 '색별 STL'을 한 번에 불러와 하나의 객체(여러 파트)로 합친 뒤 색만 지정

  앞 베젤: 본체 검정 / 빨강 / 노랑 / 흰색
  뒷 케이스: 본체 노랑 / 검정 / 흰색 / 빨강
"""
import sys, os
OUT = sys.argv[1] if len(sys.argv) > 1 else "out"
sys.argv = [sys.argv[0], OUT]
import cadquery as cq
import keyring_case as K
from keyring_case import box, cyl

DEPTH = 0.6
FONT = "/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc"

# ------------------------------------------------------------ 2D 도형 → 얇은 프리즘
class Layer:
    """한 면(z0~z1)에 그리는 도형 모음. mirror=True 면 뒷면에서 볼 때 바르게 보이도록 x 반전"""
    def __init__(self, z0, z1, mirror=False):
        self.z0, self.z1, self.mirror, self.solids = z0, z1, mirror, []

    def X(self, u):
        return 50.0 - u if self.mirror else u

    def rect(self, u0, u1, y0, y1):
        a, b = sorted((self.X(u0), self.X(u1)))
        self.solids.append(box(a, b, y0, y1, self.z0, self.z1))

    def poly(self, pts):
        p = [(self.X(u), y) for u, y in pts]
        self.solids.append(cq.Workplane("XY").workplane(offset=self.z0).polyline(p).close().extrude(self.z1 - self.z0))

    def circle(self, u, y, r):
        self.solids.append(cyl(2 * r, self.z0, self.z1, self.X(u), y))

    def arc(self, u, y, r0, r1, a0, a1, n=24):
        import math
        outer = [(u + r1 * math.cos(math.radians(a0 + (a1 - a0) * i / n)), y + r1 * math.sin(math.radians(a0 + (a1 - a0) * i / n))) for i in range(n + 1)]
        inner = [(u + r0 * math.cos(math.radians(a1 - (a1 - a0) * i / n)), y + r0 * math.sin(math.radians(a1 - (a1 - a0) * i / n))) for i in range(n + 1)]
        self.poly(outer + inner)

    def text(self, s, u, y, size):
        t = cq.Workplane("XY").workplane(offset=self.z0).text(s, size, self.z1 - self.z0, fontPath=FONT,
                                                               halign="center", valign="center")
        self.solids.append(t.translate((self.X(u), y, 0)))

    def solid(self):
        if not self.solids:
            return None
        s = self.solids[0]
        for o in self.solids[1:]:
            s = s.union(o)
        return s


# ------------------------------------------------------------ 픽셀 글꼴 (3x5)
PIX = {
    "0": ["111", "101", "101", "101", "111"], "1": ["010", "110", "010", "010", "111"],
    "2": ["111", "001", "111", "100", "111"], "3": ["111", "001", "111", "001", "111"],
    "4": ["101", "101", "111", "001", "001"], "5": ["111", "100", "111", "001", "111"],
    "6": ["111", "100", "111", "101", "111"], "7": ["111", "001", "001", "001", "001"],
    "8": ["111", "101", "111", "101", "111"],
    "B": ["110", "101", "110", "101", "110"], "O": ["010", "101", "101", "101", "010"],
    "T": ["111", "010", "010", "010", "010"], "R": ["110", "101", "110", "101", "101"],
    "S": ["011", "100", "010", "001", "110"], "G": ["011", "100", "101", "101", "011"],
    "D": ["110", "101", "101", "101", "110"], "L": ["100", "100", "100", "100", "111"],
    "U": ["101", "101", "101", "101", "111"], "C": ["011", "100", "100", "100", "011"],
    "K": ["101", "101", "110", "101", "101"], " ": ["000"] * 5,
}

def pixel_text(layer, s, uc, yc, p):
    w = len(s) * 4 * p - p
    u0, y0 = uc - w / 2, yc - 2.5 * p
    for k, ch in enumerate(s):
        g = PIX[ch]
        for r, row in enumerate(g):
            yy = y0 + (4 - r) * p
            c = 0
            while c < 3:                      # 가로로 이어진 픽셀은 한 사각형으로
                if row[c] == "1":
                    c1 = c
                    while c1 < 3 and row[c1] == "1":
                        c1 += 1
                    layer.rect(u0 + k * 4 * p + c * p, u0 + k * 4 * p + c1 * p, yy, yy + p)
                    c = c1
                else:
                    c += 1


def seven_seg(layer, d, x, y, w=4.0, h=7.0, t=0.9):
    SEG = {0: "abcdef", 1: "bc", 2: "abged", 3: "abgcd", 4: "fgbc", 5: "afgcd",
           6: "afgedc", 7: "abc", 8: "abcdefg", 9: "abcdfg"}[d]
    m = h / 2
    R = {"a": (x + t, x + w - t, y + h - t, y + h), "d": (x + t, x + w - t, y, y + t),
         "g": (x + t, x + w - t, y + m - t / 2, y + m + t / 2),
         "b": (x + w - t, x + w, y + m + t / 2 + 0.1, y + h - t - 0.1),
         "c": (x + w - t, x + w, y + t + 0.1, y + m - t / 2 - 0.1),
         "e": (x, x + t, y + t + 0.1, y + m - t / 2 - 0.1),
         "f": (x, x + t, y + m + t / 2 + 0.1, y + h - t - 0.1)}
    for s in SEG:
        layer.rect(*R[s])


# ============================================================ 앞 베젤 디자인
def front_layers():
    z0, z1 = K.H - DEPTH, K.H + 0.5
    red, yel, wht, holes = Layer(z0, z1), Layer(z0, z1), Layer(z0, z1), Layer(z0 - 0.1, z1 + 0.1)
    yt, yb = 81.9, 4.1
    # 위: 7세그 카운터 "009"  ☺  "042" (게임 화면 위쪽 막대를 닮게)
    for i, d in enumerate([0, 0, 9]):
        seven_seg(red, d, -2.0 + i * 5.0, yt - 3.5)
    for i, d in enumerate([0, 4, 2]):
        seven_seg(red, d, 38.0 + i * 5.0, yt - 3.5)
    yel.circle(25.0, yt, 4.2)
    holes.circle(23.6, yt + 1.1, 0.65)
    holes.circle(26.4, yt + 1.1, 0.65)
    holes.arc(25.0, yt - 0.2, 2.0, 2.85, 200, 340)
    # 아래: 깃발 · 지뢰찾기 · 지뢰
    wht.text("지뢰찾기", 25.0, yb, 5.6)
    wht.rect(7.2, 7.9, 1.2, 7.6)                          # 깃대
    wht.rect(4.6, 10.4, 0.5, 1.4)                         # 받침
    red.poly([(7.2, 7.6), (7.2, 4.3), (3.2, 5.95)])        # 깃발
    mx = 43.5
    wht.circle(mx, yb, 2.3)
    wht.rect(mx - 3.6, mx + 3.6, yb - 0.4, yb + 0.4)
    wht.rect(mx - 0.4, mx + 0.4, yb - 3.6, yb + 3.6)
    import math
    for a in (45, 135):
        c, s = math.cos(math.radians(a)), math.sin(math.radians(a))
        L, W = 3.0, 0.38
        wht.poly([(mx + c * L - s * W, yb + s * L + c * W), (mx + c * L + s * W, yb + s * L - c * W),
                  (mx - c * L + s * W, yb - s * L - c * W), (mx - c * L - s * W, yb - s * L + c * W)])
    holes.circle(mx - 0.8, yb + 0.8, 0.55)                 # 반짝임(검정)
    return {"red": red.solid(), "yellow": yel.solid(), "white": wht.solid()}, holes.solid()


# ============================================================ 뒷 케이스 디자인
BOARD_MINES = {(2, 3), (3, 2), (3, 3), (4, 4), (4, 5), (5, 1)}
BOARD_FLAGS = {(5, 1), (3, 2), (2, 3)}
COLS, ROWS = 7, 6

def board_state():
    def adj(c, r):
        return sum((c + dc, r + dr) in BOARD_MINES for dc in (-1, 0, 1) for dr in (-1, 0, 1) if dc or dr)
    opened, stack = set(), [(0, 0)]
    while stack:                                       # (0,0)에서 연쇄 열기
        c, r = stack.pop()
        if (c, r) in opened or (c, r) in BOARD_MINES or not (0 <= c < COLS and 0 <= r < ROWS):
            continue
        opened.add((c, r))
        if adj(c, r) == 0:
            stack += [(c + dc, r + dr) for dc in (-1, 0, 1) for dr in (-1, 0, 1)]
    return opened, adj

def back_layers():
    z0, z1 = -0.5, DEPTH
    blk, wht, red = Layer(z0, z1, True), Layer(z0, z1, True), Layer(z0, z1, True)
    P, U0, Y0, LW = 5.0, 7.5, 53.0, 0.7
    opened, adj = board_state()
    for k in range(COLS + 1):
        blk.rect(U0 + k * P - LW / 2, U0 + k * P + LW / 2, Y0 - LW / 2, Y0 + ROWS * P + LW / 2)
    for k in range(ROWS + 1):
        blk.rect(U0 - LW / 2, U0 + COLS * P + LW / 2, Y0 + k * P - LW / 2, Y0 + k * P + LW / 2)
    half = P / 2 - LW / 2
    for c in range(COLS):
        for r in range(ROWS):
            cu, cy = U0 + c * P + P / 2, Y0 + (ROWS - 1 - r) * P + P / 2
            if (c, r) in opened:
                wht.rect(cu - half, cu + half, cy - half, cy + half)
                n = adj(c, r)
                if n:
                    pixel_text(blk if n == 1 else red, str(n), cu, cy, 0.7)
            elif (c, r) in BOARD_FLAGS:
                blk.rect(cu + 0.3, cu + 0.8, cy - 1.5, cy + 1.6)
                blk.rect(cu - 1.3, cu + 1.5, cy - 1.95, cy - 1.45)
                red.poly([(cu + 0.3, cy + 1.6), (cu + 0.3, cy - 0.1), (cu - 1.7, cy + 0.75)])
    pixel_text(blk, "GOOD LUCK", 25.0, 50.1, 0.6)
    pixel_text(blk, "BOOT", 50.0 - K.BOOT_XY[0], 8.0, 0.6)
    pixel_text(blk, "RST", 50.0 - K.RESET_XY[0], 8.0, 0.6)
    w = wht.solid().cut(blk.solid()).cut(red.solid())
    return {"black": blk.solid(), "white": w, "red": red.solid()}


def split(body, colors, holes=None):
    parts = {}
    for name, s in colors.items():
        if holes is not None:
            s = s.cut(holes)
        parts[name] = s.intersect(body)
    allc = None
    for s in parts.values():
        allc = s if allc is None else allc.union(s)
    return body.cut(allc), parts


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    front = K.make_front()
    fcol, fholes = front_layers()
    fbody, fparts = split(front, fcol, fholes)
    rot = lambda s: s.rotate((0, 0, 0), (0, 1, 0), 180).translate((0, 0, K.H))
    tol = dict(tolerance=0.02, angularTolerance=0.1)
    cq.exporters.export(rot(fbody), f"{OUT}/front_bezel_4c_1_body_black.stl", **tol)
    for i, (n, ko) in enumerate([("red", "2_red"), ("yellow", "3_yellow"), ("white", "4_white")]):
        cq.exporters.export(rot(fparts[n]), f"{OUT}/front_bezel_4c_{ko}.stl", **tol)

    bcol = back_layers()
    for variant, sw in [("back_shell_4c", False), ("back_shell_switch_4c", True)]:
        back = K.make_back(sw)
        bbody, bparts = split(back, bcol)
        cq.exporters.export(bbody, f"{OUT}/{variant}_1_body_yellow.stl", **tol)
        if not sw:
            for n, ko in [("black", "2_black"), ("white", "3_white"), ("red", "4_red")]:
                cq.exporters.export(bparts[n], f"{OUT}/back_shell_4c_{ko}.stl", **tol)
            keep_b = (bbody, bparts)
    # 미리보기용 (조립 좌표)
    os.makedirs("/root/render", exist_ok=True)
    cq.exporters.export(fbody, "/root/render/f_body.stl", tolerance=0.03, angularTolerance=0.15)
    for n, s in fparts.items():
        cq.exporters.export(s, f"/root/render/f_{n}.stl", tolerance=0.02, angularTolerance=0.1)
    cq.exporters.export(keep_b[0], "/root/render/b_body.stl", tolerance=0.03, angularTolerance=0.15)
    for n, s in keep_b[1].items():
        cq.exporters.export(s, f"/root/render/b_{n}.stl", tolerance=0.02, angularTolerance=0.1)

    print("front body valid:", fbody.val().isValid(), {n: round(s.val().Volume(), 1) for n, s in fparts.items()})
    print("back  body valid:", keep_b[0].val().isValid(), {n: round(s.val().Volume(), 1) for n, s in keep_b[1].items()})
    tot_f = fbody.val().Volume() + sum(s.val().Volume() for s in fparts.values())
    tot_b = keep_b[0].val().Volume() + sum(s.val().Volume() for s in keep_b[1].values())
    print(f"부피 보존 확인: 앞 {tot_f:.1f} vs {front.val().Volume():.1f} / 뒤 {tot_b:.1f} vs {K.make_back(False).val().Volume():.1f}")
    opened, adj = board_state()
    for r in range(ROWS):
        print(" ".join(("F" if (c, r) in BOARD_FLAGS else "#") if (c, r) not in opened else (str(adj(c, r)) if adj(c, r) else ".") for c in range(COLS)))
